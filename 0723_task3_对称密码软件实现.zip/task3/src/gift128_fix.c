/*
 * 32-bit fixsliced GIFT-128 implementation adapted from the CC0 reference by
 * Alexandre Adomnicai (https://github.com/aadomn/gift).  The surrounding API,
 * unaligned-safe loads, and key-context reuse are specific to this project.
 */
#include "optcrypto.h"
#include "internal.h"

#include <stdint.h>

#define GIFT_ROR(x, n) oc_rotr32((x), (n))
#define BYTE_ROR_2(x) ((((x) >> 2) & 0x3f3f3f3fU) | (((x) & 0x03030303U) << 6))
#define BYTE_ROR_4(x) ((((x) >> 4) & 0x0f0f0f0fU) | (((x) & 0x0f0f0f0fU) << 4))
#define BYTE_ROR_6(x) ((((x) >> 6) & 0x03030303U) | (((x) & 0x3f3f3f3fU) << 2))
#define HALF_ROR_4(x) ((((x) >> 4) & 0x0fff0fffU) | (((x) & 0x000f000fU) << 12))
#define HALF_ROR_8(x) ((((x) >> 8) & 0x00ff00ffU) | (((x) & 0x00ff00ffU) << 8))
#define HALF_ROR_12(x) ((((x) >> 12) & 0x000f000fU) | (((x) & 0x0fff0fffU) << 4))
#define NIBBLE_ROR_1(x) ((((x) >> 1) & 0x77777777U) | (((x) & 0x11111111U) << 3))
#define NIBBLE_ROR_2(x) ((((x) >> 2) & 0x33333333U) | (((x) & 0x33333333U) << 2))
#define NIBBLE_ROR_3(x) ((((x) >> 3) & 0x11111111U) | (((x) & 0x77777777U) << 1))

#define SWAPMOVE(a, b, mask, n) do {                 \
    tmp = ((b) ^ ((a) >> (n))) & (mask);             \
    (b) ^= tmp;                                       \
    (a) ^= tmp << (n);                                \
} while (0)

#define SBOX(s0, s1, s2, s3) do {                    \
    (s1) ^= (s0) & (s2);                              \
    (s0) ^= (s1) & (s3);                              \
    (s2) ^= (s0) | (s1);                              \
    (s3) ^= (s2);                                     \
    (s1) ^= (s3);                                     \
    (s3) = ~(s3);                                     \
    (s2) ^= (s0) & (s1);                              \
} while (0)

#define INV_SBOX(s0, s1, s2, s3) do {                \
    (s2) ^= (s3) & (s1);                              \
    (s0) = ~(s0);                                     \
    (s1) ^= (s0);                                     \
    (s0) ^= (s2);                                     \
    (s2) ^= (s3) | (s1);                              \
    (s3) ^= (s1) & (s0);                              \
    (s1) ^= (s3) & (s2);                              \
} while (0)

static const uint32_t fix_rconst[40] = {
    0x10000008U,0x80018000U,0x54000002U,0x01010181U,
    0x8000001fU,0x10888880U,0x6001e000U,0x51500002U,
    0x03030180U,0x8000002fU,0x10088880U,0x60016000U,
    0x41500002U,0x03030080U,0x80000027U,0x10008880U,
    0x4001e000U,0x11500002U,0x03020180U,0x8000002bU,
    0x10080880U,0x60014000U,0x01400002U,0x02020080U,
    0x80000021U,0x10000080U,0x0001c000U,0x51000002U,
    0x03010180U,0x8000002eU,0x10088800U,0x60012000U,
    0x40500002U,0x01030080U,0x80000006U,0x10008808U,
    0xc001a000U,0x14500002U,0x01020181U,0x8000001aU
};

static uint32_t key_update(uint32_t x)
{
    return ((x >> 12) & 0x0000000fU) | ((x & 0x00000fffU) << 4) |
           ((x >> 2) & 0x3fff0000U) | ((x & 0x00030000U) << 14);
}

static uint32_t rearrange0(uint32_t x)
{
    uint32_t tmp;
    SWAPMOVE(x, x, 0x00550055U, 9);
    SWAPMOVE(x, x, 0x000f000fU, 12);
    SWAPMOVE(x, x, 0x00003333U, 18);
    SWAPMOVE(x, x, 0x000000ffU, 24);
    return x;
}

static uint32_t rearrange1(uint32_t x)
{
    uint32_t tmp;
    SWAPMOVE(x, x, 0x11111111U, 3);
    SWAPMOVE(x, x, 0x03030303U, 6);
    SWAPMOVE(x, x, 0x000f000fU, 12);
    SWAPMOVE(x, x, 0x000000ffU, 24);
    return x;
}

static uint32_t rearrange2(uint32_t x)
{
    uint32_t tmp;
    SWAPMOVE(x, x, 0x0000aaaaU, 15);
    SWAPMOVE(x, x, 0x00003333U, 18);
    SWAPMOVE(x, x, 0x0000f0f0U, 12);
    SWAPMOVE(x, x, 0x000000ffU, 24);
    return x;
}

static uint32_t rearrange3(uint32_t x)
{
    uint32_t tmp;
    SWAPMOVE(x, x, 0x0a0a0a0aU, 3);
    SWAPMOVE(x, x, 0x00cc00ccU, 6);
    SWAPMOVE(x, x, 0x0000f0f0U, 12);
    SWAPMOVE(x, x, 0x000000ffU, 24);
    return x;
}

static uint32_t key_triple0(uint32_t x)
{
    return GIFT_ROR(x & 0x33333333U, 24) | GIFT_ROR(x & 0xccccccccU, 16);
}

static uint32_t key_double1(uint32_t x)
{
    return ((x >> 4) & 0x0f000f00U) | ((x & 0x0f000f00U) << 4) |
           ((x >> 6) & 0x00030003U) | ((x & 0x003f003fU) << 2);
}

static uint32_t key_triple1(uint32_t x)
{
    return ((x >> 6) & 0x03000300U) | ((x & 0x3f003f00U) << 2) |
           ((x >> 5) & 0x00070007U) | ((x & 0x001f001fU) << 3);
}

static uint32_t key_double2(uint32_t x)
{
    return GIFT_ROR(x & 0xaaaaaaaaU, 24) | GIFT_ROR(x & 0x55555555U, 16);
}

static uint32_t key_triple2(uint32_t x)
{
    return GIFT_ROR(x & 0x55555555U, 24) | GIFT_ROR(x & 0xaaaaaaaaU, 20);
}

static uint32_t key_double3(uint32_t x)
{
    return ((x >> 2) & 0x03030303U) | ((x & 0x03030303U) << 2) |
           ((x >> 1) & 0x70707070U) | ((x & 0x10101010U) << 3);
}

static uint32_t key_triple3(uint32_t x)
{
    return ((x >> 18) & 0x00003030U) | ((x & 0x01010101U) << 3) |
           ((x >> 14) & 0x0000c0c0U) | ((x & 0x0000e0e0U) << 15) |
           ((x >> 1) & 0x07070707U) | ((x & 0x00001010U) << 19);
}

static uint32_t key_double4(uint32_t x)
{
    return ((x >> 4) & 0x0fff0000U) | ((x & 0x000f0000U) << 12) |
           ((x >> 8) & 0x000000ffU) | ((x & 0x000000ffU) << 8);
}

static uint32_t key_triple4(uint32_t x)
{
    return ((x >> 6) & 0x03ff0000U) | ((x & 0x003f0000U) << 10) |
           ((x >> 4) & 0x00000fffU) | ((x & 0x0000000fU) << 12);
}

void oc_gift128_fix_init(oc_gift128_fix_ctx *ctx, const uint8_t key[16])
{
    uint32_t *rkey = ctx->rkey;
    uint32_t tmp;
    int i;
    rkey[0] = oc_load32_be(key + 12);
    rkey[1] = oc_load32_be(key + 4);
    rkey[2] = oc_load32_be(key + 8);
    rkey[3] = oc_load32_be(key);
    for (i = 0; i < 16; i += 2) {
        rkey[i + 4] = rkey[i + 1];
        rkey[i + 5] = key_update(rkey[i]);
    }
    for (i = 0; i < 20; i += 10) {
        rkey[i] = rearrange0(rkey[i]);
        rkey[i + 1] = rearrange0(rkey[i + 1]);
        rkey[i + 2] = rearrange1(rkey[i + 2]);
        rkey[i + 3] = rearrange1(rkey[i + 3]);
        rkey[i + 4] = rearrange2(rkey[i + 4]);
        rkey[i + 5] = rearrange2(rkey[i + 5]);
        rkey[i + 6] = rearrange3(rkey[i + 6]);
        rkey[i + 7] = rearrange3(rkey[i + 7]);
    }
    for (i = 20; i < 80; i += 10) {
        rkey[i] = rkey[i - 19];
        rkey[i + 1] = key_triple0(rkey[i - 20]);
        rkey[i + 2] = key_double1(rkey[i - 17]);
        rkey[i + 3] = key_triple1(rkey[i - 18]);
        rkey[i + 4] = key_double2(rkey[i - 15]);
        rkey[i + 5] = key_triple2(rkey[i - 16]);
        rkey[i + 6] = key_double3(rkey[i - 13]);
        rkey[i + 7] = key_triple3(rkey[i - 14]);
        rkey[i + 8] = key_double4(rkey[i - 11]);
        rkey[i + 9] = key_triple4(rkey[i - 12]);
        SWAPMOVE(rkey[i], rkey[i], 0x00003333U, 16);
        SWAPMOVE(rkey[i], rkey[i], 0x55554444U, 1);
        SWAPMOVE(rkey[i + 1], rkey[i + 1], 0x55551100U, 1);
    }
}

static void packing(uint32_t state[4], const uint8_t input[16])
{
    uint32_t tmp;
    state[0] = ((uint32_t)input[6] << 24) | ((uint32_t)input[7] << 16) |
               ((uint32_t)input[14] << 8) | input[15];
    state[1] = ((uint32_t)input[4] << 24) | ((uint32_t)input[5] << 16) |
               ((uint32_t)input[12] << 8) | input[13];
    state[2] = ((uint32_t)input[2] << 24) | ((uint32_t)input[3] << 16) |
               ((uint32_t)input[10] << 8) | input[11];
    state[3] = ((uint32_t)input[0] << 24) | ((uint32_t)input[1] << 16) |
               ((uint32_t)input[8] << 8) | input[9];
    SWAPMOVE(state[0], state[0], 0x0a0a0a0aU, 3);
    SWAPMOVE(state[0], state[0], 0x00cc00ccU, 6);
    SWAPMOVE(state[1], state[1], 0x0a0a0a0aU, 3);
    SWAPMOVE(state[1], state[1], 0x00cc00ccU, 6);
    SWAPMOVE(state[2], state[2], 0x0a0a0a0aU, 3);
    SWAPMOVE(state[2], state[2], 0x00cc00ccU, 6);
    SWAPMOVE(state[3], state[3], 0x0a0a0a0aU, 3);
    SWAPMOVE(state[3], state[3], 0x00cc00ccU, 6);
    SWAPMOVE(state[0], state[1], 0x000f000fU, 4);
    SWAPMOVE(state[0], state[2], 0x000f000fU, 8);
    SWAPMOVE(state[0], state[3], 0x000f000fU, 12);
    SWAPMOVE(state[1], state[2], 0x00f000f0U, 4);
    SWAPMOVE(state[1], state[3], 0x00f000f0U, 8);
    SWAPMOVE(state[2], state[3], 0x0f000f00U, 4);
}

static void unpacking(uint8_t output[16], uint32_t state[4])
{
    uint32_t tmp;
    SWAPMOVE(state[2], state[3], 0x0f000f00U, 4);
    SWAPMOVE(state[1], state[3], 0x00f000f0U, 8);
    SWAPMOVE(state[1], state[2], 0x00f000f0U, 4);
    SWAPMOVE(state[0], state[3], 0x000f000fU, 12);
    SWAPMOVE(state[0], state[2], 0x000f000fU, 8);
    SWAPMOVE(state[0], state[1], 0x000f000fU, 4);
    SWAPMOVE(state[3], state[3], 0x00cc00ccU, 6);
    SWAPMOVE(state[3], state[3], 0x0a0a0a0aU, 3);
    SWAPMOVE(state[2], state[2], 0x00cc00ccU, 6);
    SWAPMOVE(state[2], state[2], 0x0a0a0a0aU, 3);
    SWAPMOVE(state[1], state[1], 0x00cc00ccU, 6);
    SWAPMOVE(state[1], state[1], 0x0a0a0a0aU, 3);
    SWAPMOVE(state[0], state[0], 0x00cc00ccU, 6);
    SWAPMOVE(state[0], state[0], 0x0a0a0a0aU, 3);
    output[0] = (uint8_t)(state[3] >> 24);
    output[1] = (uint8_t)(state[3] >> 16);
    output[2] = (uint8_t)(state[2] >> 24);
    output[3] = (uint8_t)(state[2] >> 16);
    output[4] = (uint8_t)(state[1] >> 24);
    output[5] = (uint8_t)(state[1] >> 16);
    output[6] = (uint8_t)(state[0] >> 24);
    output[7] = (uint8_t)(state[0] >> 16);
    output[8] = (uint8_t)(state[3] >> 8);
    output[9] = (uint8_t)state[3];
    output[10] = (uint8_t)(state[2] >> 8);
    output[11] = (uint8_t)state[2];
    output[12] = (uint8_t)(state[1] >> 8);
    output[13] = (uint8_t)state[1];
    output[14] = (uint8_t)(state[0] >> 8);
    output[15] = (uint8_t)state[0];
}

static void quintuple_round(uint32_t s[4], const uint32_t *rk,
                            const uint32_t *rc)
{
    uint32_t tmp;
    SBOX(s[0], s[1], s[2], s[3]);
    s[3] = NIBBLE_ROR_1(s[3]); s[1] = NIBBLE_ROR_2(s[1]);
    s[2] = NIBBLE_ROR_3(s[2]); s[1] ^= rk[0]; s[2] ^= rk[1]; s[0] ^= rc[0];
    SBOX(s[3], s[1], s[2], s[0]);
    s[0] = HALF_ROR_4(s[0]); s[1] = HALF_ROR_8(s[1]);
    s[2] = HALF_ROR_12(s[2]); s[1] ^= rk[2]; s[2] ^= rk[3]; s[3] ^= rc[1];
    SBOX(s[0], s[1], s[2], s[3]);
    s[3] = GIFT_ROR(s[3], 16); s[2] = GIFT_ROR(s[2], 16);
    SWAPMOVE(s[1], s[1], 0x55555555U, 1);
    SWAPMOVE(s[2], s[2], 0x00005555U, 1);
    SWAPMOVE(s[3], s[3], 0x55550000U, 1);
    s[1] ^= rk[4]; s[2] ^= rk[5]; s[0] ^= rc[2];
    SBOX(s[3], s[1], s[2], s[0]);
    s[0] = BYTE_ROR_6(s[0]); s[1] = BYTE_ROR_4(s[1]);
    s[2] = BYTE_ROR_2(s[2]); s[1] ^= rk[6]; s[2] ^= rk[7]; s[3] ^= rc[3];
    SBOX(s[0], s[1], s[2], s[3]);
    s[3] = GIFT_ROR(s[3], 24); s[1] = GIFT_ROR(s[1], 16);
    s[2] = GIFT_ROR(s[2], 8); s[1] ^= rk[8]; s[2] ^= rk[9]; s[0] ^= rc[4];
    tmp = s[0]; s[0] = s[3]; s[3] = tmp;
}

static void inv_quintuple_round(uint32_t s[4], const uint32_t *rk,
                                const uint32_t *rc)
{
    uint32_t tmp;
    tmp = s[0]; s[0] = s[3]; s[3] = tmp;
    s[1] ^= rk[8]; s[2] ^= rk[9]; s[0] ^= rc[4];
    s[3] = GIFT_ROR(s[3], 8); s[1] = GIFT_ROR(s[1], 16);
    s[2] = GIFT_ROR(s[2], 24); INV_SBOX(s[3], s[1], s[2], s[0]);
    s[1] ^= rk[6]; s[2] ^= rk[7]; s[3] ^= rc[3];
    s[0] = BYTE_ROR_2(s[0]); s[1] = BYTE_ROR_4(s[1]);
    s[2] = BYTE_ROR_6(s[2]); INV_SBOX(s[0], s[1], s[2], s[3]);
    s[1] ^= rk[4]; s[2] ^= rk[5]; s[0] ^= rc[2];
    SWAPMOVE(s[3], s[3], 0x55550000U, 1);
    SWAPMOVE(s[1], s[1], 0x55555555U, 1);
    SWAPMOVE(s[2], s[2], 0x00005555U, 1);
    s[3] = GIFT_ROR(s[3], 16); s[2] = GIFT_ROR(s[2], 16);
    INV_SBOX(s[3], s[1], s[2], s[0]);
    s[1] ^= rk[2]; s[2] ^= rk[3]; s[3] ^= rc[1];
    s[0] = HALF_ROR_12(s[0]); s[1] = HALF_ROR_8(s[1]);
    s[2] = HALF_ROR_4(s[2]); INV_SBOX(s[0], s[1], s[2], s[3]);
    s[1] ^= rk[0]; s[2] ^= rk[1]; s[0] ^= rc[0];
    s[3] = NIBBLE_ROR_3(s[3]); s[1] = NIBBLE_ROR_2(s[1]);
    s[2] = NIBBLE_ROR_1(s[2]); INV_SBOX(s[3], s[1], s[2], s[0]);
}

static void fix_crypt_one(const oc_gift128_fix_ctx *ctx, uint8_t *out,
                          const uint8_t *in, int decrypt)
{
    uint32_t state[4];
    int i;
    packing(state, in);
    if (!decrypt)
        for (i = 0; i < 40; i += 5)
            quintuple_round(state, ctx->rkey + 2 * i, fix_rconst + i);
    else
        for (i = 35; i >= 0; i -= 5)
            inv_quintuple_round(state, ctx->rkey + 2 * i, fix_rconst + i);
    unpacking(out, state);
}

static void fix_encrypt(const void *vctx, uint8_t *out,
                        const uint8_t *in, size_t blocks)
{
    const oc_gift128_fix_ctx *ctx = (const oc_gift128_fix_ctx *)vctx;
    size_t i;
    for (i = 0; i < blocks; ++i)
        fix_crypt_one(ctx, out + 16 * i, in + 16 * i, 0);
}

static void fix_decrypt(const void *vctx, uint8_t *out,
                        const uint8_t *in, size_t blocks)
{
    const oc_gift128_fix_ctx *ctx = (const oc_gift128_fix_ctx *)vctx;
    size_t i;
    for (i = 0; i < blocks; ++i)
        fix_crypt_one(ctx, out + 16 * i, in + 16 * i, 1);
}

oc_cipher oc_gift128_fix_cipher(const oc_gift128_fix_ctx *ctx)
{
    oc_cipher c = {ctx, 16, fix_encrypt, fix_decrypt, "GIFT-128-fixsliced"};
    return c;
}
