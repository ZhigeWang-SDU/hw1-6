# GCM-64 和 XTS-64 实现文档

## 概述

为64位分组密码（TWINE-80）实现了GCM和XTS工作模式的64位变体。这些实现基于GF(2^64)上的伽罗华域运算。

## 理论基础

### GCM-64 (Galois/Counter Mode for 64-bit Block Ciphers)

**数学基础：**
- 使用GF(2^64)域上的GHASH运算
- 既约多项式：x^64 + x^4 + x^3 + x + 1 (对应16进制 0x1B)
- 计数器模式：64位分组，最后32位作为计数器

**安全限制：**
- 生日界限：约2^32个分组（约32 GB数据）
- 超过此限制后安全性会显著下降
- Nonce不应重复使用

**特性：**
- 认证加密（AEAD）
- 支持附加认证数据（AAD）
- 输出64位认证标签
- 支持任意长度nonce（推荐64位）

### XTS-64 (XEX-based Tweaked CodeBook mode for 64-bit Block Ciphers)

**数学基础：**
- 使用GF(2^64)域上的乘法
- 既约多项式：x^64 + x^4 + x^3 + x + 1 (对应16进制 0x1B)
- Tweak更新：T_i = T_0 · α^i，其中α是原根

**特性：**
- 磁盘加密专用模式
- 支持密文窃取（Ciphertext Stealing）处理非整块数据
- 每个数据单元使用独立的tweak
- 需要两个独立的密钥实例

## API 接口

### GCM-64

```c
/* 加密 */
int oc_gcm64_encrypt(const oc_cipher *cipher, uint8_t *out,
                     const uint8_t *in, size_t len,
                     const uint8_t *aad, size_t aad_len,
                     const uint8_t *nonce, size_t nonce_len,
                     uint8_t tag[8]);

/* 解密 */
int oc_gcm64_decrypt(const oc_cipher *cipher, uint8_t *out,
                     const uint8_t *in, size_t len,
                     const uint8_t *aad, size_t aad_len,
                     const uint8_t *nonce, size_t nonce_len,
                     const uint8_t tag[8]);
```

**参数：**
- `cipher`: 64位分组密码（block_size = 8）
- `out/in`: 输出/输入缓冲区
- `len`: 数据长度（字节）
- `aad/aad_len`: 附加认证数据及其长度
- `nonce/nonce_len`: Nonce及其长度（推荐8字节）
- `tag`: 64位（8字节）认证标签

**返回值：**
- `0`: 成功
- `-1`: 参数错误
- `-2`: 认证失败（仅解密）

### XTS-64

```c
/* 加密 */
int oc_xts64_encrypt(const oc_cipher *data_cipher,
                     const oc_cipher *tweak_cipher, uint8_t *out,
                     const uint8_t *in, size_t len,
                     const uint8_t data_unit[8]);

/* 解密 */
int oc_xts64_decrypt(const oc_cipher *data_cipher,
                     const oc_cipher *tweak_cipher, uint8_t *out,
                     const uint8_t *in, size_t len,
                     const uint8_t data_unit[8]);
```

**参数：**
- `data_cipher`: 数据加密密钥上下文
- `tweak_cipher`: Tweak加密密钥上下文（必须与data_cipher独立）
- `out/in`: 输出/输入缓冲区
- `len`: 数据长度（至少8字节）
- `data_unit`: 64位数据单元标识符（扇区号）

**返回值：**
- `0`: 成功
- `-1`: 参数错误

## 使用示例

### GCM-64 示例

```c
#include "optcrypto.h"

uint8_t key[10] = {0};
uint8_t nonce[8] = {0x12,0x34,0x56,0x78,0x9a,0xbc,0xde,0xf0};
uint8_t plaintext[100] = "Hello, World!";
uint8_t ciphertext[100];
uint8_t aad[16] = "metadata";
uint8_t tag[8];

oc_twine80_ttable_ctx ctx;
oc_twine80_ttable_init(&ctx, key);
oc_cipher twine = oc_twine80_ttable_cipher(&ctx);

/* 加密 */
oc_gcm64_encrypt(&twine, ciphertext, plaintext, 100,
                 aad, 16, nonce, 8, tag);

/* 解密 */
uint8_t decrypted[100];
int result = oc_gcm64_decrypt(&twine, decrypted, ciphertext, 100,
                              aad, 16, nonce, 8, tag);
if (result == -2) {
    printf("Authentication failed!\n");
}
```

### XTS-64 示例

```c
#include "optcrypto.h"

uint8_t key1[10] = {0};  /* 数据密钥 */
uint8_t key2[10] = {1};  /* Tweak密钥（必须不同） */
uint8_t sector_data[512];
uint8_t encrypted[512];
uint8_t sector_id[8] = {0, 0, 0, 0, 0, 0, 0, 42};  /* 扇区42 */

oc_twine80_ttable_ctx data_ctx, tweak_ctx;
oc_twine80_ttable_init(&data_ctx, key1);
oc_twine80_ttable_init(&tweak_ctx, key2);
oc_cipher data = oc_twine80_ttable_cipher(&data_ctx);
oc_cipher tweak = oc_twine80_ttable_cipher(&tweak_ctx);

/* 加密扇区 */
oc_xts64_encrypt(&data, &tweak, encrypted, sector_data, 512, sector_id);

/* 解密扇区 */
uint8_t decrypted[512];
oc_xts64_decrypt(&data, &tweak, decrypted, encrypted, 512, sector_id);
```

## 性能基准测试

**测试环境：** 1 MiB 数据，AVX2 + PCLMUL

| 模式                          | 吞吐量    | 相对性能 |
|-------------------------------|-----------|----------|
| **GCM-64 / TWINE T-table**    | 11.35 MiB/s | 基准 |
| **GCM-64 / TWINE AVX2**       | 14.67 MiB/s | 1.29x |
| **XTS-64 / TWINE T-table**    | 39.58 MiB/s | 基准 |
| **XTS-64 / TWINE AVX2**       | 189.91 MiB/s | 4.80x |

**性能分析：**
1. **GCM-64性能瓶颈在GHASH**：GF(2^64)乘法较慢，没有硬件加速
2. **XTS-64性能优秀**：主要开销在密码本身，域乘法开销小
3. **AVX2加速显著**：特别是XTS-64，可以批量处理多个分组

## 实现细节

### GHASH-64 实现

```c
static void ghash64_mul(uint8_t out[8], const uint8_t x[8], const uint8_t h[8])
{
    /* 在GF(2^64)上进行carryless乘法和模既约 */
    /* 既约多项式：x^64 + x^4 + x^3 + x + 1 */
    /* 反馈常数：0x1B */
}
```

**关键点：**
- 使用移位和异或实现无进位乘法
- 每次右移后检查最低位，决定是否异或0x1B
- 时间复杂度O(64)，常数时间实现

### XTS-64 Alpha乘法

```c
static void xts64_mul_alpha(uint8_t tweak[8])
{
    /* 在GF(2^64)上乘以α（即x） */
    uint8_t carry = tweak左移1位产生的进位;
    if (carry) {
        tweak[0] ^= 0x1B;  /* 模既约 */
    }
}
```

**关键点：**
- Alpha乘法就是多项式乘以x（左移一位）
- 如果产生进位（超出64位），需要模既约
- 非常高效，仅需移位和条件异或

### 密文窃取（Ciphertext Stealing）

XTS-64支持非8字节对齐的数据：

1. 完整分组正常处理
2. 最后一个不完整分组：
   - 借用前一个密文分组的尾部字节
   - 形成完整分组进行加密
   - 交换顺序输出

这确保密文长度与明文完全相同。

## 安全注意事项

### GCM-64

⚠️ **生日界限攻击：**
- 64位分组在约2^32个分组后出现碰撞
- **限制：单个密钥不超过32 GB数据**
- 实现中硬编码了32 GB限制

⚠️ **Nonce重用：**
- 绝对不能在同一密钥下重用nonce
- 建议使用随机或计数器nonce

### XTS-64

⚠️ **密钥独立性：**
- data_cipher和tweak_cipher必须使用不同的密钥
- 使用相同密钥会破坏安全性

⚠️ **不提供完整性：**
- XTS只提供保密性，不提供认证
- 适用于全盘加密，不适用于网络传输

⚠️ **数据单元边界：**
- 不同数据单元必须使用不同的data_unit值
- 通常使用扇区号或块号

## 测试覆盖

### 功能测试
- ✅ 基本加密/解密正确性
- ✅ 认证标签验证（GCM-64）
- ✅ 标签篡改检测（GCM-64）
- ✅ 非标准nonce长度支持
- ✅ 空明文处理
- ✅ 密文窃取（XTS-64）
- ✅ 多种数据长度（8-257字节）
- ✅ 原地加密/解密

### 差分测试
- ✅ 相同密钥和nonce产生相同输出
- ✅ 不同实例产生一致结果

### 边界测试
- ✅ 最小数据长度（8字节）
- ✅ 不对齐数据长度
- ✅ 大数据量（1 MiB）

## 与标准GCM/XTS的差异

| 特性 | GCM (128-bit) | GCM-64 (64-bit) |
|------|---------------|-----------------|
| 分组大小 | 128位 | 64位 |
| 标签大小 | 128位 | 64位 |
| 既约多项式 | x^128+x^7+x^2+x+1 | x^64+x^4+x^3+x+1 |
| 反馈常数 | 0xE1 | 0x1B |
| 安全界限 | ~2^64块 | ~2^32块 |
| 推荐nonce | 96位 | 64位 |

| 特性 | XTS (128-bit) | XTS-64 (64-bit) |
|------|---------------|-----------------|
| 分组大小 | 128位 | 64位 |
| 既约多项式 | x^128+x^7+x^2+x+1 | x^64+x^4+x^3+x+1 |
| 反馈常数 | 0x87 | 0x1B |
| Data Unit | 128位 | 64位 |

## 参考文献

1. NIST SP 800-38D: Recommendation for Block Cipher Modes of Operation: Galois/Counter Mode (GCM) and GMAC
2. IEEE P1619: Standard for Cryptographic Protection of Data on Block-Oriented Storage Devices
3. McGrew, D. and Viega, J.: The Galois/Counter Mode of Operation (GCM)
4. 既约多项式选择基于标准不可约多项式表

## 文件清单

**修改的文件：**
- `src/modes.c`: 添加GCM-64和XTS-64实现（约350行）
- `include/optcrypto.h`: 添加API声明
- `tests/test.c`: 添加完整测试用例
- `bench/bench.c`: 添加性能基准测试

**新增函数：**
- `ghash64_mul()`, `ghash64_update()`: GHASH-64核心
- `gctr64()`: CTR模式（64位）
- `make_j0_64()`, `make_tag64()`: GCM-64辅助函数
- `oc_gcm64_encrypt()`, `oc_gcm64_decrypt()`: 公共API
- `xts64_mul_alpha()`: Alpha乘法
- `xts64_xex_one()`, `xts64_full_blocks()`: XTS-64核心
- `oc_xts64_encrypt()`, `oc_xts64_decrypt()`: 公共API

## 总结

成功为TWINE-80（64位分组密码）实现了：
1. ✅ GCM-64认证加密模式（基于GF(2^64)）
2. ✅ XTS-64磁盘加密模式（基于GF(2^64)）
3. ✅ 完整的测试覆盖
4. ✅ 性能基准测试
5. ✅ 详细的文档

这些实现填补了项目中64位分组密码工作模式的空白，使TWINE可以使用与SM4/GIFT相同的模式API。
