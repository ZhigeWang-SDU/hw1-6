param(
    [ValidateSet("all", "test", "bench", "clean")]
    [string]$Target = "all",
    [ValidateSet("Release", "Debug")]
    [string]$Configuration = "Release"
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$buildDir = Join-Path $root "build"

if ($Target -eq "clean") {
    if (Test-Path -LiteralPath $buildDir) {
        Remove-Item -Recurse -Force -LiteralPath $buildDir
    }
    return
}

$gcc = Get-Command gcc -ErrorAction Stop
New-Item -ItemType Directory -Force -Path $buildDir | Out-Null

$common = @("-std=c11", "-Wall", "-Wextra", "-Wpedantic", "-Iinclude")
if ($Configuration -eq "Release") {
    $common += @("-O3", "-DNDEBUG")
} else {
    $common += @("-O0", "-g3")
}

$sources = Get-ChildItem -LiteralPath (Join-Path $root "src") -Filter "*.c" |
    ForEach-Object { "src/$($_.Name)" }

function Build-Program([string]$Name, [string]$Main) {
    $output = "build/$Name.exe"
    & $gcc.Source @common @sources $Main "-o" $output
    if ($LASTEXITCODE -ne 0) {
        throw "gcc failed while building $Name"
    }
    Write-Host "built $output"
}

Push-Location $root
try {
    if ($Target -in @("all", "test")) {
        Build-Program "test_optcrypto" "tests/test.c"
    }
    if ($Target -in @("all", "bench")) {
        Build-Program "bench_optcrypto" "bench/bench.c"
    }
} finally {
    Pop-Location
}
