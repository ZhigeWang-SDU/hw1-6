#include "optcrypto.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int failures;

#define CHECK(condition, message) do {                                      \
    if (!(condition)) {                                                     \
        fprintf(stderr, "FAIL: %s (line %d)\n", (message), __LINE__);       \
        ++failures;                                                         \
    }                                                                       \
} while (0)

static size_t from_hex(uint8_t *out, const char *hex)
{
    size_t n = strlen(hex) / 2, i;
    for (i = 0; i < n; ++i) {
        unsigned value;
        if (sscanf(hex + 2 * i, "%2x", &value) != 1)
            return 0;
        out[i] = (uint8_t)value;
    }
    return n;
}

static uint32_t rng_state = 0x6d2b79f5U;

static uint32_t next_random(void)
{
    uint32_t x = rng_state;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    rng_state = x;
    return x;
}

static void random_bytes(uint8_t *out, size_t len)
{
    size_t i;
    for (i = 0; i < len; ++i)
        out[i] = (uint8_t)next_random();
}

static void test_aes128(void)
{
    static const size_t block_counts[] = {0,1,2,3,4,7,8,9,15,16};
    uint8_t key[16], plain[16], expected[16], input[16 * 16];
    uint8_t reference[sizeof(input)], output[sizeof(input)], back[sizeof(input)];
    oc_aes128_ctx basic_ctx;
    oc_aes128_ttable_ctx table_ctx;
    oc_aes128_shuffle_ctx shuffle_ctx;
    oc_aes128_aesni_ctx aesni_ctx;
    oc_cipher ciphers[5];
    size_t i, j;

    from_hex(key, "000102030405060708090a0b0c0d0e0f");
    from_hex(plain, "00112233445566778899aabbccddeeff");
    from_hex(expected, "69c4e0d86a7b0430d8cdb78070b4c55a");
    oc_aes128_init(&basic_ctx, key);
    oc_aes128_ttable_init(&table_ctx, key);
    oc_aes128_shuffle_init(&shuffle_ctx, key);
    oc_aes128_aesni_init(&aesni_ctx, key);
    ciphers[0] = oc_aes128_basic_cipher(&basic_ctx);
    ciphers[1] = oc_aes128_ttable_cipher(&table_ctx);
    ciphers[2] = oc_aes128_avx2_gather_cipher(&table_ctx);
    ciphers[3] = oc_aes128_shuffle_cipher(&shuffle_ctx);
    ciphers[4] = oc_aes128_aesni_cipher(&aesni_ctx);

    for (i = 0; i < 5; ++i) {
        ciphers[i].encrypt_blocks(ciphers[i].ctx, output, plain, 1);
        CHECK(memcmp(output, expected, 16) == 0,
              "AES-128 FIPS 197 encryption vector");
        ciphers[i].decrypt_blocks(ciphers[i].ctx, back, expected, 1);
        CHECK(memcmp(back, plain, 16) == 0,
              "AES-128 FIPS 197 decryption vector");
    }

    random_bytes(input, sizeof(input));
    ciphers[0].encrypt_blocks(ciphers[0].ctx, reference, input, 16);
    for (i = 0; i < 5; ++i) {
        ciphers[i].encrypt_blocks(ciphers[i].ctx, output, input, 16);
        CHECK(memcmp(output, reference, sizeof(input)) == 0,
              "AES-128 backend/basic differential");
        ciphers[i].decrypt_blocks(ciphers[i].ctx, output, output, 16);
        CHECK(memcmp(output, input, sizeof(input)) == 0,
              "AES-128 optimized in-place round trip");
    }
    for (j = 0; j < sizeof(block_counts) / sizeof(block_counts[0]); ++j) {
        size_t blocks = block_counts[j];
        ciphers[0].encrypt_blocks(ciphers[0].ctx, reference, input, blocks);
        for (i = 1; i < 5; ++i) {
            ciphers[i].encrypt_blocks(ciphers[i].ctx, output, input, blocks);
            CHECK(memcmp(output, reference, blocks * 16) == 0,
                  "AES-128 batch/tail differential");
        }
    }
}

static void test_aes128_ctr(void)
{
    static const size_t lengths[] = {1,15,16,17};
    uint8_t key[16], initial[16], counter[16], plain[64], expected[64];
    uint8_t output[64], back[64], zeros[32] = {0};
    oc_aes128_ctx basic_ctx;
    oc_aes128_ttable_ctx table_ctx;
    oc_aes128_shuffle_ctx shuffle_ctx;
    oc_aes128_aesni_ctx aesni_ctx;
    oc_cipher ciphers[5];
    size_t i;

    from_hex(key, "2b7e151628aed2a6abf7158809cf4f3c");
    from_hex(initial, "f0f1f2f3f4f5f6f7f8f9fafbfcfdfeff");
    from_hex(plain,
             "6bc1bee22e409f96e93d7e117393172a"
             "ae2d8a571e03ac9c9eb76fac45af8e51"
             "30c81c46a35ce411e5fbc1191a0a52ef"
             "f69f2445df4f9b17ad2b417be66c3710");
    from_hex(expected,
             "874d6191b620e3261bef6864990db6ce"
             "9806f66b7970fdff8617187bb9fffdff"
             "5ae4df3edbd5d35e5b4f09020db03eab"
             "1e031dda2fbe03d1792170a0f3009cee");
    oc_aes128_init(&basic_ctx, key);
    oc_aes128_ttable_init(&table_ctx, key);
    oc_aes128_shuffle_init(&shuffle_ctx, key);
    oc_aes128_aesni_init(&aesni_ctx, key);
    ciphers[0] = oc_aes128_basic_cipher(&basic_ctx);
    ciphers[1] = oc_aes128_ttable_cipher(&table_ctx);
    ciphers[2] = oc_aes128_avx2_gather_cipher(&table_ctx);
    ciphers[3] = oc_aes128_shuffle_cipher(&shuffle_ctx);
    ciphers[4] = oc_aes128_aesni_cipher(&aesni_ctx);
    for (i = 0; i < 5; ++i) {
        memcpy(counter, initial, 16);
        CHECK(oc_ctr_xor(&ciphers[i], output, plain, sizeof(plain), counter) == 0,
              "AES-CTR encryption");
        CHECK(memcmp(output, expected, sizeof(expected)) == 0,
              "AES-CTR SP 800-38A vector");
        memcpy(counter, initial, 16);
        CHECK(oc_ctr_xor(&ciphers[i], back, output, sizeof(output), counter) == 0 &&
              memcmp(back, plain, sizeof(plain)) == 0,
              "AES-CTR decryption");
    }

    memset(counter, 0, 16);
    counter[7] = 1;
    memset(counter + 8, 0xff, 8);
    CHECK(oc_ctr_xor(&ciphers[0], output, zeros, sizeof(zeros), counter) == 0,
          "AES-CTR 128-bit carry execution");
    CHECK(counter[7] == 2 && counter[8] == 0 && counter[15] == 1,
          "AES-CTR carries from low 64 bits into high 64 bits");
    CHECK(oc_ctr_xor(&ciphers[4], NULL, NULL, 0, counter) == 0,
          "AES-CTR accepts an empty message");
    for (i = 0; i < sizeof(lengths) / sizeof(lengths[0]); ++i) {
        size_t len = lengths[i];
        memcpy(counter, initial, 16);
        CHECK(oc_ctr_xor(&ciphers[4], output, plain, len, counter) == 0,
              "AES-CTR short-message encryption");
        memcpy(back, output, len);
        memcpy(counter, initial, 16);
        CHECK(oc_ctr_xor(&ciphers[4], back, back, len, counter) == 0 &&
              memcmp(back, plain, len) == 0,
              "AES-CTR short-message in-place round trip");
    }
}

static void test_aes128_gcm(void)
{
    uint8_t key[16] = {0}, nonce[12] = {0}, plain[64] = {0};
    uint8_t expected_ct[16], expected_tag[16], expected_empty_tag[16];
    uint8_t ct[64], ct2[64], tag[16], tag2[16], back[64];
    uint8_t untouched[64], marker[64], aad[20], nonce_long[17];
    oc_aes128_aesni_ctx ctx;
    oc_cipher cipher;

    from_hex(expected_ct, "0388dace60b6a392f328c2b971b2fe78");
    from_hex(expected_tag, "ab6e47d42cec13bdf53a67b21257bddf");
    from_hex(expected_empty_tag, "58e2fccefa7e3061367f1d57a4e7455a");
    oc_aes128_aesni_init(&ctx, key);
    cipher = oc_aes128_aesni_cipher(&ctx);

    CHECK(oc_gcm_encrypt(&cipher, NULL, NULL, 0, NULL, 0, nonce, sizeof(nonce),
                         tag, OC_GHASH_PORTABLE) == 0,
          "AES-GCM empty plaintext");
    CHECK(memcmp(tag, expected_empty_tag, 16) == 0,
          "AES-GCM empty plaintext tag");
    CHECK(oc_gcm_encrypt(&cipher, ct, plain, 16, NULL, 0, nonce,
                         sizeof(nonce), tag, OC_GHASH_PORTABLE) == 0,
          "AES-GCM portable encrypt");
    CHECK(memcmp(ct, expected_ct, 16) == 0 &&
          memcmp(tag, expected_tag, 16) == 0,
          "AES-GCM NIST vector");
    CHECK(oc_gcm_encrypt(&cipher, ct, plain, 16, NULL, 0, nonce,
                         sizeof(nonce), tag, OC_GHASH_PCLMUL) == 0 &&
          memcmp(ct, expected_ct, 16) == 0 &&
          memcmp(tag, expected_tag, 16) == 0,
          "AES-GCM PCLMUL vector");
    CHECK(oc_gcm_decrypt(&cipher, back, ct, 16, NULL, 0, nonce,
                         sizeof(nonce), tag, OC_GHASH_AUTO) == 0 &&
          memcmp(back, plain, 16) == 0,
          "AES-GCM decrypt");
    memset(untouched, 0x5a, sizeof(untouched));
    memset(marker, 0x5a, sizeof(marker));
    tag[0] ^= 1;
    CHECK(oc_gcm_decrypt(&cipher, untouched, ct, 16, NULL, 0, nonce,
                         sizeof(nonce), tag, OC_GHASH_AUTO) == -2,
          "AES-GCM rejects modified tag");
    CHECK(memcmp(untouched, marker, sizeof(marker)) == 0,
          "AES-GCM withholds unauthenticated plaintext");

    random_bytes(plain, 37);
    random_bytes(aad, 13);
    random_bytes(nonce_long, sizeof(nonce_long));
    CHECK(oc_gcm_encrypt(&cipher, ct, plain, 37, aad, 13, nonce_long,
                         sizeof(nonce_long), tag, OC_GHASH_PORTABLE) == 0,
          "AES-GCM non-96-bit nonce portable path");
    CHECK(oc_gcm_encrypt(&cipher, ct2, plain, 37, aad, 13, nonce_long,
                         sizeof(nonce_long), tag2, OC_GHASH_PCLMUL) == 0,
          "AES-GCM non-96-bit nonce PCLMUL path");
    CHECK(memcmp(ct, ct2, 37) == 0 && memcmp(tag, tag2, 16) == 0,
          "AES-GCM portable/PCLMUL differential");
    CHECK(oc_gcm_decrypt(&cipher, back, ct, 37, aad, 13, nonce_long,
                         sizeof(nonce_long), tag, OC_GHASH_AUTO) == 0 &&
          memcmp(back, plain, 37) == 0,
          "AES-GCM AAD/non-96-bit nonce round trip");
    memset(untouched, 0x5a, sizeof(untouched));
    memset(marker, 0x5a, sizeof(marker));
    ct[0] ^= 1;
    CHECK(oc_gcm_decrypt(&cipher, untouched, ct, 37, aad, 13, nonce_long,
                         sizeof(nonce_long), tag, OC_GHASH_AUTO) == -2,
          "AES-GCM rejects modified ciphertext");
    ct[0] ^= 1;
    aad[0] ^= 1;
    CHECK(oc_gcm_decrypt(&cipher, untouched, ct, 37, aad, 13, nonce_long,
                         sizeof(nonce_long), tag, OC_GHASH_AUTO) == -2,
          "AES-GCM rejects modified AAD");
    aad[0] ^= 1;
    nonce_long[0] ^= 1;
    CHECK(oc_gcm_decrypt(&cipher, untouched, ct, 37, aad, 13, nonce_long,
                         sizeof(nonce_long), tag, OC_GHASH_AUTO) == -2,
          "AES-GCM rejects modified nonce");
    nonce_long[0] ^= 1;
    tag[0] ^= 1;
    CHECK(oc_gcm_decrypt(&cipher, untouched, ct, 37, aad, 13, nonce_long,
                         sizeof(nonce_long), tag, OC_GHASH_AUTO) == -2,
          "AES-GCM rejects modified authentication tag");
    CHECK(memcmp(untouched, marker, sizeof(marker)) == 0,
          "AES-GCM never releases plaintext after authentication failure");
}

static void aes_xts_roundtrip(const oc_cipher *data, const oc_cipher *tweak,
                              size_t len)
{
    uint8_t input[513], encrypted[513], back[513], unit[16];
    random_bytes(input, len);
    random_bytes(unit, sizeof(unit));
    CHECK(oc_xts_encrypt(data, tweak, encrypted, input, len, unit) == 0,
          "AES-XTS encryption");
    CHECK(oc_xts_decrypt(data, tweak, back, encrypted, len, unit) == 0 &&
          memcmp(back, input, len) == 0,
          "AES-XTS round trip");
    memcpy(back, input, len);
    CHECK(oc_xts_encrypt(data, tweak, back, back, len, unit) == 0 &&
          oc_xts_decrypt(data, tweak, back, back, len, unit) == 0 &&
          memcmp(back, input, len) == 0,
          "AES-XTS in-place round trip");
}

static void test_aes128_xts(void)
{
    static const size_t lengths[] = {16,17,31,32,33,127,512,513};
    uint8_t key1[16], key2[16], unit[16] = {0}, plain[32], expected[32];
    uint8_t output[32], back[32], byte = 0;
    oc_aes128_ctx basic_data_ctx, basic_tweak_ctx;
    oc_aes128_ttable_ctx table_data_ctx, table_tweak_ctx;
    oc_aes128_shuffle_ctx shuffle_data_ctx, shuffle_tweak_ctx;
    oc_aes128_aesni_ctx aesni_data_ctx, aesni_tweak_ctx;
    oc_cipher data[5], tweak[5];
    size_t i, j;

    from_hex(key1, "27182818284590452353602874713526");
    from_hex(key2, "31415926535897932384626433832795");
    for (i = 0; i < sizeof(plain); ++i)
        plain[i] = (uint8_t)i;
    from_hex(expected,
             "27a7479befa1d476489f308cd4cfa6e2a"
             "96e4bbe3208ff25287dd3819616e89c");
    oc_aes128_init(&basic_data_ctx, key1);
    oc_aes128_init(&basic_tweak_ctx, key2);
    oc_aes128_ttable_init(&table_data_ctx, key1);
    oc_aes128_ttable_init(&table_tweak_ctx, key2);
    oc_aes128_shuffle_init(&shuffle_data_ctx, key1);
    oc_aes128_shuffle_init(&shuffle_tweak_ctx, key2);
    oc_aes128_aesni_init(&aesni_data_ctx, key1);
    oc_aes128_aesni_init(&aesni_tweak_ctx, key2);
    data[0] = oc_aes128_basic_cipher(&basic_data_ctx);
    tweak[0] = oc_aes128_basic_cipher(&basic_tweak_ctx);
    data[1] = oc_aes128_ttable_cipher(&table_data_ctx);
    tweak[1] = oc_aes128_ttable_cipher(&table_tweak_ctx);
    data[2] = oc_aes128_avx2_gather_cipher(&table_data_ctx);
    tweak[2] = oc_aes128_avx2_gather_cipher(&table_tweak_ctx);
    data[3] = oc_aes128_shuffle_cipher(&shuffle_data_ctx);
    tweak[3] = oc_aes128_shuffle_cipher(&shuffle_tweak_ctx);
    data[4] = oc_aes128_aesni_cipher(&aesni_data_ctx);
    tweak[4] = oc_aes128_aesni_cipher(&aesni_tweak_ctx);

    for (j = 0; j < 5; ++j) {
        CHECK(oc_xts_encrypt(&data[j], &tweak[j], output, plain,
                             sizeof(plain), unit) == 0 &&
              memcmp(output, expected, sizeof(expected)) == 0,
              "AES-XTS independent known-answer vector");
        CHECK(oc_xts_decrypt(&data[j], &tweak[j], back, output,
                             sizeof(output), unit) == 0 &&
              memcmp(back, plain, sizeof(plain)) == 0,
              "AES-XTS known-answer decryption");
        for (i = 0; i < sizeof(lengths) / sizeof(lengths[0]); ++i)
            aes_xts_roundtrip(&data[j], &tweak[j], lengths[i]);
    }
    CHECK(oc_xts_encrypt(&data[4], &tweak[4], &byte, &byte, 15, unit) == -1,
          "AES-XTS rejects data shorter than one block");
}

static void test_sm4(void)
{
    uint8_t key[16], plain[16], expected[16], out[16], back[16];
    uint8_t input[16 * 16], basic_out[sizeof(input)], table_out[sizeof(input)];
    uint8_t avx_out[sizeof(input)], shuffle_out[sizeof(input)];
    oc_sm4_ctx basic_ctx;
    oc_sm4_ttable_ctx opt_ctx;
    oc_sm4_shuffle_ctx shuffle_ctx;
    oc_cipher basic, table, avx, shuffle;

    from_hex(key, "0123456789abcdeffedcba9876543210");
    memcpy(plain, key, 16);
    from_hex(expected, "681edf34d206965e86b3e94f536e4246");
    oc_sm4_init(&basic_ctx, key);
    oc_sm4_ttable_init(&opt_ctx, key);
    oc_sm4_shuffle_init(&shuffle_ctx, key);
    basic = oc_sm4_basic_cipher(&basic_ctx);
    table = oc_sm4_ttable_cipher(&opt_ctx);
    avx = oc_sm4_avx2_cipher(&opt_ctx);
    shuffle = oc_sm4_shuffle_cipher(&shuffle_ctx);
    basic.encrypt_blocks(basic.ctx, out, plain, 1);
    CHECK(memcmp(out, expected, 16) == 0, "SM4 standard encryption vector");
    table.encrypt_blocks(table.ctx, out, plain, 1);
    CHECK(memcmp(out, expected, 16) == 0, "SM4 T-table vector");
    avx.encrypt_blocks(avx.ctx, out, plain, 1);
    CHECK(memcmp(out, expected, 16) == 0, "SM4 AVX2 vector/fallback");
    shuffle.encrypt_blocks(shuffle.ctx, out, plain, 1);
    CHECK(memcmp(out, expected, 16) == 0, "SM4 AVX2 shuffle vector/fallback");
    table.decrypt_blocks(table.ctx, back, expected, 1);
    CHECK(memcmp(back, plain, 16) == 0, "SM4 decryption vector");
    shuffle.decrypt_blocks(shuffle.ctx, back, expected, 1);
    CHECK(memcmp(back, plain, 16) == 0, "SM4 shuffle decryption vector");

    random_bytes(input, sizeof(input));
    basic.encrypt_blocks(basic.ctx, basic_out, input, 16);
    table.encrypt_blocks(table.ctx, table_out, input, 16);
    avx.encrypt_blocks(avx.ctx, avx_out, input, 16);
    shuffle.encrypt_blocks(shuffle.ctx, shuffle_out, input, 16);
    CHECK(memcmp(basic_out, table_out, sizeof(input)) == 0,
          "SM4 basic/T-table differential");
    CHECK(memcmp(basic_out, avx_out, sizeof(input)) == 0,
          "SM4 basic/AVX2 differential");
    CHECK(memcmp(basic_out, shuffle_out, sizeof(input)) == 0,
          "SM4 basic/AVX2-shuffle differential");
    avx.decrypt_blocks(avx.ctx, avx_out, avx_out, 16);
    CHECK(memcmp(input, avx_out, sizeof(input)) == 0,
          "SM4 AVX2 in-place decrypt");
    shuffle.decrypt_blocks(shuffle.ctx, shuffle_out, shuffle_out, 16);
    CHECK(memcmp(input, shuffle_out, sizeof(input)) == 0,
          "SM4 shuffle in-place decrypt");
}

static void test_gift128(void)
{
    uint8_t key[16] = {0}, plain[16] = {0}, expected[16], out[16], back[16];
    uint8_t input[16 * 8], ref_out[sizeof(input)], table_out[sizeof(input)];
    uint8_t avx_out[sizeof(input)], fix_out[sizeof(input)], avx_fix_out[sizeof(input)];
    oc_gift128_ctx basic_ctx;
    oc_gift128_ttable_ctx table_ctx;
    oc_gift128_fix_ctx fix_ctx;
    oc_cipher basic, table, avx, fix, avx_fix;

    from_hex(expected, "cd0bd738388ad3f668b15a36ceb6ff92");
    oc_gift128_init(&basic_ctx, key);
    oc_gift128_ttable_init(&table_ctx, key);
    oc_gift128_fix_init(&fix_ctx, key);
    basic = oc_gift128_basic_cipher(&basic_ctx);
    table = oc_gift128_ttable_cipher(&table_ctx);
    avx = oc_gift128_avx2_cipher(&basic_ctx);
    fix = oc_gift128_fix_cipher(&fix_ctx);
    avx_fix = oc_gift128_avx2_fix_cipher(&fix_ctx);
    basic.encrypt_blocks(basic.ctx, out, plain, 1);
    CHECK(memcmp(out, expected, 16) == 0, "GIFT-128 official vector");
    table.encrypt_blocks(table.ctx, out, plain, 1);
    CHECK(memcmp(out, expected, 16) == 0, "GIFT-128 T-table vector");
    avx.encrypt_blocks(avx.ctx, out, plain, 1);
    CHECK(memcmp(out, expected, 16) == 0, "GIFT-128 AVX2 shuffle vector");
    fix.encrypt_blocks(fix.ctx, out, plain, 1);
    CHECK(memcmp(out, expected, 16) == 0, "GIFT-128 fixsliced vector");
    avx_fix.encrypt_blocks(avx_fix.ctx, out, plain, 1);
    CHECK(memcmp(out, expected, 16) == 0, "GIFT-128 AVX2 fixsliced vector");
    fix.decrypt_blocks(fix.ctx, back, expected, 1);
    CHECK(memcmp(back, plain, 16) == 0, "GIFT-128 fixsliced decrypt vector");
    avx_fix.decrypt_blocks(avx_fix.ctx, back, expected, 1);
    CHECK(memcmp(back, plain, 16) == 0, "GIFT-128 AVX2 fixsliced decrypt vector");

    from_hex(key, "fedcba9876543210fedcba9876543210");
    from_hex(plain, "fedcba9876543210fedcba9876543210");
    from_hex(expected, "8422241a6dbf5a9346af468409ee0152");
    oc_gift128_init(&basic_ctx, key);
    oc_gift128_ttable_init(&table_ctx, key);
    oc_gift128_fix_init(&fix_ctx, key);
    basic.encrypt_blocks(basic.ctx, out, plain, 1);
    CHECK(memcmp(out, expected, 16) == 0, "GIFT-128 nonzero-key vector");
    table.encrypt_blocks(table.ctx, out, plain, 1);
    CHECK(memcmp(out, expected, 16) == 0, "GIFT-128 T-table nonzero-key vector");
    avx.encrypt_blocks(avx.ctx, out, plain, 1);
    CHECK(memcmp(out, expected, 16) == 0, "GIFT-128 AVX2 nonzero-key vector");
    fix.encrypt_blocks(fix.ctx, out, plain, 1);
    CHECK(memcmp(out, expected, 16) == 0, "GIFT-128 fixsliced nonzero-key vector");
    avx_fix.encrypt_blocks(avx_fix.ctx, out, plain, 1);
    CHECK(memcmp(out, expected, 16) == 0, "GIFT-128 AVX2 fixsliced nonzero-key vector");

    random_bytes(input, sizeof(input));
    basic.encrypt_blocks(basic.ctx, ref_out, input, 8);
    table.encrypt_blocks(table.ctx, table_out, input, 8);
    avx.encrypt_blocks(avx.ctx, avx_out, input, 8);
    fix.encrypt_blocks(fix.ctx, fix_out, input, 8);
    avx_fix.encrypt_blocks(avx_fix.ctx, avx_fix_out, input, 8);
    CHECK(memcmp(ref_out, table_out, sizeof(input)) == 0,
          "GIFT-128 basic/T-table differential");
    CHECK(memcmp(ref_out, avx_out, sizeof(input)) == 0,
          "GIFT-128 basic/AVX2 differential");
    CHECK(memcmp(ref_out, fix_out, sizeof(input)) == 0,
          "GIFT-128 basic/fixsliced differential");
    CHECK(memcmp(ref_out, avx_fix_out, sizeof(input)) == 0,
          "GIFT-128 basic/AVX2-fixsliced differential");
    table.decrypt_blocks(table.ctx, back, table_out, 1);
    CHECK(memcmp(back, input, 16) == 0, "GIFT-128 T-table decrypt adapter");
    avx.decrypt_blocks(avx.ctx, avx_out, avx_out, 8);
    CHECK(memcmp(avx_out, input, sizeof(input)) == 0,
          "GIFT-128 AVX2 in-place decrypt");
    avx_fix.decrypt_blocks(avx_fix.ctx, avx_fix_out, avx_fix_out, 8);
    CHECK(memcmp(avx_fix_out, input, sizeof(input)) == 0,
          "GIFT-128 AVX2-fixsliced in-place decrypt");
}

static void test_twine80(void)
{
    uint8_t key[10], plain[8], expected[8], out[8], back[8];
    uint8_t input[8 * 10], ref_out[sizeof(input)], table_out[sizeof(input)];
    uint8_t avx_out[sizeof(input)], fix_out[sizeof(input)], gather_out[sizeof(input)];
    oc_twine80_ctx basic_ctx;
    oc_twine80_ttable_ctx table_ctx;
    oc_twine80_fix_ctx fix_ctx;
    oc_cipher basic, table, avx, fix, gather;

    from_hex(key, "00112233445566778899");
    from_hex(plain, "0123456789abcdef");
    from_hex(expected, "7c1f0f80b1df9c28");
    oc_twine80_init(&basic_ctx, key);
    oc_twine80_ttable_init(&table_ctx, key);
    oc_twine80_fix_init(&fix_ctx, key);
    basic = oc_twine80_basic_cipher(&basic_ctx);
    table = oc_twine80_ttable_cipher(&table_ctx);
    avx = oc_twine80_avx2_cipher(&basic_ctx);
    fix = oc_twine80_fix_cipher(&fix_ctx);
    gather = oc_twine80_avx2_gather_cipher(&table_ctx);
    basic.encrypt_blocks(basic.ctx, out, plain, 1);
    CHECK(memcmp(out, expected, 8) == 0, "TWINE-80 paper vector");
    table.encrypt_blocks(table.ctx, out, plain, 1);
    CHECK(memcmp(out, expected, 8) == 0, "TWINE-80 T-table vector");
    avx.encrypt_blocks(avx.ctx, out, plain, 1);
    CHECK(memcmp(out, expected, 8) == 0, "TWINE-80 AVX2 vector/fallback");
    fix.encrypt_blocks(fix.ctx, out, plain, 1);
    CHECK(memcmp(out, expected, 8) == 0, "TWINE-80 fixsliced vector");
    gather.encrypt_blocks(gather.ctx, out, plain, 1);
    CHECK(memcmp(out, expected, 8) == 0, "TWINE-80 AVX2 gather vector/fallback");
    table.decrypt_blocks(table.ctx, back, expected, 1);
    CHECK(memcmp(back, plain, 8) == 0, "TWINE-80 T-table decrypt vector");
    fix.decrypt_blocks(fix.ctx, back, expected, 1);
    CHECK(memcmp(back, plain, 8) == 0, "TWINE-80 fixsliced decrypt vector");
    gather.decrypt_blocks(gather.ctx, back, expected, 1);
    CHECK(memcmp(back, plain, 8) == 0, "TWINE-80 AVX2 gather decrypt vector");

    random_bytes(input, sizeof(input));
    basic.encrypt_blocks(basic.ctx, ref_out, input, 10);
    table.encrypt_blocks(table.ctx, table_out, input, 10);
    avx.encrypt_blocks(avx.ctx, avx_out, input, 10);
    fix.encrypt_blocks(fix.ctx, fix_out, input, 10);
    gather.encrypt_blocks(gather.ctx, gather_out, input, 10);
    CHECK(memcmp(ref_out, table_out, sizeof(input)) == 0,
          "TWINE-80 basic/T-table differential");
    CHECK(memcmp(ref_out, avx_out, sizeof(input)) == 0,
          "TWINE-80 basic/AVX2 differential");
    CHECK(memcmp(ref_out, fix_out, sizeof(input)) == 0,
          "TWINE-80 basic/fixsliced differential");
    CHECK(memcmp(ref_out, gather_out, sizeof(input)) == 0,
          "TWINE-80 basic/AVX2-gather differential");
    avx.decrypt_blocks(avx.ctx, avx_out, avx_out, 10);
    CHECK(memcmp(input, avx_out, sizeof(input)) == 0,
          "TWINE-80 AVX2 in-place decrypt");
    fix.decrypt_blocks(fix.ctx, fix_out, fix_out, 10);
    CHECK(memcmp(input, fix_out, sizeof(input)) == 0,
          "TWINE-80 fixsliced in-place decrypt");
    gather.decrypt_blocks(gather.ctx, gather_out, gather_out, 10);
    CHECK(memcmp(input, gather_out, sizeof(input)) == 0,
          "TWINE-80 AVX2-gather in-place decrypt");
}

static void identity_blocks(const void *ctx, uint8_t *out,
                            const uint8_t *in, size_t blocks)
{
    size_t block_size = *(const size_t *)ctx;
    memmove(out, in, blocks * block_size);
}

static void test_ctr(void)
{
    uint8_t input[333], encrypted[333], back[333], key16[16], key10[10];
    uint8_t counter[16], initial[16];
    size_t identity_size = 16;
    oc_cipher identity = {&identity_size, 16, identity_blocks, identity_blocks,
                          "identity-test"};
    oc_sm4_ttable_ctx sm4;
    oc_gift128_fix_ctx gift;
    oc_twine80_ctx twine;
    oc_cipher ciphers[3];
    size_t i;

    memset(input, 0, sizeof(input));
    memset(counter, 0, sizeof(counter));
    counter[15] = 0xfe;
    CHECK(oc_ctr_xor(&identity, encrypted, input, 20, counter) == 0,
          "CTR identity execution");
    CHECK(encrypted[15] == 0xfe && encrypted[16] == 0 && encrypted[19] == 0,
          "CTR emits current big-endian counter before increment");
    CHECK(counter[14] == 1 && counter[15] == 0,
          "CTR carries over big-endian counter");

    random_bytes(input, sizeof(input));
    random_bytes(key16, sizeof(key16));
    random_bytes(key10, sizeof(key10));
    oc_sm4_ttable_init(&sm4, key16);
    oc_gift128_fix_init(&gift, key16);
    oc_twine80_init(&twine, key10);
    ciphers[0] = oc_sm4_avx2_cipher(&sm4);
    ciphers[1] = oc_gift128_fix_cipher(&gift);
    ciphers[2] = oc_twine80_avx2_cipher(&twine);
    for (i = 0; i < 3; ++i) {
        memset(initial, 0xa5, ciphers[i].block_size);
        memcpy(counter, initial, ciphers[i].block_size);
        CHECK(oc_ctr_xor(&ciphers[i], encrypted, input, sizeof(input), counter) == 0,
              "CTR encrypt for each cipher");
        memcpy(counter, initial, ciphers[i].block_size);
        CHECK(oc_ctr_xor(&ciphers[i], back, encrypted, sizeof(input), counter) == 0,
              "CTR decrypt for each cipher");
        CHECK(memcmp(input, back, sizeof(input)) == 0,
              "CTR round trip for each cipher");
    }
}

static void test_ghash(void)
{
    uint8_t x[16], h[16], portable[16], accelerated[16];
    size_t i;
    for (i = 0; i < 200; ++i) {
        random_bytes(x, sizeof(x));
        random_bytes(h, sizeof(h));
        oc_ghash_multiply(portable, x, h, OC_GHASH_PORTABLE);
        oc_ghash_multiply(accelerated, x, h, OC_GHASH_PCLMUL);
        CHECK(memcmp(portable, accelerated, 16) == 0,
              "portable/PCLMUL GHASH differential");
        if (failures)
            break;
    }
}

static void test_sm4_gcm_rfc8998(void)
{
    uint8_t key[16], nonce[12], plain[64], aad[20], expected_ct[64];
    uint8_t expected_tag[16], ct[64], ct2[64], tag[16], tag2[16];
    uint8_t back[64], untouched[64], nonce_long[17];
    oc_sm4_ttable_ctx ctx;
    oc_cipher cipher;

    from_hex(key, "0123456789abcdeffedcba9876543210");
    from_hex(nonce, "00001234567800000000abcd");
    from_hex(plain,
             "aaaaaaaaaaaaaaaabbbbbbbbbbbbbbbbccccccccccccccccdddddddddddddddd"
             "eeeeeeeeeeeeeeeeffffffffffffffffeeeeeeeeeeeeeeeeaaaaaaaaaaaaaaaa");
    from_hex(aad, "feedfacedeadbeeffeedfacedeadbeefabaddad2");
    from_hex(expected_ct,
             "17f399f08c67d5ee19d0dc9969c4bb7d5fd46fd3756489069157b282bb200735"
             "d82710ca5c22f0ccfa7cbf93d496ac15a56834cbcf98c397b4024a2691233b8d");
    from_hex(expected_tag, "83de3541e4c2b58177e065a9bf7b62ec");
    oc_sm4_ttable_init(&ctx, key);
    cipher = oc_sm4_avx2_cipher(&ctx);

    CHECK(oc_gcm_encrypt(&cipher, ct, plain, sizeof(plain), aad, sizeof(aad),
                         nonce, sizeof(nonce), tag, OC_GHASH_PORTABLE) == 0,
          "RFC 8998 GCM portable encrypt");
    CHECK(memcmp(ct, expected_ct, sizeof(ct)) == 0, "RFC 8998 ciphertext");
    CHECK(memcmp(tag, expected_tag, sizeof(tag)) == 0, "RFC 8998 tag");
    CHECK(oc_gcm_encrypt(&cipher, ct, plain, sizeof(plain), aad, sizeof(aad),
                         nonce, sizeof(nonce), tag, OC_GHASH_PCLMUL) == 0,
          "RFC 8998 GCM PCLMUL encrypt");
    CHECK(memcmp(ct, expected_ct, sizeof(ct)) == 0,
          "RFC 8998 PCLMUL ciphertext");
    CHECK(memcmp(tag, expected_tag, sizeof(tag)) == 0, "RFC 8998 PCLMUL tag");
    CHECK(oc_gcm_decrypt(&cipher, back, ct, sizeof(ct), aad, sizeof(aad),
                         nonce, sizeof(nonce), tag, OC_GHASH_AUTO) == 0,
          "RFC 8998 GCM decrypt");
    CHECK(memcmp(back, plain, sizeof(back)) == 0, "RFC 8998 plaintext recovery");

    memset(untouched, 0x5a, sizeof(untouched));
    tag[0] ^= 1;
    CHECK(oc_gcm_decrypt(&cipher, untouched, ct, sizeof(ct), aad, sizeof(aad),
                         nonce, sizeof(nonce), tag, OC_GHASH_AUTO) == -2,
          "GCM rejects modified tag");
    memset(back, 0x5a, sizeof(back));
    CHECK(memcmp(untouched, back, sizeof(back)) == 0,
          "GCM does not release plaintext before authentication");

    random_bytes(plain, 37);
    random_bytes(aad, 13);
    random_bytes(nonce_long, sizeof(nonce_long));
    CHECK(oc_gcm_encrypt(&cipher, ct, plain, 37, aad, 13, nonce_long,
                         sizeof(nonce_long), tag, OC_GHASH_PORTABLE) == 0,
          "GCM non-96-bit nonce portable path");
    CHECK(oc_gcm_encrypt(&cipher, ct2, plain, 37, aad, 13, nonce_long,
                         sizeof(nonce_long), tag2, OC_GHASH_PCLMUL) == 0,
          "GCM non-96-bit nonce PCLMUL path");
    CHECK(memcmp(ct, ct2, 37) == 0 && memcmp(tag, tag2, 16) == 0,
          "GCM non-96-bit nonce implementation differential");
    CHECK(oc_gcm_decrypt(&cipher, back, ct, 37, aad, 13, nonce_long,
                         sizeof(nonce_long), tag, OC_GHASH_AUTO) == 0 &&
          memcmp(back, plain, 37) == 0,
          "GCM non-96-bit nonce round trip");
}

static void xts_roundtrip(const oc_cipher *data, const oc_cipher *tweak,
                          size_t len)
{
    uint8_t input[513], encrypted[513], back[513], unit[16];
    random_bytes(input, len);
    random_bytes(unit, sizeof(unit));
    CHECK(oc_xts_encrypt(data, tweak, encrypted, input, len, unit) == 0,
          "XTS encryption");
    CHECK(memcmp(input, encrypted, len) != 0, "XTS changes nonempty data");
    CHECK(oc_xts_decrypt(data, tweak, back, encrypted, len, unit) == 0,
          "XTS decryption");
    CHECK(memcmp(input, back, len) == 0, "XTS round trip");
    memcpy(back, input, len);
    CHECK(oc_xts_encrypt(data, tweak, back, back, len, unit) == 0,
          "XTS in-place encryption");
    CHECK(oc_xts_decrypt(data, tweak, back, back, len, unit) == 0,
          "XTS in-place decryption");
    CHECK(memcmp(input, back, len) == 0, "XTS in-place round trip");
}

static void test_xts(void)
{
    uint8_t key1[16], key2[16], twine_key[10], unit[16] = {0}, byte = 0;
    oc_sm4_ttable_ctx sm4_data, sm4_tweak;
    oc_gift128_fix_ctx gift_data, gift_tweak;
    oc_twine80_ctx twine_ctx;
    oc_cipher sm4c1, sm4c2, giftc1, giftc2, twine;
    static const size_t lengths[] = {16,17,31,32,33,127,512,513};
    size_t i;
    random_bytes(key1, sizeof(key1));
    random_bytes(key2, sizeof(key2));
    random_bytes(twine_key, sizeof(twine_key));
    oc_sm4_ttable_init(&sm4_data, key1);
    oc_sm4_ttable_init(&sm4_tweak, key2);
    oc_gift128_fix_init(&gift_data, key1);
    oc_gift128_fix_init(&gift_tweak, key2);
    oc_twine80_init(&twine_ctx, twine_key);
    sm4c1 = oc_sm4_avx2_cipher(&sm4_data);
    sm4c2 = oc_sm4_avx2_cipher(&sm4_tweak);
    giftc1 = oc_gift128_fix_cipher(&gift_data);
    giftc2 = oc_gift128_fix_cipher(&gift_tweak);
    twine = oc_twine80_avx2_cipher(&twine_ctx);
    for (i = 0; i < sizeof(lengths) / sizeof(lengths[0]); ++i)
        xts_roundtrip(&sm4c1, &sm4c2, lengths[i]);
    xts_roundtrip(&giftc1, &giftc2, 33);
    CHECK(oc_xts_encrypt(&sm4c1, &sm4c2, &byte, &byte, 15, unit) == -1,
          "XTS rejects data units shorter than one block");
    CHECK(oc_xts_encrypt(&twine, &twine, &byte, &byte, 16, unit) == -1,
          "XTS rejects 64-bit block ciphers");
    CHECK(oc_gcm_encrypt(&twine, &byte, &byte, 1, NULL, 0, unit, 12,
                         unit, OC_GHASH_AUTO) == -1,
          "GCM rejects 64-bit block ciphers");
}

static void test_gcm64(void)
{
    uint8_t key[10], nonce[8], plain[64], aad[20], ct[64], ct2[64];
    uint8_t tag[8], tag2[8], back[64], untouched[64], nonce_long[13];
    oc_twine80_ttable_ctx ctx1, ctx2;
    oc_cipher twine1, twine2;

    /* Test basic GCM-64 encryption/decryption */
    random_bytes(key, sizeof(key));
    random_bytes(nonce, sizeof(nonce));
    random_bytes(plain, sizeof(plain));
    random_bytes(aad, sizeof(aad));

    oc_twine80_ttable_init(&ctx1, key);
    twine1 = oc_twine80_ttable_cipher(&ctx1);

    CHECK(oc_gcm64_encrypt(&twine1, ct, plain, sizeof(plain), aad, sizeof(aad),
                           nonce, sizeof(nonce), tag) == 0,
          "GCM-64 encryption with TWINE");
    CHECK(oc_gcm64_decrypt(&twine1, back, ct, sizeof(ct), aad, sizeof(aad),
                           nonce, sizeof(nonce), tag) == 0,
          "GCM-64 decryption with TWINE");
    CHECK(memcmp(back, plain, sizeof(plain)) == 0,
          "GCM-64 plaintext recovery");

    /* Test tag authentication */
    memset(untouched, 0x5a, sizeof(untouched));
    tag[0] ^= 1;
    CHECK(oc_gcm64_decrypt(&twine1, untouched, ct, sizeof(ct), aad, sizeof(aad),
                           nonce, sizeof(nonce), tag) == -2,
          "GCM-64 rejects modified tag");
    memset(back, 0x5a, sizeof(back));
    CHECK(memcmp(untouched, back, sizeof(back)) == 0,
          "GCM-64 does not release plaintext before authentication");

    /* Test with non-standard nonce length */
    tag[0] ^= 1;  /* Restore tag */
    random_bytes(nonce_long, sizeof(nonce_long));
    CHECK(oc_gcm64_encrypt(&twine1, ct, plain, 37, aad, 13, nonce_long,
                           sizeof(nonce_long), tag) == 0,
          "GCM-64 non-64-bit nonce");
    CHECK(oc_gcm64_decrypt(&twine1, back, ct, 37, aad, 13, nonce_long,
                           sizeof(nonce_long), tag) == 0 &&
          memcmp(back, plain, 37) == 0,
          "GCM-64 non-64-bit nonce round trip");

    /* Test empty plaintext */
    CHECK(oc_gcm64_encrypt(&twine1, NULL, NULL, 0, aad, sizeof(aad),
                           nonce, sizeof(nonce), tag) == 0,
          "GCM-64 empty plaintext");
    CHECK(oc_gcm64_decrypt(&twine1, NULL, NULL, 0, aad, sizeof(aad),
                           nonce, sizeof(nonce), tag) == 0,
          "GCM-64 empty plaintext decryption");

    /* Test with different cipher instances (differential) */
    oc_twine80_ttable_init(&ctx2, key);
    twine2 = oc_twine80_ttable_cipher(&ctx2);
    random_bytes(nonce, sizeof(nonce));  /* Fresh nonce for comparison */
    CHECK(oc_gcm64_encrypt(&twine1, ct, plain, sizeof(plain), aad, sizeof(aad),
                           nonce, sizeof(nonce), tag) == 0,
          "GCM-64 encryption 1");
    CHECK(oc_gcm64_encrypt(&twine2, ct2, plain, sizeof(plain), aad, sizeof(aad),
                           nonce, sizeof(nonce), tag2) == 0,
          "GCM-64 encryption 2");
    CHECK(memcmp(ct, ct2, sizeof(ct)) == 0 && memcmp(tag, tag2, 8) == 0,
          "GCM-64 produces identical output with same key and nonce");
}

static void xts64_roundtrip(const oc_cipher *data, const oc_cipher *tweak,
                            size_t len)
{
    uint8_t input[513], encrypted[513], back[513], unit[8];
    random_bytes(input, len);
    random_bytes(unit, sizeof(unit));
    CHECK(oc_xts64_encrypt(data, tweak, encrypted, input, len, unit) == 0,
          "XTS-64 encryption");
    if (len > 0)
        CHECK(memcmp(input, encrypted, len) != 0, "XTS-64 changes nonempty data");
    CHECK(oc_xts64_decrypt(data, tweak, back, encrypted, len, unit) == 0,
          "XTS-64 decryption");
    CHECK(memcmp(input, back, len) == 0, "XTS-64 round trip");
    memcpy(back, input, len);
    CHECK(oc_xts64_encrypt(data, tweak, back, back, len, unit) == 0,
          "XTS-64 in-place encryption");
    CHECK(oc_xts64_decrypt(data, tweak, back, back, len, unit) == 0,
          "XTS-64 in-place decryption");
    CHECK(memcmp(input, back, len) == 0, "XTS-64 in-place round trip");
}

static void test_xts64(void)
{
    uint8_t key1[10], key2[10], unit[8] = {0}, byte = 0;
    oc_twine80_ttable_ctx twine_data, twine_tweak;
    oc_cipher twine1, twine2;
    static const size_t lengths[] = {8,9,15,16,17,63,64,65,127,256,257};
    size_t i;

    random_bytes(key1, sizeof(key1));
    random_bytes(key2, sizeof(key2));
    oc_twine80_ttable_init(&twine_data, key1);
    oc_twine80_ttable_init(&twine_tweak, key2);
    twine1 = oc_twine80_ttable_cipher(&twine_data);
    twine2 = oc_twine80_ttable_cipher(&twine_tweak);

    for (i = 0; i < sizeof(lengths) / sizeof(lengths[0]); ++i)
        xts64_roundtrip(&twine1, &twine2, lengths[i]);

    CHECK(oc_xts64_encrypt(&twine1, &twine2, &byte, &byte, 7, unit) == -1,
          "XTS-64 rejects data units shorter than one block");
}

int main(void)
{
    printf("CPU features: AVX2=%s, PCLMUL=%s, SSSE3=%s, AES-NI=%s\n",
           oc_cpu_has_avx2() ? "yes" : "no",
           oc_cpu_has_pclmul() ? "yes" : "no",
           oc_cpu_has_ssse3() ? "yes" : "no",
           oc_cpu_has_aesni() ? "yes" : "no");
    test_aes128();
    test_aes128_ctr();
    test_aes128_gcm();
    test_aes128_xts();
    test_sm4();
    test_gift128();
    test_twine80();
    test_ctr();
    test_ghash();
    test_sm4_gcm_rfc8998();
    test_xts();
    test_gcm64();
    test_xts64();
    if (failures) {
        fprintf(stderr, "%d test(s) failed\n", failures);
        return EXIT_FAILURE;
    }
    printf("All tests passed.\n");
    return EXIT_SUCCESS;
}
