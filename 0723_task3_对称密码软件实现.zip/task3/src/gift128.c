#include "optcrypto.h"
#include "internal.h"

#include <string.h>

#if OC_X86
#include <immintrin.h>
#endif

static const uint8_t gift_sbox[16] = {
    0x1,0xa,0x4,0xc,0x6,0xf,0x3,0x9,0x2,0xd,0xb,0x7,0x5,0x0,0x8,0xe
};

static const uint8_t gift_inv_sbox[16] = {
    0xd,0x0,0x8,0x6,0x2,0xc,0x4,0xb,0xe,0x7,0x1,0xa,0x3,0x9,0xf,0x5
};

static const uint8_t gift_perm[128] = {
      0, 33, 66, 99, 96,  1, 34, 67, 64, 97,  2, 35, 32, 65, 98,  3,
      4, 37, 70,103,100,  5, 38, 71, 68,101,  6, 39, 36, 69,102,  7,
      8, 41, 74,107,104,  9, 42, 75, 72,105, 10, 43, 40, 73,106, 11,
     12, 45, 78,111,108, 13, 46, 79, 76,109, 14, 47, 44, 77,110, 15,
     16, 49, 82,115,112, 17, 50, 83, 80,113, 18, 51, 48, 81,114, 19,
     20, 53, 86,119,116, 21, 54, 87, 84,117, 22, 55, 52, 85,118, 23,
     24, 57, 90,123,120, 25, 58, 91, 88,121, 26, 59, 56, 89,122, 27,
     28, 61, 94,127,124, 29, 62, 95, 92,125, 30, 63, 60, 93,126, 31
};

static const uint8_t gift_rc[40] = {
    0x01,0x03,0x07,0x0f,0x1f,0x3e,0x3d,0x3b,0x37,0x2f,
    0x1e,0x3c,0x39,0x33,0x27,0x0e,0x1d,0x3a,0x35,0x2b,
    0x16,0x2c,0x18,0x30,0x21,0x02,0x05,0x0b,0x17,0x2e,
    0x1c,0x38,0x31,0x23,0x06,0x0d,0x1b,0x36,0x2d,0x1a
};

static void gift_bytes_to_nibbles(uint8_t n[32], const uint8_t in[16])
{
    size_t i;
    for (i = 0; i < 32; ++i) {
        uint8_t b = in[15 - i / 2];
        n[i] = (uint8_t)((i & 1U) ? (b >> 4) : (b & 0x0f));
    }
}

static void gift_nibbles_to_bytes(uint8_t out[16], const uint8_t n[32])
{
    size_t i;
    for (i = 0; i < 16; ++i)
        out[15 - i] = (uint8_t)((n[2 * i + 1] << 4) | n[2 * i]);
}

static void gift_key_update(uint8_t key[32])
{
    uint8_t tmp[32];
    size_t i;
    for (i = 0; i < 32; ++i)
        tmp[i] = key[(i + 8) & 31U];
    for (i = 0; i < 24; ++i)
        key[i] = tmp[i];
    key[24] = tmp[27];
    key[25] = tmp[24];
    key[26] = tmp[25];
    key[27] = tmp[26];
    key[28] = (uint8_t)(((tmp[28] & 0xc) >> 2) | ((tmp[29] & 0x3) << 2));
    key[29] = (uint8_t)(((tmp[29] & 0xc) >> 2) | ((tmp[30] & 0x3) << 2));
    key[30] = (uint8_t)(((tmp[30] & 0xc) >> 2) | ((tmp[31] & 0x3) << 2));
    key[31] = (uint8_t)(((tmp[31] & 0xc) >> 2) | ((tmp[28] & 0x3) << 2));
}

void oc_gift128_init(oc_gift128_ctx *ctx, const uint8_t key_bytes[16])
{
    uint8_t key[32];
    size_t r, i;
    gift_bytes_to_nibbles(key, key_bytes);
    for (r = 0; r < 40; ++r) {
        memset(ctx->round_mask[r], 0, 32);
        for (i = 0; i < 32; ++i) {
            uint8_t u = (uint8_t)((key[i / 4] >> (i & 3U)) & 1U);
            uint8_t v = (uint8_t)((key[16 + i / 4] >> (i & 3U)) & 1U);
            ctx->round_mask[r][i] = (uint8_t)((u << 1) | (v << 2));
        }
        for (i = 0; i < 6; ++i)
            ctx->round_mask[r][i] ^= (uint8_t)(((gift_rc[r] >> i) & 1U) << 3);
        ctx->round_mask[r][31] ^= 8;
        gift_key_update(key);
    }
}

static void gift_permute(uint8_t out[32], const uint8_t in[32])
{
    size_t i, bit;
    memset(out, 0, 32);
    for (i = 0; i < 32; ++i)
        for (bit = 0; bit < 4; ++bit) {
            size_t dst = gift_perm[4 * i + bit];
            out[dst / 4] |= (uint8_t)(((in[i] >> bit) & 1U) << (dst & 3U));
        }
}

static void gift_inv_permute(uint8_t out[32], const uint8_t in[32])
{
    size_t i, bit;
    memset(out, 0, 32);
    for (i = 0; i < 32; ++i)
        for (bit = 0; bit < 4; ++bit) {
            size_t src = gift_perm[4 * i + bit];
            out[i] |= (uint8_t)(((in[src / 4] >> (src & 3U)) & 1U) << bit);
        }
}

static void gift_basic_one(const oc_gift128_ctx *ctx, uint8_t *out,
                           const uint8_t *in, int decrypt)
{
    uint8_t state[32], tmp[32];
    size_t r, i;
    gift_bytes_to_nibbles(state, in);
    if (!decrypt) {
        for (r = 0; r < 40; ++r) {
            for (i = 0; i < 32; ++i)
                state[i] = gift_sbox[state[i]];
            gift_permute(tmp, state);
            for (i = 0; i < 32; ++i)
                state[i] = tmp[i] ^ ctx->round_mask[r][i];
        }
    } else {
        for (r = 40; r-- > 0;) {
            for (i = 0; i < 32; ++i)
                state[i] ^= ctx->round_mask[r][i];
            gift_inv_permute(tmp, state);
            for (i = 0; i < 32; ++i)
                state[i] = gift_inv_sbox[tmp[i]];
        }
    }
    gift_nibbles_to_bytes(out, state);
}

static void gift_basic_encrypt(const void *vctx, uint8_t *out,
                               const uint8_t *in, size_t blocks)
{
    const oc_gift128_ctx *ctx = (const oc_gift128_ctx *)vctx;
    size_t i;
    for (i = 0; i < blocks; ++i)
        gift_basic_one(ctx, out + 16 * i, in + 16 * i, 0);
}

static void gift_basic_decrypt(const void *vctx, uint8_t *out,
                               const uint8_t *in, size_t blocks)
{
    const oc_gift128_ctx *ctx = (const oc_gift128_ctx *)vctx;
    size_t i;
    for (i = 0; i < blocks; ++i)
        gift_basic_one(ctx, out + 16 * i, in + 16 * i, 1);
}

void oc_gift128_ttable_init(oc_gift128_ttable_ctx *ctx,
                            const uint8_t key[16])
{
    size_t pos, value, bit, r, i;
    oc_gift128_init(&ctx->base, key);
    for (pos = 0; pos < 32; ++pos)
        for (value = 0; value < 16; ++value) {
            uint8_t packed[16] = {0};
            uint8_t s = gift_sbox[value];
            for (bit = 0; bit < 4; ++bit)
                if ((s >> bit) & 1U) {
                    size_t dst = gift_perm[4 * pos + bit];
                    packed[dst / 8] |= (uint8_t)(1U << (dst & 7U));
                }
            memcpy(ctx->table[pos][value].q, packed, sizeof(packed));
        }
    for (r = 0; r < 40; ++r) {
        uint8_t packed[16] = {0};
        for (i = 0; i < 32; ++i)
            packed[i / 2] |= (uint8_t)(ctx->base.round_mask[r][i] <<
                                       ((i & 1U) ? 4 : 0));
        memcpy(ctx->packed_mask[r], packed, sizeof(packed));
    }
}

static void gift_ttable_one(const oc_gift128_ttable_ctx *ctx, uint8_t *out,
                            const uint8_t *in)
{
    uint8_t state[16];
    size_t i, r;
    for (i = 0; i < 16; ++i)
        state[i] = in[15 - i];
    for (r = 0; r < 40; ++r) {
        uint64_t q0 = ctx->packed_mask[r][0];
        uint64_t q1 = ctx->packed_mask[r][1];
        for (i = 0; i < 32; ++i) {
            uint8_t value = (uint8_t)((state[i / 2] >>
                                      ((i & 1U) ? 4 : 0)) & 0x0f);
            q0 ^= ctx->table[i][value].q[0];
            q1 ^= ctx->table[i][value].q[1];
        }
        memcpy(state, &q0, 8);
        memcpy(state + 8, &q1, 8);
    }
    for (i = 0; i < 16; ++i)
        out[15 - i] = state[i];
}

static void gift_ttable_encrypt(const void *vctx, uint8_t *out,
                                const uint8_t *in, size_t blocks)
{
    const oc_gift128_ttable_ctx *ctx = (const oc_gift128_ttable_ctx *)vctx;
    size_t i;
    for (i = 0; i < blocks; ++i)
        gift_ttable_one(ctx, out + 16 * i, in + 16 * i);
}

static void gift_ttable_decrypt(const void *vctx, uint8_t *out,
                                const uint8_t *in, size_t blocks)
{
    const oc_gift128_ttable_ctx *ctx = (const oc_gift128_ttable_ctx *)vctx;
    size_t i;
    /* TODO: Implement optimized T-table decryption.
     * Currently falls back to basic implementation.
     * The challenge is that GIFT's bit permutation makes it difficult
     * to create efficient inverse lookup tables. */
    for (i = 0; i < blocks; ++i)
        gift_basic_one(&ctx->base, out + 16 * i, in + 16 * i, 1);
}

#if OC_X86
OC_TARGET("avx2")
static void gift_avx2_one(const oc_gift128_ctx *ctx, uint8_t *out,
                          const uint8_t *in, int decrypt)
{
    static const uint8_t sbox_lanes[32] = {
        1,10,4,12,6,15,3,9,2,13,11,7,5,0,8,14,
        1,10,4,12,6,15,3,9,2,13,11,7,5,0,8,14
    };
    static const uint8_t inv_lanes[32] = {
        13,0,8,6,2,12,4,11,14,7,1,10,3,9,15,5,
        13,0,8,6,2,12,4,11,14,7,1,10,3,9,15,5
    };
    uint8_t state[32], tmp[32];
    __m256i v, box;
    size_t r, i;
    gift_bytes_to_nibbles(state, in);
    v = _mm256_loadu_si256((const __m256i *)(const void *)state);
    if (!decrypt) {
        box = _mm256_loadu_si256((const __m256i *)(const void *)sbox_lanes);
        for (r = 0; r < 40; ++r) {
            v = _mm256_shuffle_epi8(box, v);
            _mm256_storeu_si256((__m256i *)(void *)state, v);
            gift_permute(tmp, state);
            v = _mm256_xor_si256(
                _mm256_loadu_si256((const __m256i *)(const void *)tmp),
                _mm256_loadu_si256((const __m256i *)(const void *)ctx->round_mask[r]));
        }
    } else {
        box = _mm256_loadu_si256((const __m256i *)(const void *)inv_lanes);
        for (r = 40; r-- > 0;) {
            v = _mm256_xor_si256(
                v, _mm256_loadu_si256((const __m256i *)(const void *)ctx->round_mask[r]));
            _mm256_storeu_si256((__m256i *)(void *)state, v);
            gift_inv_permute(tmp, state);
            v = _mm256_shuffle_epi8(
                box, _mm256_loadu_si256((const __m256i *)(const void *)tmp));
        }
    }
    _mm256_storeu_si256((__m256i *)(void *)state, v);
    for (i = 0; i < 32; ++i)
        state[i] &= 0x0f;
    gift_nibbles_to_bytes(out, state);
}
#endif

static void gift_avx2_crypt(const oc_gift128_ctx *ctx, uint8_t *out,
                            const uint8_t *in, size_t blocks, int decrypt)
{
    size_t i;
    for (i = 0; i < blocks; ++i) {
#if OC_X86
        if (oc_cpu_has_avx2()) {
            gift_avx2_one(ctx, out + 16 * i, in + 16 * i, decrypt);
            continue;
        }
#endif
        gift_basic_one(ctx, out + 16 * i, in + 16 * i, decrypt);
    }
}

static void gift_avx2_encrypt(const void *vctx, uint8_t *out,
                              const uint8_t *in, size_t blocks)
{
    gift_avx2_crypt((const oc_gift128_ctx *)vctx, out, in, blocks, 0);
}

static void gift_avx2_decrypt(const void *vctx, uint8_t *out,
                              const uint8_t *in, size_t blocks)
{
    gift_avx2_crypt((const oc_gift128_ctx *)vctx, out, in, blocks, 1);
}

oc_cipher oc_gift128_basic_cipher(const oc_gift128_ctx *ctx)
{
    oc_cipher c = {ctx, 16, gift_basic_encrypt, gift_basic_decrypt,
                   "GIFT-128-basic"};
    return c;
}

oc_cipher oc_gift128_ttable_cipher(const oc_gift128_ttable_ctx *ctx)
{
    oc_cipher c = {ctx, 16, gift_ttable_encrypt, gift_ttable_decrypt,
                   "GIFT-128-T-table"};
    return c;
}

oc_cipher oc_gift128_avx2_cipher(const oc_gift128_ctx *ctx)
{
    oc_cipher c = {ctx, 16, gift_avx2_encrypt, gift_avx2_decrypt,
                   "GIFT-128-AVX2-shuffle"};
    return c;
}
