#include "optcrypto.h"
#include "internal.h"

#include <limits.h>
#include <string.h>

#if OC_X86
#include <immintrin.h>
#endif

#define OC_BATCH_BLOCKS 8

static int cipher_valid(const oc_cipher *cipher)
{
    return cipher && cipher->ctx && cipher->encrypt_blocks &&
           cipher->block_size > 0 && cipher->block_size <= 16;
}

static void increment_be(uint8_t *counter, size_t len)
{
    while (len-- > 0)
        if (++counter[len] != 0)
            break;
}

int oc_ctr_xor(const oc_cipher *cipher, uint8_t *out, const uint8_t *in,
               size_t len, uint8_t *counter)
{
    uint8_t counters[OC_BATCH_BLOCKS * 16];
    uint8_t stream[OC_BATCH_BLOCKS * 16];
    size_t bs, offset = 0;

    if (!cipher_valid(cipher) || !counter || (len && (!out || !in)))
        return -1;
    bs = cipher->block_size;
    while (offset < len) {
        size_t remaining = len - offset;
        size_t blocks = (remaining + bs - 1) / bs;
        size_t bytes, i;
        if (blocks > OC_BATCH_BLOCKS)
            blocks = OC_BATCH_BLOCKS;
        for (i = 0; i < blocks; ++i) {
            memcpy(counters + i * bs, counter, bs);
            increment_be(counter, bs);
        }
        cipher->encrypt_blocks(cipher->ctx, stream, counters, blocks);
        bytes = remaining < blocks * bs ? remaining : blocks * bs;
        for (i = 0; i < bytes; ++i)
            out[offset + i] = in[offset + i] ^ stream[i];
        offset += bytes;
    }
    return 0;
}

static void ghash_mul_portable(uint8_t out[16], const uint8_t x[16],
                               const uint8_t h[16])
{
    uint8_t z[16] = {0};
    uint8_t v[16];
    size_t bit, i;
    memcpy(v, h, 16);
    for (bit = 0; bit < 128; ++bit) {
        uint8_t selected = (uint8_t)(0U - ((x[bit / 8] >> (7 - bit % 8)) & 1U));
        uint8_t lsb;
        for (i = 0; i < 16; ++i)
            z[i] ^= v[i] & selected;
        lsb = (uint8_t)(v[15] & 1U);
        for (i = 16; i-- > 1;)
            v[i] = (uint8_t)((v[i] >> 1) | (v[i - 1] << 7));
        v[0] >>= 1;
        v[0] ^= (uint8_t)(0xe1U & (0U - lsb));
    }
    memcpy(out, z, 16);
}

#if OC_X86 && defined(__SIZEOF_INT128__)
static uint8_t reverse_bits8(uint8_t x)
{
    x = (uint8_t)(((x & 0x55U) << 1) | ((x >> 1) & 0x55U));
    x = (uint8_t)(((x & 0x33U) << 2) | ((x >> 2) & 0x33U));
    return (uint8_t)((x << 4) | (x >> 4));
}

OC_TARGET("pclmul,sse2")
static void ghash_mul_pclmul(uint8_t out[16], const uint8_t x[16],
                             const uint8_t h[16])
{
    __extension__ typedef unsigned __int128 u128;
    uint64_t xl = 0, xh = 0, hl = 0, hh = 0;
    __m128i a, b;
    __m128i p00, p11, cross;
    uint64_t w00[2], w11[2], wc[2];
    uint64_t r0, r1, r2, r3, result[2];
    u128 lo, hi, overflow;
    size_t i;

    /* NIST writes coefficient x^0 in the leftmost bit.  Reverse each byte
       while loading into CLMUL's conventional little-endian polynomial. */
    for (i = 0; i < 8; ++i) {
        xl |= (uint64_t)reverse_bits8(x[i]) << (8 * i);
        xh |= (uint64_t)reverse_bits8(x[i + 8]) << (8 * i);
        hl |= (uint64_t)reverse_bits8(h[i]) << (8 * i);
        hh |= (uint64_t)reverse_bits8(h[i + 8]) << (8 * i);
    }
    a = _mm_set_epi64x((long long)xh, (long long)xl);
    b = _mm_set_epi64x((long long)hh, (long long)hl);
    p00 = _mm_clmulepi64_si128(a, b, 0x00);
    p11 = _mm_clmulepi64_si128(a, b, 0x11);
    cross = _mm_xor_si128(_mm_clmulepi64_si128(a, b, 0x01),
                          _mm_clmulepi64_si128(a, b, 0x10));
    _mm_storeu_si128((__m128i *)(void *)w00, p00);
    _mm_storeu_si128((__m128i *)(void *)w11, p11);
    _mm_storeu_si128((__m128i *)(void *)wc, cross);
    r0 = w00[0];
    r1 = w00[1] ^ wc[0];
    r2 = w11[0] ^ wc[1];
    r3 = w11[1];
    lo = ((u128)r1 << 64) | r0;
    hi = ((u128)r3 << 64) | r2;

    /* x^128 = x^7 + x^2 + x + 1 in the little-endian polynomial form. */
    overflow = (hi >> 127) ^ (hi >> 126) ^ (hi >> 121);
    lo ^= hi ^ (hi << 1) ^ (hi << 2) ^ (hi << 7);
    lo ^= overflow ^ (overflow << 1) ^ (overflow << 2) ^ (overflow << 7);
    result[0] = (uint64_t)lo;
    result[1] = (uint64_t)(lo >> 64);
    for (i = 0; i < 16; ++i)
        out[i] = reverse_bits8((uint8_t)(result[i / 8] >> (8 * (i & 7U))));
}
#endif

void oc_ghash_multiply(uint8_t out[16], const uint8_t x[16],
                       const uint8_t h[16], oc_ghash_impl impl)
{
#if OC_X86 && defined(__SIZEOF_INT128__)
    if (impl != OC_GHASH_PORTABLE && oc_cpu_has_pclmul()) {
        ghash_mul_pclmul(out, x, h);
        return;
    }
#else
    (void)impl;
#endif
    ghash_mul_portable(out, x, h);
}

static void xor_block(uint8_t out[16], const uint8_t a[16],
                      const uint8_t b[16])
{
    size_t i;
    for (i = 0; i < 16; ++i)
        out[i] = a[i] ^ b[i];
}

static void ghash_update(uint8_t y[16], const uint8_t h[16],
                         const uint8_t *data, size_t len, oc_ghash_impl impl)
{
    while (len > 0) {
        uint8_t block[16] = {0};
        size_t take = len < 16 ? len : 16;
        size_t i;
        memcpy(block, data, take);
        for (i = 0; i < 16; ++i)
            block[i] ^= y[i];
        oc_ghash_multiply(y, block, h, impl);
        data += take;
        len -= take;
    }
}

static void increment32(uint8_t counter[16])
{
    increment_be(counter + 12, 4);
}

static void gctr(const oc_cipher *cipher, uint8_t *out, const uint8_t *in,
                 size_t len, const uint8_t initial[16])
{
    uint8_t counter[16];
    uint8_t counters[OC_BATCH_BLOCKS * 16];
    uint8_t stream[OC_BATCH_BLOCKS * 16];
    size_t offset = 0;
    memcpy(counter, initial, 16);
    while (offset < len) {
        size_t remaining = len - offset;
        size_t blocks = (remaining + 15) / 16;
        size_t bytes, i;
        if (blocks > OC_BATCH_BLOCKS)
            blocks = OC_BATCH_BLOCKS;
        for (i = 0; i < blocks; ++i) {
            increment32(counter);
            memcpy(counters + 16 * i, counter, 16);
        }
        cipher->encrypt_blocks(cipher->ctx, stream, counters, blocks);
        bytes = remaining < 16 * blocks ? remaining : 16 * blocks;
        for (i = 0; i < bytes; ++i)
            out[offset + i] = in[offset + i] ^ stream[i];
        offset += bytes;
    }
}

static int gcm_lengths_valid(size_t len, size_t aad_len, size_t nonce_len)
{
    const uint64_t max_bytes = UINT64_MAX / 8U;
    return (uint64_t)len <= max_bytes && (uint64_t)aad_len <= max_bytes &&
           (uint64_t)nonce_len <= max_bytes;
}

static void make_j0(uint8_t j0[16], const uint8_t h[16],
                    const uint8_t *nonce, size_t nonce_len,
                    oc_ghash_impl impl)
{
    if (nonce_len == 12) {
        memcpy(j0, nonce, 12);
        j0[12] = j0[13] = j0[14] = 0;
        j0[15] = 1;
    } else {
        uint8_t length_block[16] = {0};
        memset(j0, 0, 16);
        ghash_update(j0, h, nonce, nonce_len, impl);
        oc_store64_be(length_block + 8, (uint64_t)nonce_len * 8U);
        xor_block(length_block, length_block, j0);
        oc_ghash_multiply(j0, length_block, h, impl);
    }
}

static void make_tag(const oc_cipher *cipher, uint8_t tag[16],
                     const uint8_t *ciphertext, size_t len,
                     const uint8_t *aad, size_t aad_len,
                     const uint8_t h[16], const uint8_t j0[16],
                     oc_ghash_impl impl)
{
    uint8_t y[16] = {0};
    uint8_t length_block[16];
    uint8_t mask[16];
    size_t i;
    ghash_update(y, h, aad, aad_len, impl);
    ghash_update(y, h, ciphertext, len, impl);
    oc_store64_be(length_block, (uint64_t)aad_len * 8U);
    oc_store64_be(length_block + 8, (uint64_t)len * 8U);
    for (i = 0; i < 16; ++i)
        length_block[i] ^= y[i];
    oc_ghash_multiply(y, length_block, h, impl);
    cipher->encrypt_blocks(cipher->ctx, mask, j0, 1);
    xor_block(tag, y, mask);
}

int oc_gcm_encrypt(const oc_cipher *cipher, uint8_t *out,
                   const uint8_t *in, size_t len,
                   const uint8_t *aad, size_t aad_len,
                   const uint8_t *nonce, size_t nonce_len,
                   uint8_t tag[16], oc_ghash_impl impl)
{
    uint8_t zero[16] = {0}, h[16], j0[16];
    if (!cipher_valid(cipher) || cipher->block_size != 16 || !tag ||
        (len && (!out || !in)) || (aad_len && !aad) ||
        (nonce_len && !nonce) || !gcm_lengths_valid(len, aad_len, nonce_len))
        return -1;
    cipher->encrypt_blocks(cipher->ctx, h, zero, 1);
    make_j0(j0, h, nonce, nonce_len, impl);
    gctr(cipher, out, in, len, j0);
    make_tag(cipher, tag, out, len, aad, aad_len, h, j0, impl);
    return 0;
}

int oc_gcm_decrypt(const oc_cipher *cipher, uint8_t *out,
                   const uint8_t *in, size_t len,
                   const uint8_t *aad, size_t aad_len,
                   const uint8_t *nonce, size_t nonce_len,
                   const uint8_t tag[16], oc_ghash_impl impl)
{
    uint8_t zero[16] = {0}, h[16], j0[16], expected[16], diff = 0;
    size_t i;
    if (!cipher_valid(cipher) || cipher->block_size != 16 || !tag ||
        (len && (!out || !in)) || (aad_len && !aad) ||
        (nonce_len && !nonce) || !gcm_lengths_valid(len, aad_len, nonce_len))
        return -1;
    cipher->encrypt_blocks(cipher->ctx, h, zero, 1);
    make_j0(j0, h, nonce, nonce_len, impl);
    make_tag(cipher, expected, in, len, aad, aad_len, h, j0, impl);
    for (i = 0; i < 16; ++i)
        diff |= expected[i] ^ tag[i];
    if (diff)
        return -2;
    gctr(cipher, out, in, len, j0);
    return 0;
}

static void xts_mul_alpha(uint8_t tweak[16])
{
    uint8_t carry = 0;
    size_t i;
    for (i = 0; i < 16; ++i) {
        uint8_t next = (uint8_t)(tweak[i] >> 7);
        tweak[i] = (uint8_t)((tweak[i] << 1) | carry);
        carry = next;
    }
    tweak[0] ^= (uint8_t)(0x87U & (0U - carry));
}

static void xts_xex_one(const oc_cipher *cipher, uint8_t out[16],
                        const uint8_t in[16], const uint8_t tweak[16],
                        int decrypt)
{
    uint8_t tmp[16];
    size_t i;
    for (i = 0; i < 16; ++i)
        tmp[i] = in[i] ^ tweak[i];
    if (decrypt)
        cipher->decrypt_blocks(cipher->ctx, tmp, tmp, 1);
    else
        cipher->encrypt_blocks(cipher->ctx, tmp, tmp, 1);
    for (i = 0; i < 16; ++i)
        out[i] = tmp[i] ^ tweak[i];
}

static void xts_full_blocks(const oc_cipher *cipher, uint8_t *out,
                            const uint8_t *in, size_t blocks,
                            uint8_t tweak[16], int decrypt)
{
    while (blocks > 0) {
        uint8_t tweaks[OC_BATCH_BLOCKS][16];
        uint8_t before[OC_BATCH_BLOCKS * 16];
        uint8_t after[OC_BATCH_BLOCKS * 16];
        size_t count = blocks < OC_BATCH_BLOCKS ? blocks : OC_BATCH_BLOCKS;
        size_t b, i;
        for (b = 0; b < count; ++b) {
            memcpy(tweaks[b], tweak, 16);
            for (i = 0; i < 16; ++i)
                before[16 * b + i] = in[16 * b + i] ^ tweak[i];
            xts_mul_alpha(tweak);
        }
        if (decrypt)
            cipher->decrypt_blocks(cipher->ctx, after, before, count);
        else
            cipher->encrypt_blocks(cipher->ctx, after, before, count);
        for (b = 0; b < count; ++b)
            for (i = 0; i < 16; ++i)
                out[16 * b + i] = after[16 * b + i] ^ tweaks[b][i];
        out += 16 * count;
        in += 16 * count;
        blocks -= count;
    }
}

static int xts_crypt(const oc_cipher *data_cipher,
                     const oc_cipher *tweak_cipher, uint8_t *out,
                     const uint8_t *in, size_t len,
                     const uint8_t data_unit[16], int decrypt)
{
    uint8_t tweak[16];
    size_t full, tail, normal;
    if (!cipher_valid(data_cipher) || !cipher_valid(tweak_cipher) ||
        data_cipher->block_size != 16 || tweak_cipher->block_size != 16 ||
        !data_cipher->decrypt_blocks || len < 16 || !out || !in || !data_unit)
        return -1;
    tweak_cipher->encrypt_blocks(tweak_cipher->ctx, tweak, data_unit, 1);
    full = len / 16;
    tail = len % 16;
    if (tail == 0) {
        xts_full_blocks(data_cipher, out, in, full, tweak, decrypt);
        return 0;
    }

    normal = full - 1;
    xts_full_blocks(data_cipher, out, in, normal, tweak, decrypt);
    out += 16 * normal;
    in += 16 * normal;
    if (!decrypt) {
        uint8_t cc[16], pp[16], next[16];
        size_t i;
        xts_xex_one(data_cipher, cc, in, tweak, 0);
        memcpy(next, tweak, 16);
        xts_mul_alpha(next);
        for (i = 0; i < tail; ++i) {
            pp[i] = in[16 + i];
            out[16 + i] = cc[i];
        }
        memcpy(pp + tail, cc + tail, 16 - tail);
        xts_xex_one(data_cipher, out, pp, next, 0);
    } else {
        uint8_t pp[16], cc[16], next[16], partial[16];
        size_t i;
        memcpy(partial, in + 16, tail);
        memcpy(next, tweak, 16);
        xts_mul_alpha(next);
        xts_xex_one(data_cipher, pp, in, next, 1);
        for (i = 0; i < tail; ++i) {
            out[16 + i] = pp[i];
            cc[i] = partial[i];
        }
        memcpy(cc + tail, pp + tail, 16 - tail);
        xts_xex_one(data_cipher, out, cc, tweak, 1);
    }
    return 0;
}

int oc_xts_encrypt(const oc_cipher *data_cipher,
                   const oc_cipher *tweak_cipher, uint8_t *out,
                   const uint8_t *in, size_t len,
                   const uint8_t data_unit[16])
{
    return xts_crypt(data_cipher, tweak_cipher, out, in, len, data_unit, 0);
}

int oc_xts_decrypt(const oc_cipher *data_cipher,
                   const oc_cipher *tweak_cipher, uint8_t *out,
                   const uint8_t *in, size_t len,
                   const uint8_t data_unit[16])
{
    return xts_crypt(data_cipher, tweak_cipher, out, in, len, data_unit, 1);
}

/* ========================================================================
 * GCM-64 and XTS-64 for 64-bit block ciphers (e.g., TWINE)
 *
 * Based on the principle that GCM and XTS can be adapted for 64-bit blocks
 * by using GF(2^64) instead of GF(2^128).
 *
 * References:
 * - GCM for 64-bit blocks discussed in early GCM proposals
 * - Reducing polynomial: x^64 + x^4 + x^3 + x + 1 (0x1B for GF(2^64))
 * ======================================================================== */

/* GHASH-64: Multiplication in GF(2^64) with polynomial x^64 + x^4 + x^3 + x + 1 */
static void ghash64_mul(uint8_t out[8], const uint8_t x[8], const uint8_t h[8])
{
    uint8_t z[8] = {0};
    uint8_t v[8];
    size_t bit, i;
    memcpy(v, h, 8);

    for (bit = 0; bit < 64; ++bit) {
        uint8_t selected = (uint8_t)(0U - ((x[bit / 8] >> (7 - bit % 8)) & 1U));
        uint8_t lsb;
        for (i = 0; i < 8; ++i)
            z[i] ^= v[i] & selected;

        lsb = (uint8_t)(v[7] & 1U);
        for (i = 8; i-- > 1;)
            v[i] = (uint8_t)((v[i] >> 1) | (v[i - 1] << 7));
        v[0] >>= 1;
        /* Reduction polynomial x^64 + x^4 + x^3 + x + 1 -> 0x1B */
        v[0] ^= (uint8_t)(0x1bU & (0U - lsb));
    }
    memcpy(out, z, 8);
}

static void ghash64_update(uint8_t y[8], const uint8_t h[8],
                           const uint8_t *data, size_t len)
{
    while (len > 0) {
        uint8_t block[8] = {0};
        size_t take = len < 8 ? len : 8;
        size_t i;
        memcpy(block, data, take);
        for (i = 0; i < 8; ++i)
            block[i] ^= y[i];
        ghash64_mul(y, block, h);
        data += take;
        len -= take;
    }
}

static void increment32_64(uint8_t counter[8])
{
    increment_be(counter + 4, 4);
}

static void gctr64(const oc_cipher *cipher, uint8_t *out, const uint8_t *in,
                   size_t len, const uint8_t initial[8])
{
    uint8_t counter[8];
    uint8_t counters[OC_BATCH_BLOCKS * 8];
    uint8_t stream[OC_BATCH_BLOCKS * 8];
    size_t offset = 0;
    memcpy(counter, initial, 8);

    while (offset < len) {
        size_t remaining = len - offset;
        size_t blocks = (remaining + 7) / 8;
        size_t bytes, i;
        if (blocks > OC_BATCH_BLOCKS)
            blocks = OC_BATCH_BLOCKS;
        for (i = 0; i < blocks; ++i) {
            increment32_64(counter);
            memcpy(counters + 8 * i, counter, 8);
        }
        cipher->encrypt_blocks(cipher->ctx, stream, counters, blocks);
        bytes = remaining < 8 * blocks ? remaining : 8 * blocks;
        for (i = 0; i < bytes; ++i)
            out[offset + i] = in[offset + i] ^ stream[i];
        offset += bytes;
    }
}

static void make_j0_64(uint8_t j0[8], const uint8_t h[8],
                       const uint8_t *nonce, size_t nonce_len)
{
    if (nonce_len == 8) {
        /* Special case: 64-bit nonce directly used with counter=1 */
        memcpy(j0, nonce, 8);
        j0[4] = j0[5] = j0[6] = 0;
        j0[7] = 1;
    } else {
        /* General case: hash nonce and append length */
        uint8_t length_block[8] = {0};
        memset(j0, 0, 8);
        ghash64_update(j0, h, nonce, nonce_len);
        /* Store bit length in last 32 bits */
        oc_store32_be(length_block + 4, (uint32_t)(nonce_len * 8U));
        length_block[0] ^= j0[0]; length_block[1] ^= j0[1];
        length_block[2] ^= j0[2]; length_block[3] ^= j0[3];
        length_block[4] ^= j0[4]; length_block[5] ^= j0[5];
        length_block[6] ^= j0[6]; length_block[7] ^= j0[7];
        ghash64_mul(j0, length_block, h);
    }
}

static void make_tag64(const oc_cipher *cipher, uint8_t tag[8],
                       const uint8_t *ciphertext, size_t len,
                       const uint8_t *aad, size_t aad_len,
                       const uint8_t h[8], const uint8_t j0[8])
{
    uint8_t y[8] = {0};
    uint8_t length_block[8];
    uint8_t mask[8];
    size_t i;

    ghash64_update(y, h, aad, aad_len);
    ghash64_update(y, h, ciphertext, len);

    /* Encode lengths: AAD length in upper 32 bits, CT length in lower 32 bits (in bits) */
    oc_store32_be(length_block, (uint32_t)(aad_len * 8U));
    oc_store32_be(length_block + 4, (uint32_t)(len * 8U));

    for (i = 0; i < 8; ++i)
        length_block[i] ^= y[i];
    ghash64_mul(y, length_block, h);

    cipher->encrypt_blocks(cipher->ctx, mask, j0, 1);
    for (i = 0; i < 8; ++i)
        tag[i] = y[i] ^ mask[i];
}

int oc_gcm64_encrypt(const oc_cipher *cipher, uint8_t *out,
                     const uint8_t *in, size_t len,
                     const uint8_t *aad, size_t aad_len,
                     const uint8_t *nonce, size_t nonce_len,
                     uint8_t tag[8])
{
    uint8_t zero[8] = {0}, h[8], j0[8];

    if (!cipher_valid(cipher) || cipher->block_size != 8 || !tag ||
        (len && (!out || !in)) || (aad_len && !aad) || (nonce_len && !nonce))
        return -1;

    /* Security warning: 64-bit GCM has birthday bound at ~2^32 blocks */
    if (len > (1ULL << 35)) /* 32 GB limit for safety */
        return -1;

    cipher->encrypt_blocks(cipher->ctx, h, zero, 1);
    make_j0_64(j0, h, nonce, nonce_len);
    gctr64(cipher, out, in, len, j0);
    make_tag64(cipher, tag, out, len, aad, aad_len, h, j0);
    return 0;
}

int oc_gcm64_decrypt(const oc_cipher *cipher, uint8_t *out,
                     const uint8_t *in, size_t len,
                     const uint8_t *aad, size_t aad_len,
                     const uint8_t *nonce, size_t nonce_len,
                     const uint8_t tag[8])
{
    uint8_t zero[8] = {0}, h[8], j0[8], expected[8], diff = 0;
    size_t i;

    if (!cipher_valid(cipher) || cipher->block_size != 8 || !tag ||
        (len && (!out || !in)) || (aad_len && !aad) || (nonce_len && !nonce))
        return -1;

    if (len > (1ULL << 35))
        return -1;

    cipher->encrypt_blocks(cipher->ctx, h, zero, 1);
    make_j0_64(j0, h, nonce, nonce_len);
    make_tag64(cipher, expected, in, len, aad, aad_len, h, j0);

    for (i = 0; i < 8; ++i)
        diff |= expected[i] ^ tag[i];
    if (diff)
        return -2;

    gctr64(cipher, out, in, len, j0);
    return 0;
}

/* XTS-64: XTS mode for 64-bit block ciphers */
static void xts64_mul_alpha(uint8_t tweak[8])
{
    uint8_t carry = 0;
    size_t i;

    for (i = 0; i < 8; ++i) {
        uint8_t next = (uint8_t)(tweak[i] >> 7);
        tweak[i] = (uint8_t)((tweak[i] << 1) | carry);
        carry = next;
    }
    /* Reduction polynomial x^64 + x^4 + x^3 + x + 1 -> 0x1B */
    tweak[0] ^= (uint8_t)(0x1bU & (0U - carry));
}

static void xts64_xex_one(const oc_cipher *cipher, uint8_t out[8],
                          const uint8_t in[8], const uint8_t tweak[8],
                          int decrypt)
{
    uint8_t tmp[8];
    size_t i;

    for (i = 0; i < 8; ++i)
        tmp[i] = in[i] ^ tweak[i];

    if (decrypt)
        cipher->decrypt_blocks(cipher->ctx, tmp, tmp, 1);
    else
        cipher->encrypt_blocks(cipher->ctx, tmp, tmp, 1);

    for (i = 0; i < 8; ++i)
        out[i] = tmp[i] ^ tweak[i];
}

static void xts64_full_blocks(const oc_cipher *cipher, uint8_t *out,
                              const uint8_t *in, size_t blocks,
                              uint8_t tweak[8], int decrypt)
{
    while (blocks > 0) {
        uint8_t tweaks[OC_BATCH_BLOCKS][8];
        uint8_t before[OC_BATCH_BLOCKS * 8];
        uint8_t after[OC_BATCH_BLOCKS * 8];
        size_t count = blocks < OC_BATCH_BLOCKS ? blocks : OC_BATCH_BLOCKS;
        size_t b, i;

        for (b = 0; b < count; ++b) {
            memcpy(tweaks[b], tweak, 8);
            for (i = 0; i < 8; ++i)
                before[8 * b + i] = in[8 * b + i] ^ tweak[i];
            xts64_mul_alpha(tweak);
        }

        if (decrypt)
            cipher->decrypt_blocks(cipher->ctx, after, before, count);
        else
            cipher->encrypt_blocks(cipher->ctx, after, before, count);

        for (b = 0; b < count; ++b)
            for (i = 0; i < 8; ++i)
                out[8 * b + i] = after[8 * b + i] ^ tweaks[b][i];

        out += 8 * count;
        in += 8 * count;
        blocks -= count;
    }
}

static int xts64_crypt(const oc_cipher *data_cipher,
                       const oc_cipher *tweak_cipher, uint8_t *out,
                       const uint8_t *in, size_t len,
                       const uint8_t data_unit[8], int decrypt)
{
    uint8_t tweak[8];
    size_t full, tail, normal;

    if (!cipher_valid(data_cipher) || !cipher_valid(tweak_cipher) ||
        data_cipher->block_size != 8 || tweak_cipher->block_size != 8 ||
        !data_cipher->decrypt_blocks || len < 8 || !out || !in || !data_unit)
        return -1;

    tweak_cipher->encrypt_blocks(tweak_cipher->ctx, tweak, data_unit, 1);
    full = len / 8;
    tail = len % 8;

    if (tail == 0) {
        xts64_full_blocks(data_cipher, out, in, full, tweak, decrypt);
        return 0;
    }

    /* Ciphertext stealing for partial block */
    normal = full - 1;
    xts64_full_blocks(data_cipher, out, in, normal, tweak, decrypt);
    out += 8 * normal;
    in += 8 * normal;

    if (!decrypt) {
        uint8_t cc[8], pp[8], next[8];
        size_t i;

        xts64_xex_one(data_cipher, cc, in, tweak, 0);
        memcpy(next, tweak, 8);
        xts64_mul_alpha(next);

        for (i = 0; i < tail; ++i) {
            pp[i] = in[8 + i];
            out[8 + i] = cc[i];
        }
        memcpy(pp + tail, cc + tail, 8 - tail);
        xts64_xex_one(data_cipher, out, pp, next, 0);
    } else {
        uint8_t pp[8], cc[8], next[8], partial[8];
        size_t i;

        memcpy(partial, in + 8, tail);
        memcpy(next, tweak, 8);
        xts64_mul_alpha(next);
        xts64_xex_one(data_cipher, pp, in, next, 1);

        for (i = 0; i < tail; ++i) {
            out[8 + i] = pp[i];
            cc[i] = partial[i];
        }
        memcpy(cc + tail, pp + tail, 8 - tail);
        xts64_xex_one(data_cipher, out, cc, tweak, 1);
    }
    return 0;
}

int oc_xts64_encrypt(const oc_cipher *data_cipher,
                     const oc_cipher *tweak_cipher, uint8_t *out,
                     const uint8_t *in, size_t len,
                     const uint8_t data_unit[8])
{
    return xts64_crypt(data_cipher, tweak_cipher, out, in, len, data_unit, 0);
}

int oc_xts64_decrypt(const oc_cipher *data_cipher,
                     const oc_cipher *tweak_cipher, uint8_t *out,
                     const uint8_t *in, size_t len,
                     const uint8_t data_unit[8])
{
    return xts64_crypt(data_cipher, tweak_cipher, out, in, len, data_unit, 1);
}
