# AES、SM4、GIFT-128、TWINE-80 软件优化实验

这是一个可直接编译、测试和测量的 C11 作业工程。四种分组密码都包含基础实现，并且**每种密码分别提供至少两种指定类型的优化方法**。

| 密码 | 基础实现 | T-table | shuffle / 新指令集 | 额外实现 |
|---|---|---|---|---|
| AES-128 | FIPS 197 逐步轮函数 | 4 x 256 加密表与 4 x 256 解密表 | AVX2 gather、AVX2/SSSE3 `vpshufb`、AES-NI | 8 分组批处理与软件回退 |
| SM4 | 逐轮 S-box 与线性变换 | 4 x 256 融合表 | AVX2 gather，8 分组并行 | - |
| GIFT-128 | nibble S-box + bit permutation | 32 x 16 融合 SubCells/PermBits 表 | AVX2 `vpshufb` | 32 位 fixsliced |
| TWINE-80 | 16 nibble 广义 Feistel | 融合 F 函数与 block shuffle | AVX2 `vpshufb`，2 分组并行 | - |

工作模式包括：

- CTR：支持 64/128 位分组，因此四种密码均可使用；最多 8 分组批处理。
- GCM：按 NIST SP 800-38D，仅接受 128 位分组密码；支持任意 nonce 长度、AAD、PCLMULQDQ GHASH。
- XTS：按 NIST SP 800-38E，仅接受 128 位分组密码；支持非整分组数据单元的 ciphertext stealing。

因此，CTR 可搭配 AES、SM4、GIFT-128、TWINE-80；GCM 和 XTS 可搭配 AES、SM4、GIFT-128。TWINE 的分组长度为 64 位，不能直接代入标准 GCM/XTS。

## 编译与运行

环境要求：64 位 Windows、PowerShell、GCC/MinGW-w64。工程使用函数级 target attribute 编译 AVX2、SSSE3、AES-NI、PCLMUL 路径，不需要全局添加对应 ISA 参数；运行时会检测 CPU，不支持时自动回退。

```powershell
# Release 构建测试与基准
powershell -ExecutionPolicy Bypass -File .\build.ps1 -Target all -Configuration Release

# 正确性测试
.\build\test_optcrypto.exe

# 默认使用 1 MiB 缓冲区测量
.\build\bench_optcrypto.exe

# 指定缓冲区字节数
.\build\bench_optcrypto.exe --bytes 4194304

# 清理生成文件
powershell -ExecutionPolicy Bypass -File .\build.ps1 -Target clean
```

在 GNU Make 环境中也可执行 `make test` 和 `make bench`。

## 工程结构

```text
include/optcrypto.h       公共 API、上下文和 cipher adapter
src/aes.c                 AES-128 基础、T-table、AVX2 gather/shuffle、AES-NI
src/sm4.c                 SM4 基础、T-table、AVX2 gather
src/gift128.c             GIFT-128 基础、T-table、AVX2 shuffle
src/gift128_fix.c         GIFT-128 fixsliced
src/twine.c               TWINE-80 基础、T-table、AVX2 shuffle
src/modes.c               CTR、GCM/GHASH、XTS/CTS
src/cpu.c                 运行时指令集检测
tests/test.c              标准向量、差分和边界测试
bench/bench.c             自动校准的吞吐量基准
report/report.tex         实验设计、结果和分析的 LaTeX 源文件
THIRD_PARTY_NOTICES.md    第三方实现说明
```

## API 示例

```c
#include "optcrypto.h"

uint8_t key[16] = {0};
uint8_t counter[16] = {0};
uint8_t input[100] = {0}, output[100];
oc_aes128_aesni_ctx aes;

oc_aes128_aesni_init(&aes, key);
oc_cipher cipher = oc_aes128_aesni_cipher(&aes);
oc_ctr_xor(&cipher, output, input, sizeof(input), counter);
```

所有 block/mode 接口支持 `out == in`。GCM 解密返回 `-2` 表示标签错误，并保证验证失败时不写出明文；参数或分组长度错误返回 `-1`。

## 安全说明

本工程用于课程实验，不是经过审计的生产密码库。T-table 和 AVX2 gather 存在与秘密数据相关的缓存访问，可能受到 cache-timing 攻击；AES 场景优先选择 AES-NI 或固定访问全部子表的 shuffle 路径。GCM 同一密钥下不得重复 nonce；XTS 的两个密钥必须独立，且 XTS 只提供存储加密的保密性，不提供完整性认证。

完整实验内容、测试依据、测量结果与参考文献见 `report/report.tex` 及生成的 `report/report.pdf`。
