#ifndef OPTCRYPTO_H
#define OPTCRYPTO_H

#include <stddef.h>
#include <stdint.h>

#if defined(__x86_64__) || defined(__i386__) || defined(_M_X64) || defined(_M_IX86)
#include <immintrin.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*oc_crypt_blocks_fn)(const void *ctx, uint8_t *out,
                                   const uint8_t *in, size_t blocks);

typedef struct {
    const void *ctx;
    size_t block_size;
    oc_crypt_blocks_fn encrypt_blocks;
    oc_crypt_blocks_fn decrypt_blocks;
    const char *name;
} oc_cipher;

/* AES-128: basic, T-table, AVX2 gather/shuffle, and AES-NI. */
typedef struct {
    uint8_t enc_round_keys[11][16];
    uint8_t dec_round_keys[11][16];
} oc_aes128_ctx;

typedef struct {
    oc_aes128_ctx base;
    uint32_t enc_table[4][256];
    uint32_t dec_table[4][256];
} oc_aes128_ttable_ctx;

typedef struct {
    oc_aes128_ctx base;
    uint8_t sbox_sub[16][16];
    uint8_t inv_sbox_sub[16][16];
} oc_aes128_shuffle_ctx;

typedef struct {
    oc_aes128_ctx base;
} oc_aes128_aesni_ctx;

void oc_aes128_init(oc_aes128_ctx *ctx, const uint8_t key[16]);
void oc_aes128_ttable_init(oc_aes128_ttable_ctx *ctx,
                           const uint8_t key[16]);
void oc_aes128_shuffle_init(oc_aes128_shuffle_ctx *ctx,
                            const uint8_t key[16]);
void oc_aes128_aesni_init(oc_aes128_aesni_ctx *ctx,
                          const uint8_t key[16]);
oc_cipher oc_aes128_basic_cipher(const oc_aes128_ctx *ctx);
oc_cipher oc_aes128_ttable_cipher(const oc_aes128_ttable_ctx *ctx);
oc_cipher oc_aes128_avx2_gather_cipher(const oc_aes128_ttable_ctx *ctx);
oc_cipher oc_aes128_shuffle_cipher(const oc_aes128_shuffle_ctx *ctx);
oc_cipher oc_aes128_aesni_cipher(const oc_aes128_aesni_ctx *ctx);

/* SM4: basic, T-table, scalar shuffle, AVX2 gather, and AVX2 shuffle. */
typedef struct {
    uint32_t rk[32];
} oc_sm4_ctx;

typedef struct {
    oc_sm4_ctx base;
    uint32_t table[4][256];
    uint32_t sbox32[256];
} oc_sm4_ttable_ctx;

typedef struct {
    oc_sm4_ctx base;
    __m128i sbox_sub[16];  /* 16 sub-tables of 16 entries for vpshufb */
} oc_sm4_shuffle_ctx;

void oc_sm4_init(oc_sm4_ctx *ctx, const uint8_t key[16]);
void oc_sm4_ttable_init(oc_sm4_ttable_ctx *ctx, const uint8_t key[16]);
void oc_sm4_shuffle_init(oc_sm4_shuffle_ctx *ctx, const uint8_t key[16]);
oc_cipher oc_sm4_basic_cipher(const oc_sm4_ctx *ctx);
oc_cipher oc_sm4_ttable_cipher(const oc_sm4_ttable_ctx *ctx);
oc_cipher oc_sm4_scalar_shuffle_cipher(const oc_sm4_ctx *ctx);
oc_cipher oc_sm4_avx2_cipher(const oc_sm4_ttable_ctx *ctx);
oc_cipher oc_sm4_shuffle_cipher(const oc_sm4_shuffle_ctx *ctx);

/* GIFT-128: basic, T-table, fixsliced shuffle, AVX2 shuffle, and
 * AVX2 fixsliced paths. */
typedef struct {
    uint8_t round_mask[40][32];
} oc_gift128_ctx;

typedef struct {
    uint64_t q[2];
} oc_gift128_table_entry;

typedef struct {
    oc_gift128_ctx base;
    oc_gift128_table_entry table[32][16];
    uint64_t packed_mask[40][2];
} oc_gift128_ttable_ctx;

typedef struct {
    uint32_t rkey[80];
} oc_gift128_fix_ctx;

void oc_gift128_init(oc_gift128_ctx *ctx, const uint8_t key[16]);
void oc_gift128_ttable_init(oc_gift128_ttable_ctx *ctx,
                            const uint8_t key[16]);
void oc_gift128_fix_init(oc_gift128_fix_ctx *ctx, const uint8_t key[16]);
oc_cipher oc_gift128_basic_cipher(const oc_gift128_ctx *ctx);
oc_cipher oc_gift128_ttable_cipher(const oc_gift128_ttable_ctx *ctx);
oc_cipher oc_gift128_avx2_cipher(const oc_gift128_ctx *ctx);
oc_cipher oc_gift128_fix_cipher(const oc_gift128_fix_ctx *ctx);
oc_cipher oc_gift128_avx2_fix_cipher(const oc_gift128_fix_ctx *ctx);

/* TWINE-80: basic, T-table, layout-tracked shuffle, AVX2 shuffle, and
 * AVX2 gather paths. */
typedef struct {
    uint8_t round_key[36][8];
    uint8_t round_key_lanes[36][16];
} oc_twine80_ctx;

typedef struct {
    oc_twine80_ctx base;
    uint8_t ftable[16][256];
    uint64_t ptable[8][256];
    uint64_t inv_ptable[8][256];
    uint32_t gather_sbox[16][16];
} oc_twine80_ttable_ctx;

typedef struct {
    uint8_t rk[36][8];
} oc_twine80_fix_ctx;

void oc_twine80_init(oc_twine80_ctx *ctx, const uint8_t key[10]);
void oc_twine80_ttable_init(oc_twine80_ttable_ctx *ctx,
                            const uint8_t key[10]);
void oc_twine80_fix_init(oc_twine80_fix_ctx *ctx, const uint8_t key[10]);
oc_cipher oc_twine80_basic_cipher(const oc_twine80_ctx *ctx);
oc_cipher oc_twine80_ttable_cipher(const oc_twine80_ttable_ctx *ctx);
oc_cipher oc_twine80_avx2_cipher(const oc_twine80_ctx *ctx);
oc_cipher oc_twine80_fix_cipher(const oc_twine80_fix_ctx *ctx);
oc_cipher oc_twine80_avx2_gather_cipher(const oc_twine80_ttable_ctx *ctx);

/* Runtime feature reporting; accelerated APIs fall back when unavailable. */
int oc_cpu_has_avx2(void);
int oc_cpu_has_pclmul(void);
int oc_cpu_has_ssse3(void);
int oc_cpu_has_aesni(void);

/* Generic CTR. The counter is incremented as one big-endian integer. */
int oc_ctr_xor(const oc_cipher *cipher, uint8_t *out, const uint8_t *in,
               size_t len, uint8_t *counter);

typedef enum {
    OC_GHASH_PORTABLE = 0,
    OC_GHASH_PCLMUL = 1,
    OC_GHASH_AUTO = 2
} oc_ghash_impl;

/* GCM supports any nonce length and emits a full 128-bit tag. */
int oc_gcm_encrypt(const oc_cipher *cipher, uint8_t *out,
                   const uint8_t *in, size_t len,
                   const uint8_t *aad, size_t aad_len,
                   const uint8_t *nonce, size_t nonce_len,
                   uint8_t tag[16], oc_ghash_impl impl);
int oc_gcm_decrypt(const oc_cipher *cipher, uint8_t *out,
                   const uint8_t *in, size_t len,
                   const uint8_t *aad, size_t aad_len,
                   const uint8_t *nonce, size_t nonce_len,
                   const uint8_t tag[16], oc_ghash_impl impl);

/* Exposed for differential tests and the benchmark. */
void oc_ghash_multiply(uint8_t out[16], const uint8_t x[16],
                       const uint8_t h[16], oc_ghash_impl impl);

/* XTS uses two contexts of the same 128-bit block cipher and supports CTS. */
int oc_xts_encrypt(const oc_cipher *data_cipher,
                   const oc_cipher *tweak_cipher, uint8_t *out,
                   const uint8_t *in, size_t len,
                   const uint8_t data_unit[16]);
int oc_xts_decrypt(const oc_cipher *data_cipher,
                   const oc_cipher *tweak_cipher, uint8_t *out,
                   const uint8_t *in, size_t len,
                   const uint8_t data_unit[16]);

/* GCM-64 and XTS-64 for 64-bit block ciphers (e.g., TWINE).
 * Based on GF(2^64) arithmetic with reducing polynomial x^64 + x^4 + x^3 + x + 1.
 * Security note: 64-bit GCM has birthday bound at ~2^32 blocks (~32 GB).
 * Nonce should be 8 bytes for optimal performance, but any length is supported. */
int oc_gcm64_encrypt(const oc_cipher *cipher, uint8_t *out,
                     const uint8_t *in, size_t len,
                     const uint8_t *aad, size_t aad_len,
                     const uint8_t *nonce, size_t nonce_len,
                     uint8_t tag[8]);
int oc_gcm64_decrypt(const oc_cipher *cipher, uint8_t *out,
                     const uint8_t *in, size_t len,
                     const uint8_t *aad, size_t aad_len,
                     const uint8_t *nonce, size_t nonce_len,
                     const uint8_t tag[8]);

/* XTS-64 for 64-bit block ciphers with ciphertext stealing support. */
int oc_xts64_encrypt(const oc_cipher *data_cipher,
                     const oc_cipher *tweak_cipher, uint8_t *out,
                     const uint8_t *in, size_t len,
                     const uint8_t data_unit[8]);
int oc_xts64_decrypt(const oc_cipher *data_cipher,
                     const oc_cipher *tweak_cipher, uint8_t *out,
                     const uint8_t *in, size_t len,
                     const uint8_t data_unit[8]);

#ifdef __cplusplus
}
#endif

#endif
