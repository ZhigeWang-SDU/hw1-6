/*
 * Bit-sliced (fixsliced) TWINE-80 implementation.
 *
 * State representation: 4 16-bit "bit slices" packed into 2 32-bit registers.
 *   For each nibble j in 0..15, bit i of nibble j is stored at bit position j
 *   of the i-th slice.  Bit 0 is the LSB of each nibble, bit 3 is the MSB.
 *
 *   R0 = s0 | (s1 << 16)
 *   R1 = s2 | (s3 << 16)
 * where s_k[j] = bit k of nibble j.
 *
 * The S-box is implemented as a 16-way multiplexer: for each candidate input
 * value v in 0..15, the precomputed match mask is OR-ed with the corresponding
 * 32-bit S-box output mask if the candidate matches.  The construction is
 * data-independent and table-free, similar in spirit to the GIFT-128
 * fixsliced path.  The block shuffle is applied by extracting the 16 source
 * bits and re-packing them in the new order, which is constant-time.
 *
 * Nibble ordering in the byte array: byte i holds nibble 2*i (low) and
 * nibble 2*i+1 (high).  In the bit-sliced representation, nibble j lives at
 * bit position j of each slice, so the S-box applied to "all even nibbles"
 * (positions 0, 2, ..., 14) is implemented by running the multiplexer over
 * the whole slice and then shifting the result from even bit positions to
 * odd bit positions.
 */
#include "optcrypto.h"
#include "internal.h"

#include <stdint.h>
#include <stdio.h>
#include <string.h>

static const uint8_t twine_sbox[16] = {
    0xc,0x0,0xf,0xa,0x2,0xb,0x9,0x5,0x8,0x3,0xd,0x7,0x1,0xe,0x6,0x4
};

static const uint8_t twine_con[35] = {
    0x01,0x02,0x04,0x08,0x10,0x20,0x03,0x06,0x0c,0x18,
    0x30,0x23,0x05,0x0a,0x14,0x28,0x13,0x26,0x0f,0x1e,
    0x3c,0x3b,0x35,0x29,0x11,0x22,0x07,0x0e,0x1c,0x38,
    0x33,0x25,0x09,0x12,0x24
};

static const uint8_t twine_pi[16] = {
    5, 0, 1, 4, 7, 12, 3, 8, 13, 6, 9, 2, 15, 10, 11, 14
};

static const uint8_t twine_inv_pi[16] = {
    1, 2, 11, 6, 3, 0, 9, 4, 7, 10, 13, 14, 5, 8, 15, 12
};

/* Precomputed masks for the 16-way multiplexer S-box.
 * mask_b[v] = 0xFFFFFFFF if S(v)[b] = 1, else 0x00000000. */
static uint32_t sbox_mask[4][16];
static int sbox_masks_ready = 0;

static void init_sbox_masks(void)
{
    size_t v;
    for (v = 0; v < 16; ++v) {
        sbox_mask[0][v] = (twine_sbox[v] & 1U) ? 0xFFFFFFFFU : 0U;
        sbox_mask[1][v] = (twine_sbox[v] & 2U) ? 0xFFFFFFFFU : 0U;
        sbox_mask[2][v] = (twine_sbox[v] & 4U) ? 0xFFFFFFFFU : 0U;
        sbox_mask[3][v] = (twine_sbox[v] & 8U) ? 0xFFFFFFFFU : 0U;
    }
    sbox_masks_ready = 1;
}

/* Bit-sliced S-box via 16-way multiplexer.
 * Input: 4 16-bit bit slices packed into 2 32-bit registers. */
static void sbox_fix(uint32_t *R0_out, uint32_t *R1_out,
                     uint32_t R0_in, uint32_t R1_in)
{
    uint32_t s0 = R0_in & 0x0000FFFFU;
    uint32_t s1 = (R0_in >> 16) & 0x0000FFFFU;
    uint32_t s2 = R1_in & 0x0000FFFFU;
    uint32_t s3 = (R1_in >> 16) & 0x0000FFFFU;
    uint32_t out0 = 0, out1 = 0, out2 = 0, out3 = 0;
    size_t v;
    for (v = 0; v < 16; ++v) {
        /* Broadcast sv_i = 0xFFFF when sv_i = 1 (so ~(s_i ^ 0xFFFF) = s_i),
         * and 0 when sv_i = 0 (so ~(s_i ^ 0) = ~s_i). */
        uint32_t sv0 = (v & 1U) ? 0x0000FFFFU : 0U;
        uint32_t sv1 = ((v >> 1) & 1U) ? 0x0000FFFFU : 0U;
        uint32_t sv2 = ((v >> 2) & 1U) ? 0x0000FFFFU : 0U;
        uint32_t sv3 = ((v >> 3) & 1U) ? 0x0000FFFFU : 0U;
        uint32_t match = (~(s0 ^ sv0) & ~(s1 ^ sv1) &
                          ~(s2 ^ sv2) & ~(s3 ^ sv3));
        out0 |= sbox_mask[0][v] & match;
        out1 |= sbox_mask[1][v] & match;
        out2 |= sbox_mask[2][v] & match;
        out3 |= sbox_mask[3][v] & match;
    }
    *R0_out = (out0 & 0x0000FFFFU) | ((out1 & 0x0000FFFFU) << 16);
    *R1_out = (out2 & 0x0000FFFFU) | ((out3 & 0x0000FFFFU) << 16);
}

/* Apply the forward block shuffle to the bit-sliced state.
 * TWINE block permutation: new[pi[i]] = old[i], so for the new state at
 * position j, the source is the old position i such that pi[i] = j, i.e.,
 * i = pi_inv[j].  We use pi_inv as the source. */
static void shuffle_fix(uint32_t *R0, uint32_t *R1)
{
    uint32_t s0 = *R0 & 0x0000FFFFU;
    uint32_t s1 = (*R0 >> 16) & 0x0000FFFFU;
    uint32_t s2 = *R1 & 0x0000FFFFU;
    uint32_t s3 = (*R1 >> 16) & 0x0000FFFFU;
    uint32_t n0 = 0, n1 = 0, n2 = 0, n3 = 0;
    size_t i;
    for (i = 0; i < 16; ++i) {
        size_t src = twine_inv_pi[i];
        n0 |= ((s0 >> src) & 1U) << i;
        n1 |= ((s1 >> src) & 1U) << i;
        n2 |= ((s2 >> src) & 1U) << i;
        n3 |= ((s3 >> src) & 1U) << i;
    }
    *R0 = n0 | (n1 << 16);
    *R1 = n2 | (n3 << 16);
}

/* Apply the inverse block shuffle: new[i] = old[pi[i]]. */
static void inv_shuffle_fix(uint32_t *R0, uint32_t *R1)
{
    uint32_t s0 = *R0 & 0x0000FFFFU;
    uint32_t s1 = (*R0 >> 16) & 0x0000FFFFU;
    uint32_t s2 = *R1 & 0x0000FFFFU;
    uint32_t s3 = (*R1 >> 16) & 0x0000FFFFU;
    uint32_t n0 = 0, n1 = 0, n2 = 0, n3 = 0;
    size_t i;
    for (i = 0; i < 16; ++i) {
        size_t src = twine_pi[i];
        n0 |= ((s0 >> src) & 1U) << i;
        n1 |= ((s1 >> src) & 1U) << i;
        n2 |= ((s2 >> src) & 1U) << i;
        n3 |= ((s3 >> src) & 1U) << i;
    }
    *R0 = n0 | (n1 << 16);
    *R1 = n2 | (n3 << 16);
}

/* Pack 16 nibbles from a byte array into bit-sliced form.
 * Matches the basic implementation: state[2*i] = high nibble of in[i],
 * state[2*i+1] = low nibble of in[i]. */
static void pack_state(uint32_t *R0, uint32_t *R1, const uint8_t in[8])
{
    uint32_t s0 = 0, s1 = 0, s2 = 0, s3 = 0;
    size_t i;
    for (i = 0; i < 8; ++i) {
        uint8_t hi = (in[i] >> 4) & 0x0f;
        uint8_t lo = in[i] & 0x0f;
        s0 |= (uint32_t)(hi & 1U) << (2 * i);
        s0 |= (uint32_t)(lo & 1U) << (2 * i + 1);
        s1 |= (uint32_t)((hi >> 1) & 1U) << (2 * i);
        s1 |= (uint32_t)((lo >> 1) & 1U) << (2 * i + 1);
        s2 |= (uint32_t)((hi >> 2) & 1U) << (2 * i);
        s2 |= (uint32_t)((lo >> 2) & 1U) << (2 * i + 1);
        s3 |= (uint32_t)((hi >> 3) & 1U) << (2 * i);
        s3 |= (uint32_t)((lo >> 3) & 1U) << (2 * i + 1);
    }
    *R0 = s0 | (s1 << 16);
    *R1 = s2 | (s3 << 16);
}

static void unpack_state(uint8_t out[8], uint32_t R0, uint32_t R1)
{
    size_t i;
    for (i = 0; i < 8; ++i) {
        unsigned shift = 2 * i;
        uint8_t hi = (uint8_t)(((R0 >> shift) & 1U) |
                               (((R0 >> (shift + 16)) & 1U) << 1) |
                               (((R1 >> shift) & 1U) << 2) |
                               (((R1 >> (shift + 16)) & 1U) << 3));
        uint8_t lo = (uint8_t)(((R0 >> (shift + 1)) & 1U) |
                               (((R0 >> (shift + 17)) & 1U) << 1) |
                               (((R1 >> (shift + 1)) & 1U) << 2) |
                               (((R1 >> (shift + 17)) & 1U) << 3));
        out[i] = (uint8_t)((hi << 4) | lo);
    }
}

/* Pack 8 round key nibbles (rk[0..7]) into the bit-sliced representation at
 * even bit positions 0, 2, 4, ..., 14. */
static void pack_round_key(uint32_t *R0, uint32_t *R1, const uint8_t rk[8])
{
    uint32_t s0 = 0, s1 = 0, s2 = 0, s3 = 0;
    size_t i;
    for (i = 0; i < 8; ++i) {
        uint8_t k = rk[i];
        s0 |= (uint32_t)(k & 1U) << (2 * i);
        s1 |= (uint32_t)((k >> 1) & 1U) << (2 * i);
        s2 |= (uint32_t)((k >> 2) & 1U) << (2 * i);
        s3 |= (uint32_t)((k >> 3) & 1U) << (2 * i);
    }
    *R0 = s0 | (s1 << 16);
    *R1 = s2 | (s3 << 16);
}

/* F function: apply the S-box to even nibbles XORed with the round key, then
 * XOR the result into the odd nibbles. */
static void f_function(uint32_t *R0, uint32_t *R1, const uint8_t rk[8])
{
    uint32_t kR0, kR1, eR0, eR1, fR0, fR1;
    pack_round_key(&kR0, &kR1, rk);
    eR0 = *R0 ^ kR0;
    eR1 = *R1 ^ kR1;
    sbox_fix(&fR0, &fR1, eR0, eR1);
    /* Shift even-position bits to odd positions within each 16-bit slice. */
    *R0 ^= (fR0 & 0x55555555U) << 1;
    *R1 ^= (fR1 & 0x55555555U) << 1;
}

static void derive_round_keys(uint8_t rk[36][8], const uint8_t key[10])
{
    uint8_t wk[20];
    size_t i, r;
    static const uint8_t pick[8] = {1, 3, 4, 6, 13, 14, 15, 16};
    for (i = 0; i < 10; ++i) {
        wk[2 * i] = (uint8_t)(key[i] >> 4);
        wk[2 * i + 1] = (uint8_t)(key[i] & 0x0f);
    }
    for (i = 0; i < 8; ++i)
        rk[0][i] = wk[pick[i]];
    for (r = 1; r < 36; ++r) {
        wk[1] ^= twine_sbox[wk[0]];
        wk[4] ^= twine_sbox[wk[16]];
        wk[7] ^= (uint8_t)(twine_con[r - 1] >> 3);
        wk[19] ^= (uint8_t)(twine_con[r - 1] & 7U);
        {
            uint8_t old[20];
            memcpy(old, wk, sizeof(old));
            for (i = 0; i < 16; ++i) wk[i] = old[i + 4];
            wk[16] = old[1];
            wk[17] = old[2];
            wk[18] = old[3];
            wk[19] = old[0];
        }
        for (i = 0; i < 8; ++i)
            rk[r][i] = wk[pick[i]];
    }
}

void oc_twine80_fix_init(oc_twine80_fix_ctx *ctx, const uint8_t key[10])
{
    if (!sbox_masks_ready) {
        init_sbox_masks();
    }
    derive_round_keys(ctx->rk, key);
}

static void fix_crypt_one(const oc_twine80_fix_ctx *ctx, uint8_t *out,
                          const uint8_t *in, int decrypt)
{
    uint32_t R0, R1;
    int r;
    pack_state(&R0, &R1, in);
    if (!decrypt) {
        for (r = 0; r < 35; ++r) {
            f_function(&R0, &R1, ctx->rk[r]);
            shuffle_fix(&R0, &R1);
        }
        f_function(&R0, &R1, ctx->rk[35]);
    } else {
        /* Last round first (no shuffle) */
        f_function(&R0, &R1, ctx->rk[35]);
        for (r = 34; r >= 0; --r) {
            inv_shuffle_fix(&R0, &R1);
            f_function(&R0, &R1, ctx->rk[r]);
        }
    }
    unpack_state(out, R0, R1);
}

static void fix_encrypt(const void *vctx, uint8_t *out,
                        const uint8_t *in, size_t blocks)
{
    const oc_twine80_fix_ctx *ctx = (const oc_twine80_fix_ctx *)vctx;
    size_t i;
    for (i = 0; i < blocks; ++i)
        fix_crypt_one(ctx, out + 8 * i, in + 8 * i, 0);
}

static void fix_decrypt(const void *vctx, uint8_t *out,
                        const uint8_t *in, size_t blocks)
{
    const oc_twine80_fix_ctx *ctx = (const oc_twine80_fix_ctx *)vctx;
    size_t i;
    for (i = 0; i < blocks; ++i)
        fix_crypt_one(ctx, out + 8 * i, in + 8 * i, 1);
}

oc_cipher oc_twine80_fix_cipher(const oc_twine80_fix_ctx *ctx)
{
    oc_cipher c = {ctx, 8, fix_encrypt, fix_decrypt,
                   "TWINE-80-fixsliced"};
    return c;
}
