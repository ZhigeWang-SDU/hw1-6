#include "optcrypto.h"
#include "internal.h"

#include <string.h>

#if OC_X86
#include <immintrin.h>
#endif

/* AES state bytes use the FIPS 197 column-major order throughout this file. */
static const uint8_t aes_sbox[256] = {
    0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
    0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
    0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
    0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
    0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
    0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
    0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
    0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
    0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
    0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
    0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
    0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
    0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
    0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
    0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
    0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16
};

static const uint8_t aes_inv_sbox[256] = {
    0x52,0x09,0x6a,0xd5,0x30,0x36,0xa5,0x38,0xbf,0x40,0xa3,0x9e,0x81,0xf3,0xd7,0xfb,
    0x7c,0xe3,0x39,0x82,0x9b,0x2f,0xff,0x87,0x34,0x8e,0x43,0x44,0xc4,0xde,0xe9,0xcb,
    0x54,0x7b,0x94,0x32,0xa6,0xc2,0x23,0x3d,0xee,0x4c,0x95,0x0b,0x42,0xfa,0xc3,0x4e,
    0x08,0x2e,0xa1,0x66,0x28,0xd9,0x24,0xb2,0x76,0x5b,0xa2,0x49,0x6d,0x8b,0xd1,0x25,
    0x72,0xf8,0xf6,0x64,0x86,0x68,0x98,0x16,0xd4,0xa4,0x5c,0xcc,0x5d,0x65,0xb6,0x92,
    0x6c,0x70,0x48,0x50,0xfd,0xed,0xb9,0xda,0x5e,0x15,0x46,0x57,0xa7,0x8d,0x9d,0x84,
    0x90,0xd8,0xab,0x00,0x8c,0xbc,0xd3,0x0a,0xf7,0xe4,0x58,0x05,0xb8,0xb3,0x45,0x06,
    0xd0,0x2c,0x1e,0x8f,0xca,0x3f,0x0f,0x02,0xc1,0xaf,0xbd,0x03,0x01,0x13,0x8a,0x6b,
    0x3a,0x91,0x11,0x41,0x4f,0x67,0xdc,0xea,0x97,0xf2,0xcf,0xce,0xf0,0xb4,0xe6,0x73,
    0x96,0xac,0x74,0x22,0xe7,0xad,0x35,0x85,0xe2,0xf9,0x37,0xe8,0x1c,0x75,0xdf,0x6e,
    0x47,0xf1,0x1a,0x71,0x1d,0x29,0xc5,0x89,0x6f,0xb7,0x62,0x0e,0xaa,0x18,0xbe,0x1b,
    0xfc,0x56,0x3e,0x4b,0xc6,0xd2,0x79,0x20,0x9a,0xdb,0xc0,0xfe,0x78,0xcd,0x5a,0xf4,
    0x1f,0xdd,0xa8,0x33,0x88,0x07,0xc7,0x31,0xb1,0x12,0x10,0x59,0x27,0x80,0xec,0x5f,
    0x60,0x51,0x7f,0xa9,0x19,0xb5,0x4a,0x0d,0x2d,0xe5,0x7a,0x9f,0x93,0xc9,0x9c,0xef,
    0xa0,0xe0,0x3b,0x4d,0xae,0x2a,0xf5,0xb0,0xc8,0xeb,0xbb,0x3c,0x83,0x53,0x99,0x61,
    0x17,0x2b,0x04,0x7e,0xba,0x77,0xd6,0x26,0xe1,0x69,0x14,0x63,0x55,0x21,0x0c,0x7d
};

static uint8_t aes_xtime(uint8_t x)
{
    return (uint8_t)((uint8_t)(x << 1) ^ ((x >> 7) * 0x1bU));
}

static uint8_t aes_mul(uint8_t a, uint8_t b)
{
    uint8_t r = 0;
    while (b != 0) {
        if (b & 1U)
            r ^= a;
        a = aes_xtime(a);
        b >>= 1;
    }
    return r;
}

static void aes_add_round_key(uint8_t s[16], const uint8_t rk[16])
{
    size_t i;
    for (i = 0; i < 16; ++i)
        s[i] ^= rk[i];
}

static void aes_sub_bytes(uint8_t s[16], const uint8_t box[256])
{
    size_t i;
    for (i = 0; i < 16; ++i)
        s[i] = box[s[i]];
}

static void aes_shift_rows(uint8_t s[16])
{
    uint8_t t[16];
    size_t r, c;
    for (c = 0; c < 4; ++c)
        for (r = 0; r < 4; ++r)
            t[4 * c + r] = s[4 * ((c + r) & 3U) + r];
    memcpy(s, t, sizeof(t));
}

static void aes_inv_shift_rows(uint8_t s[16])
{
    uint8_t t[16];
    size_t r, c;
    for (c = 0; c < 4; ++c)
        for (r = 0; r < 4; ++r)
            t[4 * c + r] = s[4 * ((c + 4U - r) & 3U) + r];
    memcpy(s, t, sizeof(t));
}

static void aes_mix_columns(uint8_t s[16])
{
    size_t c;
    for (c = 0; c < 4; ++c) {
        uint8_t *a = s + 4 * c;
        uint8_t a0 = a[0], a1 = a[1], a2 = a[2], a3 = a[3];
        a[0] = (uint8_t)(aes_mul(a0, 2) ^ aes_mul(a1, 3) ^ a2 ^ a3);
        a[1] = (uint8_t)(a0 ^ aes_mul(a1, 2) ^ aes_mul(a2, 3) ^ a3);
        a[2] = (uint8_t)(a0 ^ a1 ^ aes_mul(a2, 2) ^ aes_mul(a3, 3));
        a[3] = (uint8_t)(aes_mul(a0, 3) ^ a1 ^ a2 ^ aes_mul(a3, 2));
    }
}

static void aes_inv_mix_columns(uint8_t s[16])
{
    size_t c;
    for (c = 0; c < 4; ++c) {
        uint8_t *a = s + 4 * c;
        uint8_t a0 = a[0], a1 = a[1], a2 = a[2], a3 = a[3];
        a[0] = (uint8_t)(aes_mul(a0, 14) ^ aes_mul(a1, 11) ^
                         aes_mul(a2, 13) ^ aes_mul(a3, 9));
        a[1] = (uint8_t)(aes_mul(a0, 9) ^ aes_mul(a1, 14) ^
                         aes_mul(a2, 11) ^ aes_mul(a3, 13));
        a[2] = (uint8_t)(aes_mul(a0, 13) ^ aes_mul(a1, 9) ^
                         aes_mul(a2, 14) ^ aes_mul(a3, 11));
        a[3] = (uint8_t)(aes_mul(a0, 11) ^ aes_mul(a1, 13) ^
                         aes_mul(a2, 9) ^ aes_mul(a3, 14));
    }
}

void oc_aes128_init(oc_aes128_ctx *ctx, const uint8_t key[16])
{
    static const uint8_t rcon[10] = {
        0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1b,0x36
    };
    size_t round, i;

    memcpy(ctx->enc_round_keys[0], key, 16);
    for (round = 1; round <= 10; ++round) {
        const uint8_t *p = ctx->enc_round_keys[round - 1];
        uint8_t *q = ctx->enc_round_keys[round];
        q[0] = (uint8_t)(p[0] ^ aes_sbox[p[13]] ^ rcon[round - 1]);
        q[1] = (uint8_t)(p[1] ^ aes_sbox[p[14]]);
        q[2] = (uint8_t)(p[2] ^ aes_sbox[p[15]]);
        q[3] = (uint8_t)(p[3] ^ aes_sbox[p[12]]);
        for (i = 4; i < 16; ++i)
            q[i] = (uint8_t)(p[i] ^ q[i - 4]);
    }

    memcpy(ctx->dec_round_keys[0], ctx->enc_round_keys[10], 16);
    memcpy(ctx->dec_round_keys[10], ctx->enc_round_keys[0], 16);
    for (round = 1; round < 10; ++round) {
        memcpy(ctx->dec_round_keys[round],
               ctx->enc_round_keys[10 - round], 16);
        aes_inv_mix_columns(ctx->dec_round_keys[round]);
    }
}

static void aes_basic_one(const oc_aes128_ctx *ctx, uint8_t *out,
                          const uint8_t *in, int decrypt)
{
    uint8_t s[16];
    size_t round;
    memcpy(s, in, 16);

    if (!decrypt) {
        aes_add_round_key(s, ctx->enc_round_keys[0]);
        for (round = 1; round < 10; ++round) {
            aes_sub_bytes(s, aes_sbox);
            aes_shift_rows(s);
            aes_mix_columns(s);
            aes_add_round_key(s, ctx->enc_round_keys[round]);
        }
        aes_sub_bytes(s, aes_sbox);
        aes_shift_rows(s);
        aes_add_round_key(s, ctx->enc_round_keys[10]);
    } else {
        aes_add_round_key(s, ctx->enc_round_keys[10]);
        for (round = 9; round != 0; --round) {
            aes_inv_shift_rows(s);
            aes_sub_bytes(s, aes_inv_sbox);
            aes_add_round_key(s, ctx->enc_round_keys[round]);
            aes_inv_mix_columns(s);
        }
        aes_inv_shift_rows(s);
        aes_sub_bytes(s, aes_inv_sbox);
        aes_add_round_key(s, ctx->enc_round_keys[0]);
    }
    memcpy(out, s, 16);
}

static void aes_basic_encrypt(const void *vctx, uint8_t *out,
                              const uint8_t *in, size_t blocks)
{
    const oc_aes128_ctx *ctx = (const oc_aes128_ctx *)vctx;
    size_t i;
    for (i = 0; i < blocks; ++i)
        aes_basic_one(ctx, out + 16 * i, in + 16 * i, 0);
}

static void aes_basic_decrypt(const void *vctx, uint8_t *out,
                              const uint8_t *in, size_t blocks)
{
    const oc_aes128_ctx *ctx = (const oc_aes128_ctx *)vctx;
    size_t i;
    for (i = 0; i < blocks; ++i)
        aes_basic_one(ctx, out + 16 * i, in + 16 * i, 1);
}

void oc_aes128_ttable_init(oc_aes128_ttable_ctx *ctx,
                           const uint8_t key[16])
{
    size_t i;
    oc_aes128_init(&ctx->base, key);
    for (i = 0; i < 256; ++i) {
        uint32_t s = aes_sbox[i];
        uint32_t s2 = aes_mul((uint8_t)s, 2);
        uint32_t s3 = aes_mul((uint8_t)s, 3);
        uint32_t d = aes_inv_sbox[i];
        uint32_t d9 = aes_mul((uint8_t)d, 9);
        uint32_t db = aes_mul((uint8_t)d, 11);
        uint32_t dd = aes_mul((uint8_t)d, 13);
        uint32_t de = aes_mul((uint8_t)d, 14);
        ctx->enc_table[0][i] = (s2 << 24) | (s << 16) | (s << 8) | s3;
        ctx->enc_table[1][i] = (s3 << 24) | (s2 << 16) | (s << 8) | s;
        ctx->enc_table[2][i] = (s << 24) | (s3 << 16) | (s2 << 8) | s;
        ctx->enc_table[3][i] = (s << 24) | (s << 16) | (s3 << 8) | s2;
        ctx->dec_table[0][i] = (de << 24) | (d9 << 16) | (dd << 8) | db;
        ctx->dec_table[1][i] = (db << 24) | (de << 16) | (d9 << 8) | dd;
        ctx->dec_table[2][i] = (dd << 24) | (db << 16) | (de << 8) | d9;
        ctx->dec_table[3][i] = (d9 << 24) | (dd << 16) | (db << 8) | de;
    }
}

static uint32_t aes_enc_tword(const oc_aes128_ttable_ctx *ctx,
                              uint32_t a, uint32_t b,
                              uint32_t c, uint32_t d)
{
    return ctx->enc_table[0][a >> 24] ^
           ctx->enc_table[1][(b >> 16) & 0xffU] ^
           ctx->enc_table[2][(c >> 8) & 0xffU] ^
           ctx->enc_table[3][d & 0xffU];
}

static uint32_t aes_dec_tword(const oc_aes128_ttable_ctx *ctx,
                              uint32_t a, uint32_t b,
                              uint32_t c, uint32_t d)
{
    return ctx->dec_table[0][a >> 24] ^
           ctx->dec_table[1][(b >> 16) & 0xffU] ^
           ctx->dec_table[2][(c >> 8) & 0xffU] ^
           ctx->dec_table[3][d & 0xffU];
}

static void aes_ttable_one(const oc_aes128_ttable_ctx *ctx, uint8_t *out,
                           const uint8_t *in, int decrypt)
{
    uint32_t s0, s1, s2, s3, t0, t1, t2, t3;
    size_t round;

    if (!decrypt) {
        s0 = oc_load32_be(in) ^ oc_load32_be(ctx->base.enc_round_keys[0]);
        s1 = oc_load32_be(in + 4) ^ oc_load32_be(ctx->base.enc_round_keys[0] + 4);
        s2 = oc_load32_be(in + 8) ^ oc_load32_be(ctx->base.enc_round_keys[0] + 8);
        s3 = oc_load32_be(in + 12) ^ oc_load32_be(ctx->base.enc_round_keys[0] + 12);
        for (round = 1; round < 10; ++round) {
            const uint8_t *rk = ctx->base.enc_round_keys[round];
            t0 = aes_enc_tword(ctx, s0, s1, s2, s3) ^ oc_load32_be(rk);
            t1 = aes_enc_tword(ctx, s1, s2, s3, s0) ^ oc_load32_be(rk + 4);
            t2 = aes_enc_tword(ctx, s2, s3, s0, s1) ^ oc_load32_be(rk + 8);
            t3 = aes_enc_tword(ctx, s3, s0, s1, s2) ^ oc_load32_be(rk + 12);
            s0 = t0; s1 = t1; s2 = t2; s3 = t3;
        }
        t0 = ((uint32_t)aes_sbox[s0 >> 24] << 24) |
             ((uint32_t)aes_sbox[(s1 >> 16) & 0xffU] << 16) |
             ((uint32_t)aes_sbox[(s2 >> 8) & 0xffU] << 8) |
             aes_sbox[s3 & 0xffU];
        t1 = ((uint32_t)aes_sbox[s1 >> 24] << 24) |
             ((uint32_t)aes_sbox[(s2 >> 16) & 0xffU] << 16) |
             ((uint32_t)aes_sbox[(s3 >> 8) & 0xffU] << 8) |
             aes_sbox[s0 & 0xffU];
        t2 = ((uint32_t)aes_sbox[s2 >> 24] << 24) |
             ((uint32_t)aes_sbox[(s3 >> 16) & 0xffU] << 16) |
             ((uint32_t)aes_sbox[(s0 >> 8) & 0xffU] << 8) |
             aes_sbox[s1 & 0xffU];
        t3 = ((uint32_t)aes_sbox[s3 >> 24] << 24) |
             ((uint32_t)aes_sbox[(s0 >> 16) & 0xffU] << 16) |
             ((uint32_t)aes_sbox[(s1 >> 8) & 0xffU] << 8) |
             aes_sbox[s2 & 0xffU];
        t0 ^= oc_load32_be(ctx->base.enc_round_keys[10]);
        t1 ^= oc_load32_be(ctx->base.enc_round_keys[10] + 4);
        t2 ^= oc_load32_be(ctx->base.enc_round_keys[10] + 8);
        t3 ^= oc_load32_be(ctx->base.enc_round_keys[10] + 12);
    } else {
        s0 = oc_load32_be(in) ^ oc_load32_be(ctx->base.dec_round_keys[0]);
        s1 = oc_load32_be(in + 4) ^ oc_load32_be(ctx->base.dec_round_keys[0] + 4);
        s2 = oc_load32_be(in + 8) ^ oc_load32_be(ctx->base.dec_round_keys[0] + 8);
        s3 = oc_load32_be(in + 12) ^ oc_load32_be(ctx->base.dec_round_keys[0] + 12);
        for (round = 1; round < 10; ++round) {
            const uint8_t *rk = ctx->base.dec_round_keys[round];
            t0 = aes_dec_tword(ctx, s0, s3, s2, s1) ^ oc_load32_be(rk);
            t1 = aes_dec_tword(ctx, s1, s0, s3, s2) ^ oc_load32_be(rk + 4);
            t2 = aes_dec_tword(ctx, s2, s1, s0, s3) ^ oc_load32_be(rk + 8);
            t3 = aes_dec_tword(ctx, s3, s2, s1, s0) ^ oc_load32_be(rk + 12);
            s0 = t0; s1 = t1; s2 = t2; s3 = t3;
        }
        t0 = ((uint32_t)aes_inv_sbox[s0 >> 24] << 24) |
             ((uint32_t)aes_inv_sbox[(s3 >> 16) & 0xffU] << 16) |
             ((uint32_t)aes_inv_sbox[(s2 >> 8) & 0xffU] << 8) |
             aes_inv_sbox[s1 & 0xffU];
        t1 = ((uint32_t)aes_inv_sbox[s1 >> 24] << 24) |
             ((uint32_t)aes_inv_sbox[(s0 >> 16) & 0xffU] << 16) |
             ((uint32_t)aes_inv_sbox[(s3 >> 8) & 0xffU] << 8) |
             aes_inv_sbox[s2 & 0xffU];
        t2 = ((uint32_t)aes_inv_sbox[s2 >> 24] << 24) |
             ((uint32_t)aes_inv_sbox[(s1 >> 16) & 0xffU] << 16) |
             ((uint32_t)aes_inv_sbox[(s0 >> 8) & 0xffU] << 8) |
             aes_inv_sbox[s3 & 0xffU];
        t3 = ((uint32_t)aes_inv_sbox[s3 >> 24] << 24) |
             ((uint32_t)aes_inv_sbox[(s2 >> 16) & 0xffU] << 16) |
             ((uint32_t)aes_inv_sbox[(s1 >> 8) & 0xffU] << 8) |
             aes_inv_sbox[s0 & 0xffU];
        t0 ^= oc_load32_be(ctx->base.dec_round_keys[10]);
        t1 ^= oc_load32_be(ctx->base.dec_round_keys[10] + 4);
        t2 ^= oc_load32_be(ctx->base.dec_round_keys[10] + 8);
        t3 ^= oc_load32_be(ctx->base.dec_round_keys[10] + 12);
    }

    oc_store32_be(out, t0);
    oc_store32_be(out + 4, t1);
    oc_store32_be(out + 8, t2);
    oc_store32_be(out + 12, t3);
}

static void aes_ttable_encrypt(const void *vctx, uint8_t *out,
                               const uint8_t *in, size_t blocks)
{
    const oc_aes128_ttable_ctx *ctx = (const oc_aes128_ttable_ctx *)vctx;
    size_t i;
    for (i = 0; i < blocks; ++i)
        aes_ttable_one(ctx, out + 16 * i, in + 16 * i, 0);
}

static void aes_ttable_decrypt(const void *vctx, uint8_t *out,
                               const uint8_t *in, size_t blocks)
{
    const oc_aes128_ttable_ctx *ctx = (const oc_aes128_ttable_ctx *)vctx;
    size_t i;
    for (i = 0; i < blocks; ++i)
        aes_ttable_one(ctx, out + 16 * i, in + 16 * i, 1);
}

#if OC_X86
OC_TARGET("avx2")
static __m256i aes_gather_word(const uint32_t table[4][256],
                               __m256i a, __m256i b,
                               __m256i c, __m256i d)
{
    const __m256i mask = _mm256_set1_epi32(0xff);
    __m256i i0 = _mm256_and_si256(_mm256_srli_epi32(a, 24), mask);
    __m256i i1 = _mm256_and_si256(_mm256_srli_epi32(b, 16), mask);
    __m256i i2 = _mm256_and_si256(_mm256_srli_epi32(c, 8), mask);
    __m256i i3 = _mm256_and_si256(d, mask);
    __m256i y0 = _mm256_i32gather_epi32(
        (const int *)(const void *)table[0], i0, 4);
    __m256i y1 = _mm256_i32gather_epi32(
        (const int *)(const void *)table[1], i1, 4);
    __m256i y2 = _mm256_i32gather_epi32(
        (const int *)(const void *)table[2], i2, 4);
    __m256i y3 = _mm256_i32gather_epi32(
        (const int *)(const void *)table[3], i3, 4);
    return _mm256_xor_si256(_mm256_xor_si256(y0, y1),
                            _mm256_xor_si256(y2, y3));
}

OC_TARGET("avx2")
static void aes_avx2_eight(const oc_aes128_ttable_ctx *ctx, uint8_t *out,
                           const uint8_t *in, int decrypt)
{
    uint32_t lane[4][8];
    __m256i s0, s1, s2, s3, t0, t1, t2, t3;
    const uint8_t (*keys)[16] = decrypt ? ctx->base.dec_round_keys
                                        : ctx->base.enc_round_keys;
    size_t i, j;

    for (j = 0; j < 8; ++j)
        for (i = 0; i < 4; ++i)
            lane[i][j] = oc_load32_be(in + 16 * j + 4 * i);
    s0 = _mm256_xor_si256(
        _mm256_loadu_si256((const __m256i *)(const void *)lane[0]),
        _mm256_set1_epi32((int)oc_load32_be(keys[0])));
    s1 = _mm256_xor_si256(
        _mm256_loadu_si256((const __m256i *)(const void *)lane[1]),
        _mm256_set1_epi32((int)oc_load32_be(keys[0] + 4)));
    s2 = _mm256_xor_si256(
        _mm256_loadu_si256((const __m256i *)(const void *)lane[2]),
        _mm256_set1_epi32((int)oc_load32_be(keys[0] + 8)));
    s3 = _mm256_xor_si256(
        _mm256_loadu_si256((const __m256i *)(const void *)lane[3]),
        _mm256_set1_epi32((int)oc_load32_be(keys[0] + 12)));

    for (i = 1; i < 10; ++i) {
        const uint32_t (*table)[256] = decrypt ? ctx->dec_table
                                               : ctx->enc_table;
        if (!decrypt) {
            t0 = aes_gather_word(table, s0, s1, s2, s3);
            t1 = aes_gather_word(table, s1, s2, s3, s0);
            t2 = aes_gather_word(table, s2, s3, s0, s1);
            t3 = aes_gather_word(table, s3, s0, s1, s2);
        } else {
            t0 = aes_gather_word(table, s0, s3, s2, s1);
            t1 = aes_gather_word(table, s1, s0, s3, s2);
            t2 = aes_gather_word(table, s2, s1, s0, s3);
            t3 = aes_gather_word(table, s3, s2, s1, s0);
        }
        s0 = _mm256_xor_si256(
            t0, _mm256_set1_epi32((int)oc_load32_be(keys[i])));
        s1 = _mm256_xor_si256(
            t1, _mm256_set1_epi32((int)oc_load32_be(keys[i] + 4)));
        s2 = _mm256_xor_si256(
            t2, _mm256_set1_epi32((int)oc_load32_be(keys[i] + 8)));
        s3 = _mm256_xor_si256(
            t3, _mm256_set1_epi32((int)oc_load32_be(keys[i] + 12)));
    }

    _mm256_storeu_si256((__m256i *)(void *)lane[0], s0);
    _mm256_storeu_si256((__m256i *)(void *)lane[1], s1);
    _mm256_storeu_si256((__m256i *)(void *)lane[2], s2);
    _mm256_storeu_si256((__m256i *)(void *)lane[3], s3);

    for (j = 0; j < 8; ++j) {
        uint32_t a = lane[0][j], b = lane[1][j];
        uint32_t c = lane[2][j], d = lane[3][j];
        uint32_t z0, z1, z2, z3;
        if (!decrypt) {
            z0 = ((uint32_t)aes_sbox[a >> 24] << 24) |
                 ((uint32_t)aes_sbox[(b >> 16) & 0xffU] << 16) |
                 ((uint32_t)aes_sbox[(c >> 8) & 0xffU] << 8) |
                 aes_sbox[d & 0xffU];
            z1 = ((uint32_t)aes_sbox[b >> 24] << 24) |
                 ((uint32_t)aes_sbox[(c >> 16) & 0xffU] << 16) |
                 ((uint32_t)aes_sbox[(d >> 8) & 0xffU] << 8) |
                 aes_sbox[a & 0xffU];
            z2 = ((uint32_t)aes_sbox[c >> 24] << 24) |
                 ((uint32_t)aes_sbox[(d >> 16) & 0xffU] << 16) |
                 ((uint32_t)aes_sbox[(a >> 8) & 0xffU] << 8) |
                 aes_sbox[b & 0xffU];
            z3 = ((uint32_t)aes_sbox[d >> 24] << 24) |
                 ((uint32_t)aes_sbox[(a >> 16) & 0xffU] << 16) |
                 ((uint32_t)aes_sbox[(b >> 8) & 0xffU] << 8) |
                 aes_sbox[c & 0xffU];
        } else {
            z0 = ((uint32_t)aes_inv_sbox[a >> 24] << 24) |
                 ((uint32_t)aes_inv_sbox[(d >> 16) & 0xffU] << 16) |
                 ((uint32_t)aes_inv_sbox[(c >> 8) & 0xffU] << 8) |
                 aes_inv_sbox[b & 0xffU];
            z1 = ((uint32_t)aes_inv_sbox[b >> 24] << 24) |
                 ((uint32_t)aes_inv_sbox[(a >> 16) & 0xffU] << 16) |
                 ((uint32_t)aes_inv_sbox[(d >> 8) & 0xffU] << 8) |
                 aes_inv_sbox[c & 0xffU];
            z2 = ((uint32_t)aes_inv_sbox[c >> 24] << 24) |
                 ((uint32_t)aes_inv_sbox[(b >> 16) & 0xffU] << 16) |
                 ((uint32_t)aes_inv_sbox[(a >> 8) & 0xffU] << 8) |
                 aes_inv_sbox[d & 0xffU];
            z3 = ((uint32_t)aes_inv_sbox[d >> 24] << 24) |
                 ((uint32_t)aes_inv_sbox[(c >> 16) & 0xffU] << 16) |
                 ((uint32_t)aes_inv_sbox[(b >> 8) & 0xffU] << 8) |
                 aes_inv_sbox[a & 0xffU];
        }
        oc_store32_be(out + 16 * j,
                      z0 ^ oc_load32_be(keys[10]));
        oc_store32_be(out + 16 * j + 4,
                      z1 ^ oc_load32_be(keys[10] + 4));
        oc_store32_be(out + 16 * j + 8,
                      z2 ^ oc_load32_be(keys[10] + 8));
        oc_store32_be(out + 16 * j + 12,
                      z3 ^ oc_load32_be(keys[10] + 12));
    }
}
#endif

static void aes_avx2_crypt(const oc_aes128_ttable_ctx *ctx, uint8_t *out,
                           const uint8_t *in, size_t blocks, int decrypt)
{
    size_t done = 0;
#if OC_X86
    if (oc_cpu_has_avx2()) {
        while (blocks - done >= 8) {
            aes_avx2_eight(ctx, out + 16 * done, in + 16 * done, decrypt);
            done += 8;
        }
    }
#endif
    while (done < blocks) {
        aes_ttable_one(ctx, out + 16 * done, in + 16 * done, decrypt);
        ++done;
    }
}

static void aes_avx2_encrypt(const void *vctx, uint8_t *out,
                             const uint8_t *in, size_t blocks)
{
    aes_avx2_crypt((const oc_aes128_ttable_ctx *)vctx,
                   out, in, blocks, 0);
}

static void aes_avx2_decrypt(const void *vctx, uint8_t *out,
                             const uint8_t *in, size_t blocks)
{
    aes_avx2_crypt((const oc_aes128_ttable_ctx *)vctx,
                   out, in, blocks, 1);
}

void oc_aes128_shuffle_init(oc_aes128_shuffle_ctx *ctx,
                            const uint8_t key[16])
{
    size_t h, l;
    oc_aes128_init(&ctx->base, key);
    for (h = 0; h < 16; ++h) {
        for (l = 0; l < 16; ++l) {
            ctx->sbox_sub[h][l] = aes_sbox[16 * h + l];
            ctx->inv_sbox_sub[h][l] = aes_inv_sbox[16 * h + l];
        }
    }
}

#if OC_X86
OC_TARGET("ssse3,sse2")
static __m128i aes_shuffle_subbytes(
    const uint8_t table[16][16], __m128i x)
{
    const __m128i nibble = _mm_set1_epi8(0x0f);
    __m128i lo = _mm_and_si128(x, nibble);
    __m128i hi = _mm_and_si128(_mm_srli_epi16(x, 4), nibble);
    __m128i result = _mm_setzero_si128();
    size_t i;
    for (i = 0; i < 16; ++i) {
        __m128i sub = _mm_loadu_si128(
            (const __m128i *)(const void *)table[i]);
        __m128i value = _mm_shuffle_epi8(sub, lo);
        __m128i select = _mm_cmpeq_epi8(hi, _mm_set1_epi8((char)i));
        result = _mm_or_si128(result, _mm_and_si128(value, select));
    }
    return result;
}

OC_TARGET("ssse3,sse2")
static __m128i aes_shuffle_xtime(__m128i x)
{
    __m128i carry = _mm_cmpgt_epi8(_mm_setzero_si128(), x);
    return _mm_xor_si128(_mm_add_epi8(x, x),
                         _mm_and_si128(carry, _mm_set1_epi8(0x1b)));
}

OC_TARGET("ssse3,sse2")
static __m128i aes_shuffle_mix_columns(__m128i x)
{
    static const uint8_t rot1_bytes[16] = {
        1,2,3,0, 5,6,7,4, 9,10,11,8, 13,14,15,12
    };
    static const uint8_t rot2_bytes[16] = {
        2,3,0,1, 6,7,4,5, 10,11,8,9, 14,15,12,13
    };
    static const uint8_t rot3_bytes[16] = {
        3,0,1,2, 7,4,5,6, 11,8,9,10, 15,12,13,14
    };
    __m128i r1 = _mm_shuffle_epi8(
        x, _mm_loadu_si128((const __m128i *)(const void *)rot1_bytes));
    __m128i r2 = _mm_shuffle_epi8(
        x, _mm_loadu_si128((const __m128i *)(const void *)rot2_bytes));
    __m128i r3 = _mm_shuffle_epi8(
        x, _mm_loadu_si128((const __m128i *)(const void *)rot3_bytes));
    __m128i all = _mm_xor_si128(_mm_xor_si128(x, r1),
                                _mm_xor_si128(r2, r3));
    return _mm_xor_si128(_mm_xor_si128(x, all),
                         aes_shuffle_xtime(_mm_xor_si128(x, r1)));
}

OC_TARGET("ssse3,sse2")
static __m128i aes_shuffle_inv_mix_columns(__m128i x)
{
    static const uint8_t rot1_bytes[16] = {
        1,2,3,0, 5,6,7,4, 9,10,11,8, 13,14,15,12
    };
    static const uint8_t rot2_bytes[16] = {
        2,3,0,1, 6,7,4,5, 10,11,8,9, 14,15,12,13
    };
    static const uint8_t rot3_bytes[16] = {
        3,0,1,2, 7,4,5,6, 11,8,9,10, 15,12,13,14
    };
    __m128i x2 = aes_shuffle_xtime(x);
    __m128i x4 = aes_shuffle_xtime(x2);
    __m128i x8 = aes_shuffle_xtime(x4);
    __m128i m9 = _mm_xor_si128(x8, x);
    __m128i mb = _mm_xor_si128(_mm_xor_si128(x8, x2), x);
    __m128i md = _mm_xor_si128(_mm_xor_si128(x8, x4), x);
    __m128i me = _mm_xor_si128(_mm_xor_si128(x8, x4), x2);
    __m128i r1 = _mm_shuffle_epi8(
        mb, _mm_loadu_si128((const __m128i *)(const void *)rot1_bytes));
    __m128i r2 = _mm_shuffle_epi8(
        md, _mm_loadu_si128((const __m128i *)(const void *)rot2_bytes));
    __m128i r3 = _mm_shuffle_epi8(
        m9, _mm_loadu_si128((const __m128i *)(const void *)rot3_bytes));
    return _mm_xor_si128(_mm_xor_si128(me, r1),
                         _mm_xor_si128(r2, r3));
}

OC_TARGET("ssse3,sse2")
static __m128i aes_shuffle_rows(__m128i x, int inverse)
{
    static const uint8_t shift[16] = {
        0,5,10,15, 4,9,14,3, 8,13,2,7, 12,1,6,11
    };
    static const uint8_t inv_shift[16] = {
        0,13,10,7, 4,1,14,11, 8,5,2,15, 12,9,6,3
    };
    const uint8_t *mask = inverse ? inv_shift : shift;
    return _mm_shuffle_epi8(
        x, _mm_loadu_si128((const __m128i *)(const void *)mask));
}

OC_TARGET("ssse3,sse2")
static void aes_shuffle_one(const oc_aes128_shuffle_ctx *ctx, uint8_t *out,
                            const uint8_t *in, int decrypt)
{
    __m128i x = _mm_loadu_si128((const __m128i *)(const void *)in);
    size_t round;
    if (!decrypt) {
        x = _mm_xor_si128(x, _mm_loadu_si128(
            (const __m128i *)(const void *)ctx->base.enc_round_keys[0]));
        for (round = 1; round < 10; ++round) {
            x = aes_shuffle_subbytes(ctx->sbox_sub, x);
            x = aes_shuffle_rows(x, 0);
            x = aes_shuffle_mix_columns(x);
            x = _mm_xor_si128(x, _mm_loadu_si128(
                (const __m128i *)(const void *)
                ctx->base.enc_round_keys[round]));
        }
        x = aes_shuffle_subbytes(ctx->sbox_sub, x);
        x = aes_shuffle_rows(x, 0);
        x = _mm_xor_si128(x, _mm_loadu_si128(
            (const __m128i *)(const void *)ctx->base.enc_round_keys[10]));
    } else {
        x = _mm_xor_si128(x, _mm_loadu_si128(
            (const __m128i *)(const void *)ctx->base.enc_round_keys[10]));
        for (round = 9; round != 0; --round) {
            x = aes_shuffle_rows(x, 1);
            x = aes_shuffle_subbytes(ctx->inv_sbox_sub, x);
            x = _mm_xor_si128(x, _mm_loadu_si128(
                (const __m128i *)(const void *)
                ctx->base.enc_round_keys[round]));
            x = aes_shuffle_inv_mix_columns(x);
        }
        x = aes_shuffle_rows(x, 1);
        x = aes_shuffle_subbytes(ctx->inv_sbox_sub, x);
        x = _mm_xor_si128(x, _mm_loadu_si128(
            (const __m128i *)(const void *)ctx->base.enc_round_keys[0]));
    }
    _mm_storeu_si128((__m128i *)(void *)out, x);
}

OC_TARGET("avx2")
static __m256i aes_shuffle_subbytes256(
    const uint8_t table[16][16], __m256i x)
{
    const __m256i nibble = _mm256_set1_epi8(0x0f);
    __m256i lo = _mm256_and_si256(x, nibble);
    __m256i hi = _mm256_and_si256(_mm256_srli_epi16(x, 4), nibble);
    __m256i result = _mm256_setzero_si256();
    size_t i;
    for (i = 0; i < 16; ++i) {
        __m128i sub128 = _mm_loadu_si128(
            (const __m128i *)(const void *)table[i]);
        __m256i sub = _mm256_broadcastsi128_si256(sub128);
        __m256i value = _mm256_shuffle_epi8(sub, lo);
        __m256i select = _mm256_cmpeq_epi8(
            hi, _mm256_set1_epi8((char)i));
        result = _mm256_or_si256(
            result, _mm256_and_si256(value, select));
    }
    return result;
}

OC_TARGET("avx2")
static __m256i aes_shuffle_xtime256(__m256i x)
{
    __m256i carry = _mm256_cmpgt_epi8(_mm256_setzero_si256(), x);
    return _mm256_xor_si256(
        _mm256_add_epi8(x, x),
        _mm256_and_si256(carry, _mm256_set1_epi8(0x1b)));
}

OC_TARGET("avx2")
static __m256i aes_shuffle_mask256(const uint8_t mask[16])
{
    return _mm256_broadcastsi128_si256(_mm_loadu_si128(
        (const __m128i *)(const void *)mask));
}

OC_TARGET("avx2")
static __m256i aes_shuffle_mix_columns256(__m256i x)
{
    static const uint8_t rot1_bytes[16] = {
        1,2,3,0, 5,6,7,4, 9,10,11,8, 13,14,15,12
    };
    static const uint8_t rot2_bytes[16] = {
        2,3,0,1, 6,7,4,5, 10,11,8,9, 14,15,12,13
    };
    static const uint8_t rot3_bytes[16] = {
        3,0,1,2, 7,4,5,6, 11,8,9,10, 15,12,13,14
    };
    __m256i r1 = _mm256_shuffle_epi8(
        x, aes_shuffle_mask256(rot1_bytes));
    __m256i r2 = _mm256_shuffle_epi8(
        x, aes_shuffle_mask256(rot2_bytes));
    __m256i r3 = _mm256_shuffle_epi8(
        x, aes_shuffle_mask256(rot3_bytes));
    __m256i all = _mm256_xor_si256(_mm256_xor_si256(x, r1),
                                   _mm256_xor_si256(r2, r3));
    return _mm256_xor_si256(
        _mm256_xor_si256(x, all),
        aes_shuffle_xtime256(_mm256_xor_si256(x, r1)));
}

OC_TARGET("avx2")
static __m256i aes_shuffle_inv_mix_columns256(__m256i x)
{
    static const uint8_t rot1_bytes[16] = {
        1,2,3,0, 5,6,7,4, 9,10,11,8, 13,14,15,12
    };
    static const uint8_t rot2_bytes[16] = {
        2,3,0,1, 6,7,4,5, 10,11,8,9, 14,15,12,13
    };
    static const uint8_t rot3_bytes[16] = {
        3,0,1,2, 7,4,5,6, 11,8,9,10, 15,12,13,14
    };
    __m256i x2 = aes_shuffle_xtime256(x);
    __m256i x4 = aes_shuffle_xtime256(x2);
    __m256i x8 = aes_shuffle_xtime256(x4);
    __m256i m9 = _mm256_xor_si256(x8, x);
    __m256i mb = _mm256_xor_si256(_mm256_xor_si256(x8, x2), x);
    __m256i md = _mm256_xor_si256(_mm256_xor_si256(x8, x4), x);
    __m256i me = _mm256_xor_si256(_mm256_xor_si256(x8, x4), x2);
    __m256i r1 = _mm256_shuffle_epi8(
        mb, aes_shuffle_mask256(rot1_bytes));
    __m256i r2 = _mm256_shuffle_epi8(
        md, aes_shuffle_mask256(rot2_bytes));
    __m256i r3 = _mm256_shuffle_epi8(
        m9, aes_shuffle_mask256(rot3_bytes));
    return _mm256_xor_si256(_mm256_xor_si256(me, r1),
                            _mm256_xor_si256(r2, r3));
}

OC_TARGET("avx2")
static __m256i aes_shuffle_rows256(__m256i x, int inverse)
{
    static const uint8_t shift[16] = {
        0,5,10,15, 4,9,14,3, 8,13,2,7, 12,1,6,11
    };
    static const uint8_t inv_shift[16] = {
        0,13,10,7, 4,1,14,11, 8,5,2,15, 12,9,6,3
    };
    return _mm256_shuffle_epi8(
        x, aes_shuffle_mask256(inverse ? inv_shift : shift));
}

/* Four YMM registers hold two independent AES blocks per 128-bit lane. */
OC_TARGET("avx2")
static void aes_shuffle_eight(const oc_aes128_shuffle_ctx *ctx,
                              uint8_t *out, const uint8_t *in,
                              int decrypt)
{
    __m256i x[4];
    __m256i rk;
    size_t i, round;

    for (i = 0; i < 4; ++i)
        x[i] = _mm256_loadu_si256(
            (const __m256i *)(const void *)(in + 32 * i));

    if (!decrypt) {
        rk = _mm256_broadcastsi128_si256(_mm_loadu_si128(
            (const __m128i *)(const void *)
            ctx->base.enc_round_keys[0]));
        for (i = 0; i < 4; ++i)
            x[i] = _mm256_xor_si256(x[i], rk);
        for (round = 1; round < 10; ++round) {
            rk = _mm256_broadcastsi128_si256(_mm_loadu_si128(
                (const __m128i *)(const void *)
                ctx->base.enc_round_keys[round]));
            for (i = 0; i < 4; ++i) {
                x[i] = aes_shuffle_subbytes256(ctx->sbox_sub, x[i]);
                x[i] = aes_shuffle_rows256(x[i], 0);
                x[i] = aes_shuffle_mix_columns256(x[i]);
                x[i] = _mm256_xor_si256(x[i], rk);
            }
        }
        rk = _mm256_broadcastsi128_si256(_mm_loadu_si128(
            (const __m128i *)(const void *)
            ctx->base.enc_round_keys[10]));
        for (i = 0; i < 4; ++i) {
            x[i] = aes_shuffle_subbytes256(ctx->sbox_sub, x[i]);
            x[i] = aes_shuffle_rows256(x[i], 0);
            x[i] = _mm256_xor_si256(x[i], rk);
        }
    } else {
        rk = _mm256_broadcastsi128_si256(_mm_loadu_si128(
            (const __m128i *)(const void *)
            ctx->base.enc_round_keys[10]));
        for (i = 0; i < 4; ++i)
            x[i] = _mm256_xor_si256(x[i], rk);
        for (round = 9; round != 0; --round) {
            rk = _mm256_broadcastsi128_si256(_mm_loadu_si128(
                (const __m128i *)(const void *)
                ctx->base.enc_round_keys[round]));
            for (i = 0; i < 4; ++i) {
                x[i] = aes_shuffle_rows256(x[i], 1);
                x[i] = aes_shuffle_subbytes256(
                    ctx->inv_sbox_sub, x[i]);
                x[i] = _mm256_xor_si256(x[i], rk);
                x[i] = aes_shuffle_inv_mix_columns256(x[i]);
            }
        }
        rk = _mm256_broadcastsi128_si256(_mm_loadu_si128(
            (const __m128i *)(const void *)
            ctx->base.enc_round_keys[0]));
        for (i = 0; i < 4; ++i) {
            x[i] = aes_shuffle_rows256(x[i], 1);
            x[i] = aes_shuffle_subbytes256(ctx->inv_sbox_sub, x[i]);
            x[i] = _mm256_xor_si256(x[i], rk);
        }
    }

    for (i = 0; i < 4; ++i)
        _mm256_storeu_si256(
            (__m256i *)(void *)(out + 32 * i), x[i]);
}
#endif

static void aes_shuffle_crypt(const oc_aes128_shuffle_ctx *ctx,
                              uint8_t *out, const uint8_t *in,
                              size_t blocks, int decrypt)
{
    size_t done = 0;
#if OC_X86
    if (oc_cpu_has_avx2()) {
        while (blocks - done >= 8) {
            aes_shuffle_eight(ctx, out + 16 * done,
                              in + 16 * done, decrypt);
            done += 8;
        }
    }
    if (oc_cpu_has_ssse3()) {
        while (done < blocks) {
            aes_shuffle_one(ctx, out + 16 * done,
                            in + 16 * done, decrypt);
            ++done;
        }
    }
#endif
    while (done < blocks) {
        aes_basic_one(&ctx->base, out + 16 * done,
                      in + 16 * done, decrypt);
        ++done;
    }
}

static void aes_shuffle_encrypt(const void *vctx, uint8_t *out,
                                const uint8_t *in, size_t blocks)
{
    aes_shuffle_crypt((const oc_aes128_shuffle_ctx *)vctx,
                      out, in, blocks, 0);
}

static void aes_shuffle_decrypt(const void *vctx, uint8_t *out,
                                const uint8_t *in, size_t blocks)
{
    aes_shuffle_crypt((const oc_aes128_shuffle_ctx *)vctx,
                      out, in, blocks, 1);
}

void oc_aes128_aesni_init(oc_aes128_aesni_ctx *ctx,
                          const uint8_t key[16])
{
    oc_aes128_init(&ctx->base, key);
}

#if OC_X86
OC_TARGET("aes,sse2")
static void aes_aesni_one(const oc_aes128_aesni_ctx *ctx, uint8_t *out,
                          const uint8_t *in, int decrypt)
{
    const uint8_t (*keys)[16] = decrypt ? ctx->base.dec_round_keys
                                        : ctx->base.enc_round_keys;
    __m128i x = _mm_loadu_si128((const __m128i *)(const void *)in);
    size_t round;
    x = _mm_xor_si128(x, _mm_loadu_si128(
        (const __m128i *)(const void *)keys[0]));
    for (round = 1; round < 10; ++round) {
        __m128i rk = _mm_loadu_si128(
            (const __m128i *)(const void *)keys[round]);
        x = decrypt ? _mm_aesdec_si128(x, rk) : _mm_aesenc_si128(x, rk);
    }
    if (decrypt)
        x = _mm_aesdeclast_si128(x, _mm_loadu_si128(
            (const __m128i *)(const void *)keys[10]));
    else
        x = _mm_aesenclast_si128(x, _mm_loadu_si128(
            (const __m128i *)(const void *)keys[10]));
    _mm_storeu_si128((__m128i *)(void *)out, x);
}

OC_TARGET("aes,sse2")
static void aes_aesni_eight(const oc_aes128_aesni_ctx *ctx, uint8_t *out,
                            const uint8_t *in, int decrypt)
{
    const uint8_t (*keys)[16] = decrypt ? ctx->base.dec_round_keys
                                        : ctx->base.enc_round_keys;
    __m128i x[8];
    __m128i rk;
    size_t i, round;
    rk = _mm_loadu_si128((const __m128i *)(const void *)keys[0]);
    for (i = 0; i < 8; ++i)
        x[i] = _mm_xor_si128(_mm_loadu_si128(
            (const __m128i *)(const void *)(in + 16 * i)), rk);
    for (round = 1; round < 10; ++round) {
        rk = _mm_loadu_si128(
            (const __m128i *)(const void *)keys[round]);
        for (i = 0; i < 8; ++i)
            x[i] = decrypt ? _mm_aesdec_si128(x[i], rk)
                           : _mm_aesenc_si128(x[i], rk);
    }
    rk = _mm_loadu_si128((const __m128i *)(const void *)keys[10]);
    for (i = 0; i < 8; ++i) {
        x[i] = decrypt ? _mm_aesdeclast_si128(x[i], rk)
                       : _mm_aesenclast_si128(x[i], rk);
        _mm_storeu_si128((__m128i *)(void *)(out + 16 * i), x[i]);
    }
}
#endif

static void aes_aesni_crypt(const oc_aes128_aesni_ctx *ctx, uint8_t *out,
                            const uint8_t *in, size_t blocks, int decrypt)
{
    size_t done = 0;
#if OC_X86
    if (oc_cpu_has_aesni()) {
        while (blocks - done >= 8) {
            aes_aesni_eight(ctx, out + 16 * done, in + 16 * done, decrypt);
            done += 8;
        }
        while (done < blocks) {
            aes_aesni_one(ctx, out + 16 * done, in + 16 * done, decrypt);
            ++done;
        }
        return;
    }
#endif
    while (done < blocks) {
        aes_basic_one(&ctx->base, out + 16 * done,
                      in + 16 * done, decrypt);
        ++done;
    }
}

static void aes_aesni_encrypt(const void *vctx, uint8_t *out,
                              const uint8_t *in, size_t blocks)
{
    aes_aesni_crypt((const oc_aes128_aesni_ctx *)vctx,
                    out, in, blocks, 0);
}

static void aes_aesni_decrypt(const void *vctx, uint8_t *out,
                              const uint8_t *in, size_t blocks)
{
    aes_aesni_crypt((const oc_aes128_aesni_ctx *)vctx,
                    out, in, blocks, 1);
}

oc_cipher oc_aes128_basic_cipher(const oc_aes128_ctx *ctx)
{
    oc_cipher c = {ctx, 16, aes_basic_encrypt, aes_basic_decrypt,
                   "AES-128-basic"};
    return c;
}

oc_cipher oc_aes128_ttable_cipher(const oc_aes128_ttable_ctx *ctx)
{
    oc_cipher c = {ctx, 16, aes_ttable_encrypt, aes_ttable_decrypt,
                   "AES-128-T-table"};
    return c;
}

oc_cipher oc_aes128_avx2_gather_cipher(const oc_aes128_ttable_ctx *ctx)
{
    oc_cipher c = {ctx, 16, aes_avx2_encrypt, aes_avx2_decrypt,
                   "AES-128-AVX2-gather"};
    return c;
}

oc_cipher oc_aes128_shuffle_cipher(const oc_aes128_shuffle_ctx *ctx)
{
    oc_cipher c = {ctx, 16, aes_shuffle_encrypt, aes_shuffle_decrypt,
                   "AES-128-AVX2-shuffle"};
    return c;
}

oc_cipher oc_aes128_aesni_cipher(const oc_aes128_aesni_ctx *ctx)
{
    oc_cipher c = {ctx, 16, aes_aesni_encrypt, aes_aesni_decrypt,
                   "AES-128-AES-NI"};
    return c;
}
