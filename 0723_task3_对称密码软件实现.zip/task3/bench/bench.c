#include "optcrypto.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
static double now_seconds(void)
{
    LARGE_INTEGER counter, frequency;
    QueryPerformanceCounter(&counter);
    QueryPerformanceFrequency(&frequency);
    return (double)counter.QuadPart / (double)frequency.QuadPart;
}
#else
#include <time.h>
static double now_seconds(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}
#endif

static volatile uint8_t bench_sink;

static size_t calibrated_repeats(double one_run)
{
    const double target = 0.25;
    size_t repeats;
    if (one_run <= 0.0)
        return 10;
    repeats = (size_t)(target / one_run) + 1;
    if (repeats > 1000)
        repeats = 1000;
    return repeats;
}

static void print_result(const char *name, size_t bytes, size_t repeats,
                         double elapsed)
{
    double total = (double)bytes * (double)repeats;
    double mib_s = total / elapsed / 1048576.0;
    double ns_byte = elapsed * 1e9 / total;
    printf("| %-29s | %10.2f | %9.3f |\n", name, mib_s, ns_byte);
}

static void bench_cipher(const oc_cipher *cipher, uint8_t *out,
                         const uint8_t *in, size_t bytes)
{
    size_t blocks = bytes / cipher->block_size;
    size_t used = blocks * cipher->block_size;
    size_t repeats, i;
    double start, elapsed;
    start = now_seconds();
    cipher->encrypt_blocks(cipher->ctx, out, in, blocks);
    elapsed = now_seconds() - start;
    repeats = calibrated_repeats(elapsed);
    start = now_seconds();
    for (i = 0; i < repeats; ++i)
        cipher->encrypt_blocks(cipher->ctx, out, in, blocks);
    elapsed = now_seconds() - start;
    bench_sink ^= out[(repeats * 17U) % used];
    print_result(cipher->name, used, repeats, elapsed);
}

static void bench_ctr(const oc_cipher *cipher, uint8_t *out,
                      const uint8_t *in, size_t bytes, const char *name)
{
    uint8_t counter[16];
    size_t repeats, i;
    double start, elapsed;
    memset(counter, 0x3c, sizeof(counter));
    start = now_seconds();
    oc_ctr_xor(cipher, out, in, bytes, counter);
    elapsed = now_seconds() - start;
    repeats = calibrated_repeats(elapsed);
    start = now_seconds();
    for (i = 0; i < repeats; ++i) {
        memset(counter, 0x3c, sizeof(counter));
        oc_ctr_xor(cipher, out, in, bytes, counter);
    }
    elapsed = now_seconds() - start;
    bench_sink ^= out[(repeats * 19U) % bytes];
    print_result(name, bytes, repeats, elapsed);
}

static void bench_gcm(const oc_cipher *cipher, uint8_t *out,
                      const uint8_t *in, size_t bytes, oc_ghash_impl impl,
                      const char *name)
{
    static const uint8_t aad[20] = {
        0xfe,0xed,0xfa,0xce,0xde,0xad,0xbe,0xef,0xfe,0xed,
        0xfa,0xce,0xde,0xad,0xbe,0xef,0xab,0xad,0xda,0xd2
    };
    static const uint8_t nonce[12] = {0,0,0x12,0x34,0x56,0x78,0,0,0,0,0xab,0xcd};
    uint8_t tag[16];
    size_t repeats, i;
    double start, elapsed;
    start = now_seconds();
    oc_gcm_encrypt(cipher, out, in, bytes, aad, sizeof(aad), nonce,
                   sizeof(nonce), tag, impl);
    elapsed = now_seconds() - start;
    repeats = calibrated_repeats(elapsed);
    start = now_seconds();
    for (i = 0; i < repeats; ++i)
        oc_gcm_encrypt(cipher, out, in, bytes, aad, sizeof(aad), nonce,
                       sizeof(nonce), tag, impl);
    elapsed = now_seconds() - start;
    bench_sink ^= tag[repeats & 15U];
    print_result(name, bytes, repeats, elapsed);
}

static void bench_xts(const oc_cipher *data, const oc_cipher *tweak,
                      uint8_t *out, const uint8_t *in, size_t bytes,
                      const char *name)
{
    uint8_t unit[16] = {0};
    size_t repeats, i;
    double start, elapsed;
    unit[0] = 7;
    start = now_seconds();
    oc_xts_encrypt(data, tweak, out, in, bytes, unit);
    elapsed = now_seconds() - start;
    repeats = calibrated_repeats(elapsed);
    start = now_seconds();
    for (i = 0; i < repeats; ++i)
        oc_xts_encrypt(data, tweak, out, in, bytes, unit);
    elapsed = now_seconds() - start;
    bench_sink ^= out[(repeats * 23U) % bytes];
    print_result(name, bytes, repeats, elapsed);
}

static void bench_gcm64(const oc_cipher *cipher, uint8_t *out,
                        const uint8_t *in, size_t bytes, const char *name)
{
    static const uint8_t aad[20] = {
        0xfe,0xed,0xfa,0xce,0xde,0xad,0xbe,0xef,0xfe,0xed,
        0xfa,0xce,0xde,0xad,0xbe,0xef,0xab,0xad,0xda,0xd2
    };
    static const uint8_t nonce[8] = {0x12,0x34,0x56,0x78,0xab,0xcd,0xef,0x01};
    uint8_t tag[8];
    size_t repeats, i;
    double start, elapsed;
    start = now_seconds();
    oc_gcm64_encrypt(cipher, out, in, bytes, aad, sizeof(aad), nonce,
                     sizeof(nonce), tag);
    elapsed = now_seconds() - start;
    repeats = calibrated_repeats(elapsed);
    start = now_seconds();
    for (i = 0; i < repeats; ++i)
        oc_gcm64_encrypt(cipher, out, in, bytes, aad, sizeof(aad), nonce,
                         sizeof(nonce), tag);
    elapsed = now_seconds() - start;
    bench_sink ^= tag[repeats & 7U];
    print_result(name, bytes, repeats, elapsed);
}

static void bench_xts64(const oc_cipher *data, const oc_cipher *tweak,
                        uint8_t *out, const uint8_t *in, size_t bytes,
                        const char *name)
{
    uint8_t unit[8] = {0};
    size_t repeats, i;
    double start, elapsed;
    unit[0] = 7;
    start = now_seconds();
    oc_xts64_encrypt(data, tweak, out, in, bytes, unit);
    elapsed = now_seconds() - start;
    repeats = calibrated_repeats(elapsed);
    start = now_seconds();
    for (i = 0; i < repeats; ++i)
        oc_xts64_encrypt(data, tweak, out, in, bytes, unit);
    elapsed = now_seconds() - start;
    bench_sink ^= out[(repeats * 23U) % bytes];
    print_result(name, bytes, repeats, elapsed);
}

static size_t parse_bytes(int argc, char **argv)
{
    size_t bytes = 1024U * 1024U;
    int i;
    for (i = 1; i + 1 < argc; ++i)
        if (strcmp(argv[i], "--bytes") == 0) {
            unsigned long long value = strtoull(argv[i + 1], NULL, 10);
            if (value >= 4096 && value <= (unsigned long long)1024 * 1024 * 1024)
                bytes = (size_t)value;
        }
    return bytes;
}

int main(int argc, char **argv)
{
    static oc_aes128_ctx aes_basic_ctx, aes_tweak_basic_ctx;
    static oc_aes128_ttable_ctx aes_table_ctx, aes_tweak_table_ctx;
    static oc_aes128_shuffle_ctx aes_shuffle_ctx, aes_tweak_shuffle_ctx;
    static oc_aes128_aesni_ctx aes_aesni_ctx, aes_tweak_aesni_ctx;
    static oc_sm4_ctx sm4_basic_ctx;
    static oc_sm4_ttable_ctx sm4_data_ctx, sm4_tweak_ctx;
    static oc_sm4_shuffle_ctx sm4_shuffle_ctx;
    static oc_gift128_ctx gift_basic_ctx;
    static oc_gift128_ttable_ctx gift_table_ctx;
    static oc_gift128_fix_ctx gift_fix_ctx, gift_tweak_ctx;
    static oc_twine80_ctx twine_basic_ctx;
    static oc_twine80_ttable_ctx twine_table_ctx;
    static oc_twine80_fix_ctx twine_fix_ctx;
    uint8_t key1[16], key2[16], twine_key[10];
    uint8_t *input, *output;
    size_t bytes = parse_bytes(argc, argv), i;
    oc_cipher aes_basic, aes_table, aes_gather, aes_shuffle, aes_aesni;
    oc_cipher aes_tweak_basic, aes_tweak_table, aes_tweak_shuffle, aes_tweak_aesni;
    oc_cipher sm4_basic, sm4_table, sm4_avx, sm4_shuffle, sm4_tweak;
    oc_cipher gift_basic, gift_table, gift_avx, gift_fix, gift_avx_fix, gift_tweak;
    oc_cipher twine_basic, twine_table, twine_avx, twine_fix, twine_gather;

    input = (uint8_t *)malloc(bytes);
    output = (uint8_t *)malloc(bytes);
    if (!input || !output) {
        fprintf(stderr, "allocation failed for %zu bytes\n", bytes);
        free(input);
        free(output);
        return EXIT_FAILURE;
    }
    for (i = 0; i < bytes; ++i)
        input[i] = (uint8_t)(i * 29U + i / 251U);
    for (i = 0; i < sizeof(key1); ++i) {
        key1[i] = (uint8_t)(i * 17U + 3U);
        key2[i] = (uint8_t)(i * 31U + 9U);
    }
    for (i = 0; i < sizeof(twine_key); ++i)
        twine_key[i] = (uint8_t)(i * 23U + 5U);

    oc_aes128_init(&aes_basic_ctx, key1);
    oc_aes128_init(&aes_tweak_basic_ctx, key2);
    oc_aes128_ttable_init(&aes_table_ctx, key1);
    oc_aes128_ttable_init(&aes_tweak_table_ctx, key2);
    oc_aes128_shuffle_init(&aes_shuffle_ctx, key1);
    oc_aes128_shuffle_init(&aes_tweak_shuffle_ctx, key2);
    oc_aes128_aesni_init(&aes_aesni_ctx, key1);
    oc_aes128_aesni_init(&aes_tweak_aesni_ctx, key2);
    oc_sm4_init(&sm4_basic_ctx, key1);
    oc_sm4_ttable_init(&sm4_data_ctx, key1);
    oc_sm4_ttable_init(&sm4_tweak_ctx, key2);
    oc_sm4_shuffle_init(&sm4_shuffle_ctx, key1);
    oc_gift128_init(&gift_basic_ctx, key1);
    oc_gift128_ttable_init(&gift_table_ctx, key1);
    oc_gift128_fix_init(&gift_fix_ctx, key1);
    oc_gift128_fix_init(&gift_tweak_ctx, key2);
    oc_twine80_init(&twine_basic_ctx, twine_key);
    oc_twine80_ttable_init(&twine_table_ctx, twine_key);
    oc_twine80_fix_init(&twine_fix_ctx, twine_key);

    aes_basic = oc_aes128_basic_cipher(&aes_basic_ctx);
    aes_tweak_basic = oc_aes128_basic_cipher(&aes_tweak_basic_ctx);
    aes_table = oc_aes128_ttable_cipher(&aes_table_ctx);
    aes_gather = oc_aes128_avx2_gather_cipher(&aes_table_ctx);
    aes_shuffle = oc_aes128_shuffle_cipher(&aes_shuffle_ctx);
    aes_aesni = oc_aes128_aesni_cipher(&aes_aesni_ctx);
    aes_tweak_table = oc_aes128_ttable_cipher(&aes_tweak_table_ctx);
    aes_tweak_shuffle = oc_aes128_shuffle_cipher(&aes_tweak_shuffle_ctx);
    aes_tweak_aesni = oc_aes128_aesni_cipher(&aes_tweak_aesni_ctx);
    sm4_basic = oc_sm4_basic_cipher(&sm4_basic_ctx);
    sm4_table = oc_sm4_ttable_cipher(&sm4_data_ctx);
    sm4_avx = oc_sm4_avx2_cipher(&sm4_data_ctx);
    sm4_shuffle = oc_sm4_shuffle_cipher(&sm4_shuffle_ctx);
    sm4_tweak = oc_sm4_avx2_cipher(&sm4_tweak_ctx);
    gift_basic = oc_gift128_basic_cipher(&gift_basic_ctx);
    gift_table = oc_gift128_ttable_cipher(&gift_table_ctx);
    gift_avx = oc_gift128_avx2_cipher(&gift_basic_ctx);
    gift_fix = oc_gift128_fix_cipher(&gift_fix_ctx);
    gift_avx_fix = oc_gift128_avx2_fix_cipher(&gift_fix_ctx);
    gift_tweak = oc_gift128_avx2_fix_cipher(&gift_tweak_ctx);
    twine_basic = oc_twine80_basic_cipher(&twine_basic_ctx);
    twine_table = oc_twine80_ttable_cipher(&twine_table_ctx);
    twine_avx = oc_twine80_avx2_cipher(&twine_basic_ctx);
    twine_fix = oc_twine80_fix_cipher(&twine_fix_ctx);
    twine_gather = oc_twine80_avx2_gather_cipher(&twine_table_ctx);

    printf("Buffer: %zu bytes; AVX2=%s; PCLMUL=%s; SSSE3=%s; AES-NI=%s\n\n", bytes,
           oc_cpu_has_avx2() ? "yes" : "no",
           oc_cpu_has_pclmul() ? "yes" : "no",
           oc_cpu_has_ssse3() ? "yes" : "no",
           oc_cpu_has_aesni() ? "yes" : "no");
    printf("| implementation                |      MiB/s |   ns/byte |\n");
    printf("|-------------------------------|------------|-----------|\n");
    bench_cipher(&aes_basic, output, input, bytes);
    bench_cipher(&aes_table, output, input, bytes);
    bench_cipher(&aes_gather, output, input, bytes);
    bench_cipher(&aes_shuffle, output, input, bytes);
    bench_cipher(&aes_aesni, output, input, bytes);
    bench_cipher(&sm4_basic, output, input, bytes);
    bench_cipher(&sm4_table, output, input, bytes);
    bench_cipher(&sm4_avx, output, input, bytes);
    bench_cipher(&sm4_shuffle, output, input, bytes);
    bench_cipher(&gift_basic, output, input, bytes);
    bench_cipher(&gift_table, output, input, bytes);
    bench_cipher(&gift_avx, output, input, bytes);
    bench_cipher(&gift_fix, output, input, bytes);
    bench_cipher(&gift_avx_fix, output, input, bytes);
    bench_cipher(&twine_basic, output, input, bytes);
    bench_cipher(&twine_table, output, input, bytes);
    bench_cipher(&twine_avx, output, input, bytes);
    bench_cipher(&twine_fix, output, input, bytes);
    bench_cipher(&twine_gather, output, input, bytes);

    printf("\n| mode                          |      MiB/s |   ns/byte |\n");
    printf("|-------------------------------|------------|-----------|\n");
    bench_ctr(&aes_basic, output, input, bytes, "CTR / AES basic");
    bench_ctr(&aes_table, output, input, bytes, "CTR / AES T-table");
    bench_ctr(&aes_gather, output, input, bytes, "CTR / AES AVX2 gather");
    bench_ctr(&aes_shuffle, output, input, bytes, "CTR / AES shuffle");
    bench_ctr(&aes_aesni, output, input, bytes, "CTR / AES-NI");
    bench_gcm(&aes_aesni, output, input, bytes, OC_GHASH_PORTABLE,
              "GCM / AES-NI + portable");
    bench_gcm(&aes_aesni, output, input, bytes, OC_GHASH_PCLMUL,
              "GCM / AES-NI + PCLMUL");
    bench_xts(&aes_basic, &aes_tweak_basic, output, input, bytes,
              "XTS / AES basic");
    bench_xts(&aes_table, &aes_tweak_table, output, input, bytes,
              "XTS / AES T-table");
    bench_xts(&aes_gather, &aes_tweak_table, output, input, bytes,
              "XTS / AES AVX2 gather");
    bench_xts(&aes_shuffle, &aes_tweak_shuffle, output, input, bytes,
              "XTS / AES shuffle");
    bench_xts(&aes_aesni, &aes_tweak_aesni, output, input, bytes,
              "XTS / AES-NI");
    bench_ctr(&sm4_table, output, input, bytes, "CTR / SM4 T-table");
    bench_ctr(&sm4_avx, output, input, bytes, "CTR / SM4 AVX2 gather");
    bench_ctr(&sm4_shuffle, output, input, bytes, "CTR / SM4 AVX2 shuffle");
    bench_ctr(&gift_fix, output, input, bytes, "CTR / GIFT fixsliced");
    bench_ctr(&gift_avx_fix, output, input, bytes, "CTR / GIFT AVX2-fixsliced");
    bench_ctr(&twine_table, output, input, bytes, "CTR / TWINE T-table");
    bench_ctr(&twine_avx, output, input, bytes, "CTR / TWINE AVX2 shuffle");
    bench_gcm(&sm4_avx, output, input, bytes, OC_GHASH_PORTABLE,
              "GCM / portable GHASH");
    bench_gcm(&sm4_avx, output, input, bytes, OC_GHASH_PCLMUL,
              "GCM / PCLMUL GHASH");
    bench_gcm(&gift_avx_fix, output, input, bytes, OC_GHASH_PORTABLE,
              "GCM / GIFT AVX2-fixsliced + portable");
    bench_gcm(&gift_avx_fix, output, input, bytes, OC_GHASH_PCLMUL,
              "GCM / GIFT AVX2-fixsliced + PCLMUL");
    bench_gcm64(&twine_table, output, input, bytes, "GCM-64 / TWINE T-table");
    bench_gcm64(&twine_avx, output, input, bytes, "GCM-64 / TWINE AVX2");
    bench_xts(&sm4_avx, &sm4_tweak, output, input, bytes,
              "XTS / SM4 AVX2");
    bench_xts(&gift_avx_fix, &gift_tweak, output, input, bytes,
              "XTS / GIFT AVX2-fixsliced");
    bench_xts64(&twine_table, &twine_table, output, input, bytes,
                "XTS-64 / TWINE T-table");
    bench_xts64(&twine_avx, &twine_avx, output, input, bytes,
                "XTS-64 / TWINE AVX2");

    free(input);
    free(output);
    (void)bench_sink;
    return EXIT_SUCCESS;
}
