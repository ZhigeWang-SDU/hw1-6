#include "optcrypto.h"
#include "internal.h"

#include <string.h>

#if OC_X86
#include <immintrin.h>
#endif

static const uint8_t twine_sbox[16] = {
    0xc,0x0,0xf,0xa,0x2,0xb,0x9,0x5,0x8,0x3,0xd,0x7,0x1,0xe,0x6,0x4
};

static const uint8_t twine_pi[16] = {
    5,0,1,4,7,12,3,8,13,6,9,2,15,10,11,14
};

static const uint8_t twine_inv_pi[16] = {
    1,2,11,6,3,0,9,4,7,10,13,14,5,8,15,12
};

static const uint8_t twine_con[35] = {
    0x01,0x02,0x04,0x08,0x10,0x20,0x03,0x06,0x0c,0x18,
    0x30,0x23,0x05,0x0a,0x14,0x28,0x13,0x26,0x0f,0x1e,
    0x3c,0x3b,0x35,0x29,0x11,0x22,0x07,0x0e,0x1c,0x38,
    0x33,0x25,0x09,0x12,0x24
};

static void twine_store_round_key(oc_twine80_ctx *ctx, size_t r,
                                  const uint8_t wk[20])
{
    static const uint8_t pick[8] = {1,3,4,6,13,14,15,16};
    size_t i;
    memset(ctx->round_key_lanes[r], 0, 16);
    for (i = 0; i < 8; ++i) {
        uint8_t k = wk[pick[i]];
        ctx->round_key[r][i] = k;
        ctx->round_key_lanes[r][2 * i] = k;
        ctx->round_key_lanes[r][2 * i + 1] = k;
    }
}

void oc_twine80_init(oc_twine80_ctx *ctx, const uint8_t key[10])
{
    uint8_t wk[20], old[20];
    size_t i, r;
    for (i = 0; i < 10; ++i) {
        wk[2 * i] = (uint8_t)(key[i] >> 4);
        wk[2 * i + 1] = (uint8_t)(key[i] & 0x0f);
    }
    twine_store_round_key(ctx, 0, wk);
    for (r = 1; r < 36; ++r) {
        wk[1] ^= twine_sbox[wk[0]];
        wk[4] ^= twine_sbox[wk[16]];
        wk[7] ^= (uint8_t)(twine_con[r - 1] >> 3);
        wk[19] ^= (uint8_t)(twine_con[r - 1] & 7U);
        memcpy(old, wk, sizeof(old));
        for (i = 0; i < 16; ++i)
            wk[i] = old[i + 4];
        wk[16] = old[1];
        wk[17] = old[2];
        wk[18] = old[3];
        wk[19] = old[0];
        twine_store_round_key(ctx, r, wk);
    }
}

static void twine_bytes_to_nibbles(uint8_t state[16], const uint8_t in[8])
{
    size_t i;
    for (i = 0; i < 8; ++i) {
        state[2 * i] = (uint8_t)(in[i] >> 4);
        state[2 * i + 1] = (uint8_t)(in[i] & 0x0f);
    }
}

static void twine_nibbles_to_bytes(uint8_t out[8], const uint8_t state[16])
{
    size_t i;
    for (i = 0; i < 8; ++i)
        out[i] = (uint8_t)((state[2 * i] << 4) | state[2 * i + 1]);
}

static void twine_f(uint8_t state[16], const uint8_t rk[8])
{
    size_t i;
    for (i = 0; i < 8; ++i)
        state[2 * i + 1] ^= twine_sbox[state[2 * i] ^ rk[i]];
}

static void twine_permute(uint8_t state[16], const uint8_t map[16])
{
    uint8_t tmp[16];
    size_t i;
    for (i = 0; i < 16; ++i)
        tmp[map[i]] = state[i];
    memcpy(state, tmp, 16);
}

static void twine_basic_one(const oc_twine80_ctx *ctx, uint8_t *out,
                            const uint8_t *in, int decrypt)
{
    uint8_t state[16];
    size_t r;
    twine_bytes_to_nibbles(state, in);
    if (!decrypt) {
        for (r = 0; r < 35; ++r) {
            twine_f(state, ctx->round_key[r]);
            twine_permute(state, twine_pi);
        }
        twine_f(state, ctx->round_key[35]);
    } else {
        twine_f(state, ctx->round_key[35]);
        for (r = 35; r-- > 0;) {
            twine_permute(state, twine_inv_pi);
            twine_f(state, ctx->round_key[r]);
        }
    }
    twine_nibbles_to_bytes(out, state);
}

static void twine_basic_encrypt(const void *vctx, uint8_t *out,
                                const uint8_t *in, size_t blocks)
{
    const oc_twine80_ctx *ctx = (const oc_twine80_ctx *)vctx;
    size_t i;
    for (i = 0; i < blocks; ++i)
        twine_basic_one(ctx, out + 8 * i, in + 8 * i, 0);
}

static void twine_basic_decrypt(const void *vctx, uint8_t *out,
                                const uint8_t *in, size_t blocks)
{
    const oc_twine80_ctx *ctx = (const oc_twine80_ctx *)vctx;
    size_t i;
    for (i = 0; i < blocks; ++i)
        twine_basic_one(ctx, out + 8 * i, in + 8 * i, 1);
}

static uint64_t twine_place_nibble(uint64_t word, size_t nibble, uint8_t value)
{
    unsigned shift = (unsigned)(60 - 4 * nibble);
    return word | ((uint64_t)(value & 0x0f) << shift);
}

void oc_twine80_ttable_init(oc_twine80_ttable_ctx *ctx,
                            const uint8_t key[10])
{
    size_t k, value, pos;
    oc_twine80_init(&ctx->base, key);
    for (k = 0; k < 16; ++k)
        for (value = 0; value < 256; ++value) {
            uint8_t hi = (uint8_t)(value >> 4);
            uint8_t lo = (uint8_t)(value & 0x0f);
            ctx->ftable[k][value] = (uint8_t)((hi << 4) |
                                      (lo ^ twine_sbox[hi ^ k]));
        }
    for (pos = 0; pos < 8; ++pos)
        for (value = 0; value < 256; ++value) {
            uint8_t hi = (uint8_t)(value >> 4);
            uint8_t lo = (uint8_t)(value & 0x0f);
            uint64_t p = 0, ip = 0;
            p = twine_place_nibble(p, twine_pi[2 * pos], hi);
            p = twine_place_nibble(p, twine_pi[2 * pos + 1], lo);
            ip = twine_place_nibble(ip, twine_inv_pi[2 * pos], hi);
            ip = twine_place_nibble(ip, twine_inv_pi[2 * pos + 1], lo);
            ctx->ptable[pos][value] = p;
            ctx->inv_ptable[pos][value] = ip;
        }
}

static uint64_t twine_t_f(const oc_twine80_ttable_ctx *ctx, uint64_t state,
                          const uint8_t rk[8])
{
    uint64_t out = 0;
    size_t i;
    for (i = 0; i < 8; ++i) {
        uint8_t b = (uint8_t)(state >> (56 - 8 * i));
        out |= (uint64_t)ctx->ftable[rk[i]][b] << (56 - 8 * i);
    }
    return out;
}

static uint64_t twine_t_perm(const uint64_t table[8][256], uint64_t state)
{
    uint64_t out = 0;
    size_t i;
    for (i = 0; i < 8; ++i)
        out |= table[i][(uint8_t)(state >> (56 - 8 * i))];
    return out;
}

static void twine_ttable_one(const oc_twine80_ttable_ctx *ctx, uint8_t *out,
                             const uint8_t *in, int decrypt)
{
    uint64_t state = oc_load64_be(in);
    size_t r;
    if (!decrypt) {
        for (r = 0; r < 35; ++r) {
            state = twine_t_f(ctx, state, ctx->base.round_key[r]);
            state = twine_t_perm(ctx->ptable, state);
        }
        state = twine_t_f(ctx, state, ctx->base.round_key[35]);
    } else {
        state = twine_t_f(ctx, state, ctx->base.round_key[35]);
        for (r = 35; r-- > 0;) {
            state = twine_t_perm(ctx->inv_ptable, state);
            state = twine_t_f(ctx, state, ctx->base.round_key[r]);
        }
    }
    oc_store64_be(out, state);
}

static void twine_ttable_encrypt(const void *vctx, uint8_t *out,
                                 const uint8_t *in, size_t blocks)
{
    const oc_twine80_ttable_ctx *ctx = (const oc_twine80_ttable_ctx *)vctx;
    size_t i;
    for (i = 0; i < blocks; ++i)
        twine_ttable_one(ctx, out + 8 * i, in + 8 * i, 0);
}

static void twine_ttable_decrypt(const void *vctx, uint8_t *out,
                                 const uint8_t *in, size_t blocks)
{
    const oc_twine80_ttable_ctx *ctx = (const oc_twine80_ttable_ctx *)vctx;
    size_t i;
    for (i = 0; i < blocks; ++i)
        twine_ttable_one(ctx, out + 8 * i, in + 8 * i, 1);
}

#if OC_X86
OC_TARGET("avx2")
static void twine_avx2_pair(const oc_twine80_ctx *ctx, uint8_t *out,
                            const uint8_t *in, int decrypt)
{
    static const uint8_t sbox16[16] = {
        12,0,15,10,2,11,9,5,8,3,13,7,1,14,6,4
    };
    static const uint8_t even_dup16[16] = {
        0,0,2,2,4,4,6,6,8,8,10,10,12,12,14,14
    };
    static const uint8_t odd16[16] = {
        0,0xff,0,0xff,0,0xff,0,0xff,0,0xff,0,0xff,0,0xff,0,0xff
    };
    uint8_t lanes[32];
    __m128i box128 = _mm_loadu_si128((const __m128i *)(const void *)sbox16);
    __m128i dup128 = _mm_loadu_si128((const __m128i *)(const void *)even_dup16);
    __m128i odd128 = _mm_loadu_si128((const __m128i *)(const void *)odd16);
    __m128i pi128 = _mm_loadu_si128((const __m128i *)(const void *)twine_pi);
    __m128i inv128 = _mm_loadu_si128((const __m128i *)(const void *)twine_inv_pi);
    __m256i box = _mm256_broadcastsi128_si256(box128);
    __m256i dup = _mm256_broadcastsi128_si256(dup128);
    __m256i odd = _mm256_broadcastsi128_si256(odd128);
    __m256i p_mask = _mm256_broadcastsi128_si256(inv128);
    __m256i inv_mask = _mm256_broadcastsi128_si256(pi128);
    __m256i state;
    size_t b, i, r;

    for (b = 0; b < 2; ++b)
        twine_bytes_to_nibbles(lanes + 16 * b, in + 8 * b);
    state = _mm256_loadu_si256((const __m256i *)(const void *)lanes);

#define TWINE_AVX_F(round_index) do {                                      \
    __m256i rk128 = _mm256_broadcastsi128_si256(                           \
        _mm_loadu_si128((const __m128i *)(const void *)                    \
                        ctx->round_key_lanes[(round_index)]));             \
    __m256i even = _mm256_shuffle_epi8(state, dup);                        \
    __m256i sub = _mm256_shuffle_epi8(box, _mm256_xor_si256(even, rk128)); \
    state = _mm256_xor_si256(state, _mm256_and_si256(sub, odd));           \
} while (0)

    if (!decrypt) {
        for (r = 0; r < 35; ++r) {
            TWINE_AVX_F(r);
            state = _mm256_shuffle_epi8(state, p_mask);
        }
        TWINE_AVX_F(35);
    } else {
        TWINE_AVX_F(35);
        for (r = 35; r-- > 0;) {
            state = _mm256_shuffle_epi8(state, inv_mask);
            TWINE_AVX_F(r);
        }
    }
#undef TWINE_AVX_F

    _mm256_storeu_si256((__m256i *)(void *)lanes, state);
    for (b = 0; b < 2; ++b) {
        for (i = 0; i < 16; ++i)
            lanes[16 * b + i] &= 0x0f;
        twine_nibbles_to_bytes(out + 8 * b, lanes + 16 * b);
    }
}
#endif

static void twine_avx2_crypt(const oc_twine80_ctx *ctx, uint8_t *out,
                             const uint8_t *in, size_t blocks, int decrypt)
{
    size_t done = 0;
#if OC_X86
    if (oc_cpu_has_avx2()) {
        while (blocks - done >= 2) {
            twine_avx2_pair(ctx, out + 8 * done, in + 8 * done, decrypt);
            done += 2;
        }
    }
#endif
    while (done < blocks) {
        twine_basic_one(ctx, out + 8 * done, in + 8 * done, decrypt);
        ++done;
    }
}

static void twine_avx2_encrypt(const void *vctx, uint8_t *out,
                               const uint8_t *in, size_t blocks)
{
    twine_avx2_crypt((const oc_twine80_ctx *)vctx, out, in, blocks, 0);
}

static void twine_avx2_decrypt(const void *vctx, uint8_t *out,
                               const uint8_t *in, size_t blocks)
{
    twine_avx2_crypt((const oc_twine80_ctx *)vctx, out, in, blocks, 1);
}

oc_cipher oc_twine80_basic_cipher(const oc_twine80_ctx *ctx)
{
    oc_cipher c = {ctx, 8, twine_basic_encrypt, twine_basic_decrypt,
                   "TWINE-80-basic"};
    return c;
}

oc_cipher oc_twine80_ttable_cipher(const oc_twine80_ttable_ctx *ctx)
{
    oc_cipher c = {ctx, 8, twine_ttable_encrypt, twine_ttable_decrypt,
                   "TWINE-80-T-table"};
    return c;
}

oc_cipher oc_twine80_avx2_cipher(const oc_twine80_ctx *ctx)
{
    oc_cipher c = {ctx, 8, twine_avx2_encrypt, twine_avx2_decrypt,
                   "TWINE-80-AVX2-shuffle"};
    return c;
}

#if OC_X86
OC_TARGET("avx2")
static void twine_avx2_gather_four(const oc_twine80_ttable_ctx *ctx,
                                   uint8_t *out, const uint8_t *in, int decrypt)
{
    uint64_t state[4];
    __m256i s;
    size_t b, i, r;

    /* Load 4 blocks as 64-bit integers */
    for (b = 0; b < 4; ++b)
        state[b] = oc_load64_be(in + 8 * b);

    s = _mm256_loadu_si256((const __m256i *)(const void *)state);

    if (!decrypt) {
        for (r = 0; r < 35; ++r) {
            /* F function using gather for S-box lookups */
            __m256i out_f = _mm256_setzero_si256();
            for (i = 0; i < 8; ++i) {
                __m256i byte_shifted = _mm256_srli_epi64(s, 56 - 8 * i);
                __m256i byte_vals = _mm256_and_si256(byte_shifted,
                                                     _mm256_set1_epi64x(0xFF));
                __m128i byte_lo = _mm256_castsi256_si128(byte_vals);
                __m128i byte_hi = _mm256_extracti128_si256(byte_vals, 1);

                /* Gather from ftable[rk[i]] */
                uint8_t rk_val = ctx->base.round_key[r][i];
                __m128i gathered_lo = _mm_i32gather_epi32(
                    (const int *)(const void *)ctx->ftable[rk_val],
                    byte_lo, 1);
                __m128i gathered_hi = _mm_i32gather_epi32(
                    (const int *)(const void *)ctx->ftable[rk_val],
                    byte_hi, 1);
                __m256i gathered_256 = _mm256_set_m128i(gathered_hi, gathered_lo);

                /* Extract byte and place in correct position */
                __m256i result_byte = _mm256_and_si256(gathered_256,
                                                       _mm256_set1_epi64x(0xFF));
                out_f = _mm256_or_si256(out_f,
                                        _mm256_slli_epi64(result_byte, 56 - 8 * i));
            }
            s = out_f;

            /* Permutation using gather from ptable */
            __m256i out_p = _mm256_setzero_si256();
            for (i = 0; i < 8; ++i) {
                __m256i byte_shifted = _mm256_srli_epi64(s, 56 - 8 * i);
                __m256i byte_vals = _mm256_and_si256(byte_shifted,
                                                     _mm256_set1_epi64x(0xFF));
                __m128i byte_lo = _mm256_castsi256_si128(byte_vals);
                __m128i byte_hi = _mm256_extracti128_si256(byte_vals, 1);

                __m128i perm_lo = _mm_i64gather_epi64(
                    (const long long *)(const void *)ctx->ptable[i],
                    byte_lo, 8);
                __m128i perm_hi = _mm_i64gather_epi64(
                    (const long long *)(const void *)ctx->ptable[i],
                    byte_hi, 8);
                __m256i perm_256 = _mm256_set_m128i(perm_hi, perm_lo);
                out_p = _mm256_or_si256(out_p, perm_256);
            }
            s = out_p;
        }
        /* Final F function */
        __m256i out_f = _mm256_setzero_si256();
        for (i = 0; i < 8; ++i) {
            __m256i byte_shifted = _mm256_srli_epi64(s, 56 - 8 * i);
            __m256i byte_vals = _mm256_and_si256(byte_shifted,
                                                 _mm256_set1_epi64x(0xFF));
            __m128i byte_lo = _mm256_castsi256_si128(byte_vals);
            __m128i byte_hi = _mm256_extracti128_si256(byte_vals, 1);

            uint8_t rk_val = ctx->base.round_key[35][i];
            __m128i gathered_lo = _mm_i32gather_epi32(
                (const int *)(const void *)ctx->ftable[rk_val],
                byte_lo, 1);
            __m128i gathered_hi = _mm_i32gather_epi32(
                (const int *)(const void *)ctx->ftable[rk_val],
                byte_hi, 1);
            __m256i gathered_256 = _mm256_set_m128i(gathered_hi, gathered_lo);

            __m256i result_byte = _mm256_and_si256(gathered_256,
                                                   _mm256_set1_epi64x(0xFF));
            out_f = _mm256_or_si256(out_f,
                                    _mm256_slli_epi64(result_byte, 56 - 8 * i));
        }
        s = out_f;
    } else {
        /* Decrypt path - similar but reversed */
        __m256i out_f = _mm256_setzero_si256();
        for (i = 0; i < 8; ++i) {
            __m256i byte_shifted = _mm256_srli_epi64(s, 56 - 8 * i);
            __m256i byte_vals = _mm256_and_si256(byte_shifted,
                                                 _mm256_set1_epi64x(0xFF));
            __m128i byte_lo = _mm256_castsi256_si128(byte_vals);
            __m128i byte_hi = _mm256_extracti128_si256(byte_vals, 1);

            uint8_t rk_val = ctx->base.round_key[35][i];
            __m128i gathered_lo = _mm_i32gather_epi32(
                (const int *)(const void *)ctx->ftable[rk_val],
                byte_lo, 1);
            __m128i gathered_hi = _mm_i32gather_epi32(
                (const int *)(const void *)ctx->ftable[rk_val],
                byte_hi, 1);
            __m256i gathered_256 = _mm256_set_m128i(gathered_hi, gathered_lo);

            __m256i result_byte = _mm256_and_si256(gathered_256,
                                                   _mm256_set1_epi64x(0xFF));
            out_f = _mm256_or_si256(out_f,
                                    _mm256_slli_epi64(result_byte, 56 - 8 * i));
        }
        s = out_f;

        for (r = 35; r-- > 0;) {
            /* Inverse permutation */
            __m256i out_p = _mm256_setzero_si256();
            for (i = 0; i < 8; ++i) {
                __m256i byte_shifted = _mm256_srli_epi64(s, 56 - 8 * i);
                __m256i byte_vals = _mm256_and_si256(byte_shifted,
                                                     _mm256_set1_epi64x(0xFF));
                __m128i byte_lo = _mm256_castsi256_si128(byte_vals);
                __m128i byte_hi = _mm256_extracti128_si256(byte_vals, 1);

                __m128i perm_lo = _mm_i64gather_epi64(
                    (const long long *)(const void *)ctx->inv_ptable[i],
                    byte_lo, 8);
                __m128i perm_hi = _mm_i64gather_epi64(
                    (const long long *)(const void *)ctx->inv_ptable[i],
                    byte_hi, 8);
                __m256i perm_256 = _mm256_set_m128i(perm_hi, perm_lo);
                out_p = _mm256_or_si256(out_p, perm_256);
            }
            s = out_p;

            /* F function */
            out_f = _mm256_setzero_si256();
            for (i = 0; i < 8; ++i) {
                __m256i byte_shifted = _mm256_srli_epi64(s, 56 - 8 * i);
                __m256i byte_vals = _mm256_and_si256(byte_shifted,
                                                     _mm256_set1_epi64x(0xFF));
                __m128i byte_lo = _mm256_castsi256_si128(byte_vals);
                __m128i byte_hi = _mm256_extracti128_si256(byte_vals, 1);

                uint8_t rk_val = ctx->base.round_key[r][i];
                __m128i gathered_lo = _mm_i32gather_epi32(
                    (const int *)(const void *)ctx->ftable[rk_val],
                    byte_lo, 1);
                __m128i gathered_hi = _mm_i32gather_epi32(
                    (const int *)(const void *)ctx->ftable[rk_val],
                    byte_hi, 1);
                __m256i gathered_256 = _mm256_set_m128i(gathered_hi, gathered_lo);

                __m256i result_byte = _mm256_and_si256(gathered_256,
                                                       _mm256_set1_epi64x(0xFF));
                out_f = _mm256_or_si256(out_f,
                                        _mm256_slli_epi64(result_byte, 56 - 8 * i));
            }
            s = out_f;
        }
    }

    _mm256_storeu_si256((__m256i *)(void *)state, s);
    for (b = 0; b < 4; ++b)
        oc_store64_be(out + 8 * b, state[b]);
}
#endif

static void twine_avx2_gather_crypt(const oc_twine80_ttable_ctx *ctx,
                                    uint8_t *out, const uint8_t *in,
                                    size_t blocks, int decrypt)
{
    size_t done = 0;
#if OC_X86
    if (oc_cpu_has_avx2()) {
        while (blocks - done >= 4) {
            twine_avx2_gather_four(ctx, out + 8 * done, in + 8 * done, decrypt);
            done += 4;
        }
    }
#endif
    while (done < blocks) {
        twine_ttable_one(ctx, out + 8 * done, in + 8 * done, decrypt);
        ++done;
    }
}

static void twine_avx2_gather_encrypt(const void *vctx, uint8_t *out,
                                      const uint8_t *in, size_t blocks)
{
    twine_avx2_gather_crypt((const oc_twine80_ttable_ctx *)vctx, out, in,
                            blocks, 0);
}

static void twine_avx2_gather_decrypt(const void *vctx, uint8_t *out,
                                      const uint8_t *in, size_t blocks)
{
    twine_avx2_gather_crypt((const oc_twine80_ttable_ctx *)vctx, out, in,
                            blocks, 1);
}

oc_cipher oc_twine80_avx2_gather_cipher(const oc_twine80_ttable_ctx *ctx)
{
    oc_cipher c = {ctx, 8, twine_avx2_gather_encrypt, twine_avx2_gather_decrypt,
                   "TWINE-80-AVX2-gather"};
    return c;
}
