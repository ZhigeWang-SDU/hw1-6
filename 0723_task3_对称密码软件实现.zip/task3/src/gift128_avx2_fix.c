/* Eight-block AVX2 fixsliced GIFT-128.
 *
 * The scalar fixsliced implementation in gift128_fix.c already removes the
 * bit permutation from the round loop.  This file keeps that layout and
 * broadcasts each 32-bit slice across eight SIMD lanes, so the same Boolean
 * circuit encrypts eight independent blocks in parallel.  It is the second
 * modern-ISA path for GIFT, while the pshufb path remains available through
 * oc_gift128_avx2_cipher().
 */
#include "optcrypto.h"
#include "internal.h"

#if OC_X86
#include <immintrin.h>

#define GIFT256_ROR(x, n) \
    _mm256_or_si256(_mm256_srli_epi32((x), (n)), \
                    _mm256_slli_epi32((x), 32 - (n)))
#define BYTE256_ROR_2(x) \
    _mm256_or_si256(_mm256_and_si256(_mm256_srli_epi32((x), 2), \
                                     _mm256_set1_epi32(0x3f3f3f3fU)), \
                    _mm256_slli_epi32(_mm256_and_si256((x), \
                                                        _mm256_set1_epi32(0x03030303U)), 6))
#define BYTE256_ROR_4(x) \
    _mm256_or_si256(_mm256_and_si256(_mm256_srli_epi32((x), 4), \
                                     _mm256_set1_epi32(0x0f0f0f0fU)), \
                    _mm256_slli_epi32(_mm256_and_si256((x), \
                                                        _mm256_set1_epi32(0x0f0f0f0fU)), 4))
#define BYTE256_ROR_6(x) \
    _mm256_or_si256(_mm256_and_si256(_mm256_srli_epi32((x), 6), \
                                     _mm256_set1_epi32(0x03030303U)), \
                    _mm256_slli_epi32(_mm256_and_si256((x), \
                                                        _mm256_set1_epi32(0x3f3f3f3fU)), 2))
#define HALF256_ROR_4(x) \
    _mm256_or_si256(_mm256_and_si256(_mm256_srli_epi32((x), 4), \
                                     _mm256_set1_epi32(0x0fff0fffU)), \
                    _mm256_slli_epi32(_mm256_and_si256((x), \
                                                        _mm256_set1_epi32(0x000f000fU)), 12))
#define HALF256_ROR_8(x) \
    _mm256_or_si256(_mm256_and_si256(_mm256_srli_epi32((x), 8), \
                                     _mm256_set1_epi32(0x00ff00ffU)), \
                    _mm256_slli_epi32(_mm256_and_si256((x), \
                                                        _mm256_set1_epi32(0x00ff00ffU)), 8))
#define HALF256_ROR_12(x) \
    _mm256_or_si256(_mm256_and_si256(_mm256_srli_epi32((x), 12), \
                                     _mm256_set1_epi32(0x000f000fU)), \
                    _mm256_slli_epi32(_mm256_and_si256((x), \
                                                        _mm256_set1_epi32(0x0fff0fffU)), 4))
#define NIBBLE256_ROR_1(x) \
    _mm256_or_si256(_mm256_and_si256(_mm256_srli_epi32((x), 1), \
                                     _mm256_set1_epi32(0x77777777U)), \
                    _mm256_slli_epi32(_mm256_and_si256((x), \
                                                        _mm256_set1_epi32(0x11111111U)), 3))
#define NIBBLE256_ROR_2(x) \
    _mm256_or_si256(_mm256_and_si256(_mm256_srli_epi32((x), 2), \
                                     _mm256_set1_epi32(0x33333333U)), \
                    _mm256_slli_epi32(_mm256_and_si256((x), \
                                                        _mm256_set1_epi32(0x33333333U)), 2))
#define NIBBLE256_ROR_3(x) \
    _mm256_or_si256(_mm256_and_si256(_mm256_srli_epi32((x), 3), \
                                     _mm256_set1_epi32(0x11111111U)), \
                    _mm256_slli_epi32(_mm256_and_si256((x), \
                                                        _mm256_set1_epi32(0x77777777U)), 1))

#define SWAPMOVE256(a, b, mask, n) do {                                  \
    __m256i sm_tmp = _mm256_and_si256(                                   \
        _mm256_xor_si256((b), _mm256_srli_epi32((a), (n))),              \
        _mm256_set1_epi32((mask)));                                      \
    (b) = _mm256_xor_si256((b), sm_tmp);                                 \
    (a) = _mm256_xor_si256((a), _mm256_slli_epi32(sm_tmp, (n)));          \
} while (0)

#define SBOX256(s0, s1, s2, s3) do {                                    \
    (s1) = _mm256_xor_si256((s1), _mm256_and_si256((s0), (s2)));          \
    (s0) = _mm256_xor_si256((s0), _mm256_and_si256((s1), (s3)));          \
    (s2) = _mm256_xor_si256((s2), _mm256_or_si256((s0), (s1)));           \
    (s3) = _mm256_xor_si256((s3), (s2));                                 \
    (s1) = _mm256_xor_si256((s1), (s3));                                 \
    (s3) = _mm256_xor_si256(_mm256_set1_epi32(-1), (s3));                \
    (s2) = _mm256_xor_si256((s2), _mm256_and_si256((s0), (s1)));          \
} while (0)

#define INV_SBOX256(s0, s1, s2, s3) do {                                \
    (s2) = _mm256_xor_si256((s2), _mm256_and_si256((s3), (s1)));          \
    (s0) = _mm256_xor_si256(_mm256_set1_epi32(-1), (s0));                \
    (s1) = _mm256_xor_si256((s1), (s0));                                 \
    (s0) = _mm256_xor_si256((s0), (s2));                                 \
    (s2) = _mm256_xor_si256((s2), _mm256_or_si256((s3), (s1)));           \
    (s3) = _mm256_xor_si256((s3), _mm256_and_si256((s1), (s0)));          \
    (s1) = _mm256_xor_si256((s1), _mm256_and_si256((s3), (s2)));          \
} while (0)

static const uint32_t gift_fix_rconst256[40] = {
    0x10000008U,0x80018000U,0x54000002U,0x01010181U,
    0x8000001fU,0x10888880U,0x6001e000U,0x51500002U,
    0x03030180U,0x8000002fU,0x10088880U,0x60016000U,
    0x41500002U,0x03030080U,0x80000027U,0x10008880U,
    0x4001e000U,0x11500002U,0x03020180U,0x8000002bU,
    0x10080880U,0x60014000U,0x01400002U,0x02020080U,
    0x80000021U,0x10000080U,0x0001c000U,0x51000002U,
    0x03010180U,0x8000002eU,0x10088800U,0x60012000U,
    0x40500002U,0x01030080U,0x80000006U,0x10008808U,
    0xc001a000U,0x14500002U,0x01020181U,0x8000001aU
};

static inline void gift_swapmove_scalar(uint32_t *a, uint32_t *b,
                                        uint32_t mask, unsigned n)
{
    uint32_t tmp = (*b ^ (*a >> n)) & mask;
    *b ^= tmp;
    *a ^= tmp << n;
}

static void gift_pack_scalar(uint32_t state[4], const uint8_t input[16])
{
    state[0] = ((uint32_t)input[6] << 24) | ((uint32_t)input[7] << 16) |
               ((uint32_t)input[14] << 8) | input[15];
    state[1] = ((uint32_t)input[4] << 24) | ((uint32_t)input[5] << 16) |
               ((uint32_t)input[12] << 8) | input[13];
    state[2] = ((uint32_t)input[2] << 24) | ((uint32_t)input[3] << 16) |
               ((uint32_t)input[10] << 8) | input[11];
    state[3] = ((uint32_t)input[0] << 24) | ((uint32_t)input[1] << 16) |
               ((uint32_t)input[8] << 8) | input[9];
    gift_swapmove_scalar(&state[0], &state[0], 0x0a0a0a0aU, 3);
    gift_swapmove_scalar(&state[0], &state[0], 0x00cc00ccU, 6);
    gift_swapmove_scalar(&state[1], &state[1], 0x0a0a0a0aU, 3);
    gift_swapmove_scalar(&state[1], &state[1], 0x00cc00ccU, 6);
    gift_swapmove_scalar(&state[2], &state[2], 0x0a0a0a0aU, 3);
    gift_swapmove_scalar(&state[2], &state[2], 0x00cc00ccU, 6);
    gift_swapmove_scalar(&state[3], &state[3], 0x0a0a0a0aU, 3);
    gift_swapmove_scalar(&state[3], &state[3], 0x00cc00ccU, 6);
    gift_swapmove_scalar(&state[0], &state[1], 0x000f000fU, 4);
    gift_swapmove_scalar(&state[0], &state[2], 0x000f000fU, 8);
    gift_swapmove_scalar(&state[0], &state[3], 0x000f000fU, 12);
    gift_swapmove_scalar(&state[1], &state[2], 0x00f000f0U, 4);
    gift_swapmove_scalar(&state[1], &state[3], 0x00f000f0U, 8);
    gift_swapmove_scalar(&state[2], &state[3], 0x0f000f00U, 4);
}

static void gift_unpack_scalar(uint8_t output[16], uint32_t state[4])
{
    gift_swapmove_scalar(&state[2], &state[3], 0x0f000f00U, 4);
    gift_swapmove_scalar(&state[1], &state[3], 0x00f000f0U, 8);
    gift_swapmove_scalar(&state[1], &state[2], 0x00f000f0U, 4);
    gift_swapmove_scalar(&state[0], &state[3], 0x000f000fU, 12);
    gift_swapmove_scalar(&state[0], &state[2], 0x000f000fU, 8);
    gift_swapmove_scalar(&state[0], &state[1], 0x000f000fU, 4);
    gift_swapmove_scalar(&state[3], &state[3], 0x00cc00ccU, 6);
    gift_swapmove_scalar(&state[3], &state[3], 0x0a0a0a0aU, 3);
    gift_swapmove_scalar(&state[2], &state[2], 0x00cc00ccU, 6);
    gift_swapmove_scalar(&state[2], &state[2], 0x0a0a0a0aU, 3);
    gift_swapmove_scalar(&state[1], &state[1], 0x00cc00ccU, 6);
    gift_swapmove_scalar(&state[1], &state[1], 0x0a0a0a0aU, 3);
    gift_swapmove_scalar(&state[0], &state[0], 0x00cc00ccU, 6);
    gift_swapmove_scalar(&state[0], &state[0], 0x0a0a0a0aU, 3);
    output[0] = (uint8_t)(state[3] >> 24);
    output[1] = (uint8_t)(state[3] >> 16);
    output[2] = (uint8_t)(state[2] >> 24);
    output[3] = (uint8_t)(state[2] >> 16);
    output[4] = (uint8_t)(state[1] >> 24);
    output[5] = (uint8_t)(state[1] >> 16);
    output[6] = (uint8_t)(state[0] >> 24);
    output[7] = (uint8_t)(state[0] >> 16);
    output[8] = (uint8_t)(state[3] >> 8);
    output[9] = (uint8_t)state[3];
    output[10] = (uint8_t)(state[2] >> 8);
    output[11] = (uint8_t)state[2];
    output[12] = (uint8_t)(state[1] >> 8);
    output[13] = (uint8_t)state[1];
    output[14] = (uint8_t)(state[0] >> 8);
    output[15] = (uint8_t)state[0];
}

OC_TARGET("avx2")
static void gift_quintuple256(__m256i s[4], const uint32_t *rk,
                              const uint32_t *rc)
{
    __m256i tmp;
    SBOX256(s[0], s[1], s[2], s[3]);
    s[3] = NIBBLE256_ROR_1(s[3]); s[1] = NIBBLE256_ROR_2(s[1]);
    s[2] = NIBBLE256_ROR_3(s[2]);
    s[1] = _mm256_xor_si256(s[1], _mm256_set1_epi32((int)rk[0]));
    s[2] = _mm256_xor_si256(s[2], _mm256_set1_epi32((int)rk[1]));
    s[0] = _mm256_xor_si256(s[0], _mm256_set1_epi32((int)rc[0]));
    SBOX256(s[3], s[1], s[2], s[0]);
    s[0] = HALF256_ROR_4(s[0]); s[1] = HALF256_ROR_8(s[1]);
    s[2] = HALF256_ROR_12(s[2]);
    s[1] = _mm256_xor_si256(s[1], _mm256_set1_epi32((int)rk[2]));
    s[2] = _mm256_xor_si256(s[2], _mm256_set1_epi32((int)rk[3]));
    s[3] = _mm256_xor_si256(s[3], _mm256_set1_epi32((int)rc[1]));
    SBOX256(s[0], s[1], s[2], s[3]);
    s[3] = GIFT256_ROR(s[3], 16); s[2] = GIFT256_ROR(s[2], 16);
    SWAPMOVE256(s[1], s[1], 0x55555555U, 1);
    SWAPMOVE256(s[2], s[2], 0x00005555U, 1);
    SWAPMOVE256(s[3], s[3], 0x55550000U, 1);
    s[1] = _mm256_xor_si256(s[1], _mm256_set1_epi32((int)rk[4]));
    s[2] = _mm256_xor_si256(s[2], _mm256_set1_epi32((int)rk[5]));
    s[0] = _mm256_xor_si256(s[0], _mm256_set1_epi32((int)rc[2]));
    SBOX256(s[3], s[1], s[2], s[0]);
    s[0] = BYTE256_ROR_6(s[0]); s[1] = BYTE256_ROR_4(s[1]);
    s[2] = BYTE256_ROR_2(s[2]);
    s[1] = _mm256_xor_si256(s[1], _mm256_set1_epi32((int)rk[6]));
    s[2] = _mm256_xor_si256(s[2], _mm256_set1_epi32((int)rk[7]));
    s[3] = _mm256_xor_si256(s[3], _mm256_set1_epi32((int)rc[3]));
    SBOX256(s[0], s[1], s[2], s[3]);
    s[3] = GIFT256_ROR(s[3], 24); s[1] = GIFT256_ROR(s[1], 16);
    s[2] = GIFT256_ROR(s[2], 8);
    s[1] = _mm256_xor_si256(s[1], _mm256_set1_epi32((int)rk[8]));
    s[2] = _mm256_xor_si256(s[2], _mm256_set1_epi32((int)rk[9]));
    s[0] = _mm256_xor_si256(s[0], _mm256_set1_epi32((int)rc[4]));
    tmp = s[0]; s[0] = s[3]; s[3] = tmp;
}

OC_TARGET("avx2")
static void gift_inv_quintuple256(__m256i s[4], const uint32_t *rk,
                                  const uint32_t *rc)
{
    __m256i tmp;
    tmp = s[0]; s[0] = s[3]; s[3] = tmp;
    s[1] = _mm256_xor_si256(s[1], _mm256_set1_epi32((int)rk[8]));
    s[2] = _mm256_xor_si256(s[2], _mm256_set1_epi32((int)rk[9]));
    s[0] = _mm256_xor_si256(s[0], _mm256_set1_epi32((int)rc[4]));
    s[3] = GIFT256_ROR(s[3], 8); s[1] = GIFT256_ROR(s[1], 16);
    s[2] = GIFT256_ROR(s[2], 24); INV_SBOX256(s[3], s[1], s[2], s[0]);
    s[1] = _mm256_xor_si256(s[1], _mm256_set1_epi32((int)rk[6]));
    s[2] = _mm256_xor_si256(s[2], _mm256_set1_epi32((int)rk[7]));
    s[3] = _mm256_xor_si256(s[3], _mm256_set1_epi32((int)rc[3]));
    s[0] = BYTE256_ROR_2(s[0]); s[1] = BYTE256_ROR_4(s[1]);
    s[2] = BYTE256_ROR_6(s[2]); INV_SBOX256(s[0], s[1], s[2], s[3]);
    s[1] = _mm256_xor_si256(s[1], _mm256_set1_epi32((int)rk[4]));
    s[2] = _mm256_xor_si256(s[2], _mm256_set1_epi32((int)rk[5]));
    s[0] = _mm256_xor_si256(s[0], _mm256_set1_epi32((int)rc[2]));
    SWAPMOVE256(s[3], s[3], 0x55550000U, 1);
    SWAPMOVE256(s[1], s[1], 0x55555555U, 1);
    SWAPMOVE256(s[2], s[2], 0x00005555U, 1);
    s[3] = GIFT256_ROR(s[3], 16); s[2] = GIFT256_ROR(s[2], 16);
    INV_SBOX256(s[3], s[1], s[2], s[0]);
    s[1] = _mm256_xor_si256(s[1], _mm256_set1_epi32((int)rk[2]));
    s[2] = _mm256_xor_si256(s[2], _mm256_set1_epi32((int)rk[3]));
    s[3] = _mm256_xor_si256(s[3], _mm256_set1_epi32((int)rc[1]));
    s[0] = HALF256_ROR_12(s[0]); s[1] = HALF256_ROR_8(s[1]);
    s[2] = HALF256_ROR_4(s[2]); INV_SBOX256(s[0], s[1], s[2], s[3]);
    s[1] = _mm256_xor_si256(s[1], _mm256_set1_epi32((int)rk[0]));
    s[2] = _mm256_xor_si256(s[2], _mm256_set1_epi32((int)rk[1]));
    s[0] = _mm256_xor_si256(s[0], _mm256_set1_epi32((int)rc[0]));
    s[3] = NIBBLE256_ROR_3(s[3]); s[1] = NIBBLE256_ROR_2(s[1]);
    s[2] = NIBBLE256_ROR_1(s[2]); INV_SBOX256(s[3], s[1], s[2], s[0]);
}

OC_TARGET("avx2")
static void gift_avx2_fix_eight(const oc_gift128_fix_ctx *ctx, uint8_t *out,
                                const uint8_t *in, int decrypt)
{
    uint32_t lane[4][8], packed[4], unpacked[4];
    __m256i s[4];
    size_t b, i;
    for (b = 0; b < 8; ++b) {
        gift_pack_scalar(packed, in + 16 * b);
        for (i = 0; i < 4; ++i)
            lane[i][b] = packed[i];
    }
    for (i = 0; i < 4; ++i)
        s[i] = _mm256_loadu_si256((const __m256i *)(const void *)lane[i]);
    if (!decrypt) {
        for (i = 0; i < 40; i += 5)
            gift_quintuple256(s, ctx->rkey + 2 * i,
                              gift_fix_rconst256 + i);
    } else {
        for (i = 35; i != (size_t)-5; i -= 5)
            gift_inv_quintuple256(s, ctx->rkey + 2 * i,
                                  gift_fix_rconst256 + i);
    }
    for (i = 0; i < 4; ++i)
        _mm256_storeu_si256((__m256i *)(void *)lane[i], s[i]);
    for (b = 0; b < 8; ++b) {
        for (i = 0; i < 4; ++i)
            unpacked[i] = lane[i][b];
        gift_unpack_scalar(out + 16 * b, unpacked);
    }
}

static void gift_avx2_fix_crypt(const oc_gift128_fix_ctx *ctx, uint8_t *out,
                                const uint8_t *in, size_t blocks, int decrypt)
{
    size_t done = 0;
    if (oc_cpu_has_avx2()) {
        while (blocks - done >= 8) {
            gift_avx2_fix_eight(ctx, out + 16 * done, in + 16 * done,
                                decrypt);
            done += 8;
        }
    }
    while (done < blocks) {
        oc_cipher fallback = oc_gift128_fix_cipher(ctx);
        if (decrypt)
            fallback.decrypt_blocks(fallback.ctx, out + 16 * done,
                                     in + 16 * done, 1);
        else
            fallback.encrypt_blocks(fallback.ctx, out + 16 * done,
                                    in + 16 * done, 1);
        ++done;
    }
}

static void gift_avx2_fix_encrypt(const void *vctx, uint8_t *out,
                                  const uint8_t *in, size_t blocks)
{
    gift_avx2_fix_crypt((const oc_gift128_fix_ctx *)vctx, out, in, blocks, 0);
}

static void gift_avx2_fix_decrypt(const void *vctx, uint8_t *out,
                                  const uint8_t *in, size_t blocks)
{
    gift_avx2_fix_crypt((const oc_gift128_fix_ctx *)vctx, out, in, blocks, 1);
}

oc_cipher oc_gift128_avx2_fix_cipher(const oc_gift128_fix_ctx *ctx)
{
    oc_cipher c = {ctx, 16, gift_avx2_fix_encrypt, gift_avx2_fix_decrypt,
                   "GIFT-128-AVX2-fixsliced"};
    return c;
}

#else

oc_cipher oc_gift128_avx2_fix_cipher(const oc_gift128_fix_ctx *ctx)
{
    return oc_gift128_fix_cipher(ctx);
}

#endif
