#ifndef OPTCRYPTO_INTERNAL_H
#define OPTCRYPTO_INTERNAL_H

#include <stdint.h>
#include <string.h>

static inline uint32_t oc_load32_be(const uint8_t *p)
{
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
           ((uint32_t)p[2] << 8) | p[3];
}

static inline void oc_store32_be(uint8_t *p, uint32_t x)
{
    p[0] = (uint8_t)(x >> 24);
    p[1] = (uint8_t)(x >> 16);
    p[2] = (uint8_t)(x >> 8);
    p[3] = (uint8_t)x;
}

static inline uint64_t oc_load64_be(const uint8_t *p)
{
    return ((uint64_t)oc_load32_be(p) << 32) | oc_load32_be(p + 4);
}

static inline void oc_store64_be(uint8_t *p, uint64_t x)
{
    oc_store32_be(p, (uint32_t)(x >> 32));
    oc_store32_be(p + 4, (uint32_t)x);
}

static inline uint32_t oc_rotl32(uint32_t x, unsigned n)
{
    return (x << n) | (x >> (32U - n));
}

static inline uint32_t oc_rotr32(uint32_t x, unsigned n)
{
    return (x >> n) | (x << (32U - n));
}

#if defined(__x86_64__) || defined(__i386__) || defined(_M_X64) || defined(_M_IX86)
#define OC_X86 1
#else
#define OC_X86 0
#endif

#if OC_X86 && (defined(__GNUC__) || defined(__clang__))
#define OC_TARGET(x) __attribute__((target(x)))
#else
#define OC_TARGET(x)
#endif

#endif
