#include "optcrypto.h"
#include "internal.h"

int oc_cpu_has_avx2(void)
{
#if OC_X86 && (defined(__GNUC__) || defined(__clang__))
    __builtin_cpu_init();
    return __builtin_cpu_supports("avx2") != 0;
#else
    return 0;
#endif
}

int oc_cpu_has_pclmul(void)
{
#if OC_X86 && (defined(__GNUC__) || defined(__clang__))
    __builtin_cpu_init();
    return __builtin_cpu_supports("pclmul") != 0;
#else
    return 0;
#endif
}

int oc_cpu_has_ssse3(void)
{
#if OC_X86 && (defined(__GNUC__) || defined(__clang__))
    __builtin_cpu_init();
    return __builtin_cpu_supports("ssse3") != 0;
#else
    return 0;
#endif
}

int oc_cpu_has_aesni(void)
{
#if OC_X86 && (defined(__GNUC__) || defined(__clang__))
    __builtin_cpu_init();
    return __builtin_cpu_supports("aes") != 0;
#else
    return 0;
#endif
}
