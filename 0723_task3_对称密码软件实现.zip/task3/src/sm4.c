#include "optcrypto.h"
#include "internal.h"

#include <string.h>

#if OC_X86
#include <immintrin.h>
#endif

static const uint8_t sm4_sbox[256] = {
    0xd6,0x90,0xe9,0xfe,0xcc,0xe1,0x3d,0xb7,0x16,0xb6,0x14,0xc2,0x28,0xfb,0x2c,0x05,
    0x2b,0x67,0x9a,0x76,0x2a,0xbe,0x04,0xc3,0xaa,0x44,0x13,0x26,0x49,0x86,0x06,0x99,
    0x9c,0x42,0x50,0xf4,0x91,0xef,0x98,0x7a,0x33,0x54,0x0b,0x43,0xed,0xcf,0xac,0x62,
    0xe4,0xb3,0x1c,0xa9,0xc9,0x08,0xe8,0x95,0x80,0xdf,0x94,0xfa,0x75,0x8f,0x3f,0xa6,
    0x47,0x07,0xa7,0xfc,0xf3,0x73,0x17,0xba,0x83,0x59,0x3c,0x19,0xe6,0x85,0x4f,0xa8,
    0x68,0x6b,0x81,0xb2,0x71,0x64,0xda,0x8b,0xf8,0xeb,0x0f,0x4b,0x70,0x56,0x9d,0x35,
    0x1e,0x24,0x0e,0x5e,0x63,0x58,0xd1,0xa2,0x25,0x22,0x7c,0x3b,0x01,0x21,0x78,0x87,
    0xd4,0x00,0x46,0x57,0x9f,0xd3,0x27,0x52,0x4c,0x36,0x02,0xe7,0xa0,0xc4,0xc8,0x9e,
    0xea,0xbf,0x8a,0xd2,0x40,0xc7,0x38,0xb5,0xa3,0xf7,0xf2,0xce,0xf9,0x61,0x15,0xa1,
    0xe0,0xae,0x5d,0xa4,0x9b,0x34,0x1a,0x55,0xad,0x93,0x32,0x30,0xf5,0x8c,0xb1,0xe3,
    0x1d,0xf6,0xe2,0x2e,0x82,0x66,0xca,0x60,0xc0,0x29,0x23,0xab,0x0d,0x53,0x4e,0x6f,
    0xd5,0xdb,0x37,0x45,0xde,0xfd,0x8e,0x2f,0x03,0xff,0x6a,0x72,0x6d,0x6c,0x5b,0x51,
    0x8d,0x1b,0xaf,0x92,0xbb,0xdd,0xbc,0x7f,0x11,0xd9,0x5c,0x41,0x1f,0x10,0x5a,0xd8,
    0x0a,0xc1,0x31,0x88,0xa5,0xcd,0x7b,0xbd,0x2d,0x74,0xd0,0x12,0xb8,0xe5,0xb4,0xb0,
    0x89,0x69,0x97,0x4a,0x0c,0x96,0x77,0x7e,0x65,0xb9,0xf1,0x09,0xc5,0x6e,0xc6,0x84,
    0x18,0xf0,0x7d,0xec,0x3a,0xdc,0x4d,0x20,0x79,0xee,0x5f,0x3e,0xd7,0xcb,0x39,0x48
};

static const uint32_t sm4_fk[4] = {
    0xa3b1bac6U, 0x56aa3350U, 0x677d9197U, 0xb27022dcU
};

static const uint32_t sm4_ck[32] = {
    0x00070e15U,0x1c232a31U,0x383f464dU,0x545b6269U,
    0x70777e85U,0x8c939aa1U,0xa8afb6bdU,0xc4cbd2d9U,
    0xe0e7eef5U,0xfc030a11U,0x181f262dU,0x343b4249U,
    0x50575e65U,0x6c737a81U,0x888f969dU,0xa4abb2b9U,
    0xc0c7ced5U,0xdce3eaf1U,0xf8ff060dU,0x141b2229U,
    0x30373e45U,0x4c535a61U,0x686f767dU,0x848b9299U,
    0xa0a7aeb5U,0xbcc3cad1U,0xd8dfe6edU,0xf4fb0209U,
    0x10171e25U,0x2c333a41U,0x484f565dU,0x646b7279U
};

static uint32_t sm4_tau(uint32_t x)
{
    return ((uint32_t)sm4_sbox[x >> 24] << 24) |
           ((uint32_t)sm4_sbox[(x >> 16) & 0xff] << 16) |
           ((uint32_t)sm4_sbox[(x >> 8) & 0xff] << 8) |
           sm4_sbox[x & 0xff];
}

static uint32_t sm4_l(uint32_t x)
{
    return x ^ oc_rotl32(x, 2) ^ oc_rotl32(x, 10) ^
           oc_rotl32(x, 18) ^ oc_rotl32(x, 24);
}

static uint32_t sm4_l_key(uint32_t x)
{
    return x ^ oc_rotl32(x, 13) ^ oc_rotl32(x, 23);
}

void oc_sm4_init(oc_sm4_ctx *ctx, const uint8_t key[16])
{
    uint32_t k[36];
    size_t i;

    for (i = 0; i < 4; ++i)
        k[i] = oc_load32_be(key + 4 * i) ^ sm4_fk[i];
    for (i = 0; i < 32; ++i) {
        k[i + 4] = k[i] ^ sm4_l_key(sm4_tau(k[i + 1] ^ k[i + 2] ^
                                            k[i + 3] ^ sm4_ck[i]));
        ctx->rk[i] = k[i + 4];
    }
}

void oc_sm4_ttable_init(oc_sm4_ttable_ctx *ctx, const uint8_t key[16])
{
    size_t i;
    oc_sm4_init(&ctx->base, key);
    for (i = 0; i < 256; ++i) {
        uint32_t s = sm4_sbox[i];
        ctx->sbox32[i] = s;
        ctx->table[0][i] = sm4_l(s << 24);
        ctx->table[1][i] = sm4_l(s << 16);
        ctx->table[2][i] = sm4_l(s << 8);
        ctx->table[3][i] = sm4_l(s);
    }
}

static void sm4_basic_one(const oc_sm4_ctx *ctx, uint8_t *out,
                          const uint8_t *in, int decrypt)
{
    uint32_t x[36];
    size_t i;
    for (i = 0; i < 4; ++i)
        x[i] = oc_load32_be(in + 4 * i);
    for (i = 0; i < 32; ++i) {
        uint32_t rk = decrypt ? ctx->rk[31 - i] : ctx->rk[i];
        x[i + 4] = x[i] ^ sm4_l(sm4_tau(x[i + 1] ^ x[i + 2] ^
                                        x[i + 3] ^ rk));
    }
    for (i = 0; i < 4; ++i)
        oc_store32_be(out + 4 * i, x[35 - i]);
}

static void sm4_basic_encrypt(const void *vctx, uint8_t *out,
                              const uint8_t *in, size_t blocks)
{
    const oc_sm4_ctx *ctx = (const oc_sm4_ctx *)vctx;
    size_t i;
    for (i = 0; i < blocks; ++i)
        sm4_basic_one(ctx, out + 16 * i, in + 16 * i, 0);
}

static void sm4_basic_decrypt(const void *vctx, uint8_t *out,
                              const uint8_t *in, size_t blocks)
{
    const oc_sm4_ctx *ctx = (const oc_sm4_ctx *)vctx;
    size_t i;
    for (i = 0; i < blocks; ++i)
        sm4_basic_one(ctx, out + 16 * i, in + 16 * i, 1);
}

static uint32_t sm4_t_round(const oc_sm4_ttable_ctx *ctx, uint32_t x)
{
    return ctx->table[0][x >> 24] ^
           ctx->table[1][(x >> 16) & 0xff] ^
           ctx->table[2][(x >> 8) & 0xff] ^
           ctx->table[3][x & 0xff];
}

static void sm4_ttable_one(const oc_sm4_ttable_ctx *ctx, uint8_t *out,
                           const uint8_t *in, int decrypt)
{
    uint32_t x[36];
    size_t i;
    for (i = 0; i < 4; ++i)
        x[i] = oc_load32_be(in + 4 * i);
    for (i = 0; i < 32; ++i) {
        uint32_t rk = decrypt ? ctx->base.rk[31 - i] : ctx->base.rk[i];
        x[i + 4] = x[i] ^ sm4_t_round(ctx, x[i + 1] ^ x[i + 2] ^
                                           x[i + 3] ^ rk);
    }
    for (i = 0; i < 4; ++i)
        oc_store32_be(out + 4 * i, x[35 - i]);
}

static void sm4_ttable_encrypt(const void *vctx, uint8_t *out,
                               const uint8_t *in, size_t blocks)
{
    const oc_sm4_ttable_ctx *ctx = (const oc_sm4_ttable_ctx *)vctx;
    size_t i;
    for (i = 0; i < blocks; ++i)
        sm4_ttable_one(ctx, out + 16 * i, in + 16 * i, 0);
}

static void sm4_ttable_decrypt(const void *vctx, uint8_t *out,
                               const uint8_t *in, size_t blocks)
{
    const oc_sm4_ttable_ctx *ctx = (const oc_sm4_ttable_ctx *)vctx;
    size_t i;
    for (i = 0; i < blocks; ++i)
        sm4_ttable_one(ctx, out + 16 * i, in + 16 * i, 1);
}

/* Scalar layout/shuffle optimization.  The reference implementation keeps
 * all 36 state words in memory.  The round recurrence only needs four words;
 * rotating those four registers is the scalar equivalent of the courseware's
 * "track positions and restore once" strategy. */
static void sm4_shuffle_one(const oc_sm4_ctx *ctx, uint8_t *out,
                            const uint8_t *in, int decrypt)
{
    uint32_t a = oc_load32_be(in);
    uint32_t b = oc_load32_be(in + 4);
    uint32_t c = oc_load32_be(in + 8);
    uint32_t d = oc_load32_be(in + 12);
    size_t i;
    for (i = 0; i < 32; ++i) {
        uint32_t rk = decrypt ? ctx->rk[31 - i] : ctx->rk[i];
        uint32_t t = a ^ sm4_l(sm4_tau(b ^ c ^ d ^ rk));
        a = b;
        b = c;
        c = d;
        d = t;
    }
    oc_store32_be(out, d);
    oc_store32_be(out + 4, c);
    oc_store32_be(out + 8, b);
    oc_store32_be(out + 12, a);
}

static void sm4_shuffle_scalar_encrypt(const void *vctx, uint8_t *out,
                                       const uint8_t *in, size_t blocks)
{
    const oc_sm4_ctx *ctx = (const oc_sm4_ctx *)vctx;
    size_t i;
    for (i = 0; i < blocks; ++i)
        sm4_shuffle_one(ctx, out + 16 * i, in + 16 * i, 0);
}

static void sm4_shuffle_scalar_decrypt(const void *vctx, uint8_t *out,
                                       const uint8_t *in, size_t blocks)
{
    const oc_sm4_ctx *ctx = (const oc_sm4_ctx *)vctx;
    size_t i;
    for (i = 0; i < blocks; ++i)
        sm4_shuffle_one(ctx, out + 16 * i, in + 16 * i, 1);
}

#if OC_X86
OC_TARGET("avx2")
static void sm4_avx2_eight(const oc_sm4_ttable_ctx *ctx, uint8_t *out,
                           const uint8_t *in, int decrypt)
{
    uint32_t lane[4][8];
    __m256i x[36];
    const __m256i mask = _mm256_set1_epi32(0xff);
    size_t i, j;

    for (j = 0; j < 8; ++j)
        for (i = 0; i < 4; ++i)
            lane[i][j] = oc_load32_be(in + 16 * j + 4 * i);
    for (i = 0; i < 4; ++i)
        x[i] = _mm256_loadu_si256((const __m256i *)(const void *)lane[i]);

    for (i = 0; i < 32; ++i) {
        uint32_t rk = decrypt ? ctx->base.rk[31 - i] : ctx->base.rk[i];
        __m256i t = _mm256_xor_si256(x[i + 1], x[i + 2]);
        __m256i y0, y1, y2, y3;
        t = _mm256_xor_si256(t, x[i + 3]);
        t = _mm256_xor_si256(t, _mm256_set1_epi32((int)rk));
        y0 = _mm256_and_si256(_mm256_srli_epi32(t, 24), mask);
        y1 = _mm256_and_si256(_mm256_srli_epi32(t, 16), mask);
        y2 = _mm256_and_si256(_mm256_srli_epi32(t, 8), mask);
        y3 = _mm256_and_si256(t, mask);
        y0 = _mm256_i32gather_epi32((const int *)ctx->table[0], y0, 4);
        y1 = _mm256_i32gather_epi32((const int *)ctx->table[1], y1, 4);
        y2 = _mm256_i32gather_epi32((const int *)ctx->table[2], y2, 4);
        y3 = _mm256_i32gather_epi32((const int *)ctx->table[3], y3, 4);
        y0 = _mm256_xor_si256(y0, y1);
        y2 = _mm256_xor_si256(y2, y3);
        x[i + 4] = _mm256_xor_si256(x[i], _mm256_xor_si256(y0, y2));
    }

    for (i = 0; i < 4; ++i)
        _mm256_storeu_si256((__m256i *)(void *)lane[i], x[35 - i]);
    for (j = 0; j < 8; ++j)
        for (i = 0; i < 4; ++i)
            oc_store32_be(out + 16 * j + 4 * i, lane[i][j]);
}
#endif

static void sm4_avx2_crypt(const oc_sm4_ttable_ctx *ctx, uint8_t *out,
                           const uint8_t *in, size_t blocks, int decrypt)
{
    size_t done = 0;
#if OC_X86
    if (oc_cpu_has_avx2()) {
        while (blocks - done >= 8) {
            sm4_avx2_eight(ctx, out + 16 * done, in + 16 * done, decrypt);
            done += 8;
        }
    }
#endif
    while (done < blocks) {
        sm4_ttable_one(ctx, out + 16 * done, in + 16 * done, decrypt);
        ++done;
    }
}

static void sm4_avx2_encrypt(const void *vctx, uint8_t *out,
                             const uint8_t *in, size_t blocks)
{
    sm4_avx2_crypt((const oc_sm4_ttable_ctx *)vctx, out, in, blocks, 0);
}

static void sm4_avx2_decrypt(const void *vctx, uint8_t *out,
                             const uint8_t *in, size_t blocks)
{
    sm4_avx2_crypt((const oc_sm4_ttable_ctx *)vctx, out, in, blocks, 1);
}

oc_cipher oc_sm4_basic_cipher(const oc_sm4_ctx *ctx)
{
    oc_cipher c = {ctx, 16, sm4_basic_encrypt, sm4_basic_decrypt, "SM4-basic"};
    return c;
}

oc_cipher oc_sm4_ttable_cipher(const oc_sm4_ttable_ctx *ctx)
{
    oc_cipher c = {ctx, 16, sm4_ttable_encrypt, sm4_ttable_decrypt,
                   "SM4-T-table"};
    return c;
}

oc_cipher oc_sm4_scalar_shuffle_cipher(const oc_sm4_ctx *ctx)
{
    oc_cipher c = {ctx, 16, sm4_shuffle_scalar_encrypt,
                   sm4_shuffle_scalar_decrypt, "SM4-scalar-shuffle"};
    return c;
}

oc_cipher oc_sm4_avx2_cipher(const oc_sm4_ttable_ctx *ctx)
{
    oc_cipher c = {ctx, 16, sm4_avx2_encrypt, sm4_avx2_decrypt,
                   "SM4-AVX2-gather"};
    return c;
}

/* SM4 shuffle (vpshufb) implementation.
 *
 * The 256-entry S-box is decomposed into 16 sub-tables of 16 entries each,
 * indexed by the high nibble of the input byte.  We then evaluate SubBytes
 * with 16 vpshufb lookups (one per high nibble value), masking each result
 * by whether the input byte actually has that high nibble, and OR-ing all 16
 * masked vectors together.  The 32-bit linear transform L is then applied
 * with SIMD shifts and XORs, fully avoiding gather/scatter and any
 * cache-timing surface from T-table-style memory access.
 */
void oc_sm4_shuffle_init(oc_sm4_shuffle_ctx *ctx, const uint8_t key[16])
{
    size_t h, l;
    uint8_t sub[16] __attribute__((aligned(16)));
    oc_sm4_init(&ctx->base, key);
    for (h = 0; h < 16; ++h) {
        for (l = 0; l < 16; ++l)
            sub[l] = sm4_sbox[h * 16 + l];
        ctx->sbox_sub[h] = _mm_load_si128((const __m128i *)(const void *)sub);
    }
}

#if OC_X86
OC_TARGET("ssse3,avx2")
static __m128i sm4_shuffle_subbytes128(const oc_sm4_shuffle_ctx *ctx, __m128i x)
{
    /* Decompose every byte into (h, l) = (high nibble, low nibble). */
    __m128i h = _mm_and_si128(_mm_srli_epi32(x, 4), _mm_set1_epi8(0x0f));
    __m128i l = _mm_and_si128(x, _mm_set1_epi8(0x0f));
    __m128i r = _mm_setzero_si128();
    size_t i;
    for (i = 0; i < 16; ++i) {
        __m128i looked = _mm_shuffle_epi8(ctx->sbox_sub[i], l);
        __m128i mask = _mm_cmpeq_epi8(h, _mm_set1_epi8((char)i));
        r = _mm_or_si128(r, _mm_and_si128(looked, mask));
    }
    return r;
}

OC_TARGET("ssse3,avx2")
static __m256i sm4_shuffle_L256(__m256i s)
{
    /* L(B) = B ^ (B<<<2) ^ (B<<<10) ^ (B<<<18) ^ (B<<<24) per 32-bit lane. */
    __m256i r2  = _mm256_or_si256(_mm256_slli_epi32(s,  2), _mm256_srli_epi32(s, 30));
    __m256i r10 = _mm256_or_si256(_mm256_slli_epi32(s, 10), _mm256_srli_epi32(s, 22));
    __m256i r18 = _mm256_or_si256(_mm256_slli_epi32(s, 18), _mm256_srli_epi32(s, 14));
    __m256i r24 = _mm256_or_si256(_mm256_slli_epi32(s, 24), _mm256_srli_epi32(s,  8));
    return _mm256_xor_si256(_mm256_xor_si256(s, r2),
                            _mm256_xor_si256(r10, _mm256_xor_si256(r18, r24)));
}

OC_TARGET("ssse3,avx2")
static void sm4_shuffle_eight(const oc_sm4_shuffle_ctx *ctx, uint8_t *out,
                              const uint8_t *in, int decrypt)
{
    __m256i X[36];
    uint32_t lane[4][8];
    size_t i, j;

    for (j = 0; j < 8; ++j)
        for (i = 0; i < 4; ++i)
            lane[i][j] = oc_load32_be(in + 16 * j + 4 * i);
    for (i = 0; i < 4; ++i)
        X[i] = _mm256_loadu_si256((const __m256i *)(const void *)lane[i]);

    for (i = 0; i < 32; ++i) {
        uint32_t rk = decrypt ? ctx->base.rk[31 - i] : ctx->base.rk[i];
        __m256i t = _mm256_xor_si256(_mm256_xor_si256(X[i + 1], X[i + 2]),
                                     _mm256_xor_si256(X[i + 3],
                                                      _mm256_set1_epi32((int)rk)));
        __m128i t_lo = _mm256_castsi256_si128(t);
        __m128i t_hi = _mm256_extracti128_si256(t, 1);
        __m128i s_lo = sm4_shuffle_subbytes128(ctx, t_lo);
        __m128i s_hi = sm4_shuffle_subbytes128(ctx, t_hi);
        __m256i s = _mm256_set_m128i(s_hi, s_lo);
        __m256i L = sm4_shuffle_L256(s);
        X[i + 4] = _mm256_xor_si256(X[i], L);
    }

    for (i = 0; i < 4; ++i)
        _mm256_storeu_si256((__m256i *)(void *)lane[i], X[35 - i]);
    for (j = 0; j < 8; ++j)
        for (i = 0; i < 4; ++i)
            oc_store32_be(out + 16 * j + 4 * i, lane[i][j]);
}
#endif

static void sm4_shuffle_crypt(const oc_sm4_shuffle_ctx *ctx, uint8_t *out,
                              const uint8_t *in, size_t blocks, int decrypt)
{
    size_t done = 0;
#if OC_X86
    if (oc_cpu_has_avx2()) {
        while (blocks - done >= 8) {
            sm4_shuffle_eight(ctx, out + 16 * done, in + 16 * done, decrypt);
            done += 8;
        }
    }
#else
    (void)ctx; (void)out; (void)in; (void)decrypt; (void)done;
#endif
    while (done < blocks) {
        sm4_basic_one(&ctx->base, out + 16 * done, in + 16 * done, decrypt);
        ++done;
    }
}

static void sm4_shuffle_encrypt(const void *vctx, uint8_t *out,
                                const uint8_t *in, size_t blocks)
{
    sm4_shuffle_crypt((const oc_sm4_shuffle_ctx *)vctx, out, in, blocks, 0);
}

static void sm4_shuffle_decrypt(const void *vctx, uint8_t *out,
                                const uint8_t *in, size_t blocks)
{
    sm4_shuffle_crypt((const oc_sm4_shuffle_ctx *)vctx, out, in, blocks, 1);
}

oc_cipher oc_sm4_shuffle_cipher(const oc_sm4_shuffle_ctx *ctx)
{
    oc_cipher c = {ctx, 16, sm4_shuffle_encrypt, sm4_shuffle_decrypt,
                   "SM4-AVX2-shuffle"};
    return c;
}
