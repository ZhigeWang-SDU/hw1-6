# Third-Party Notices

`src/gift128_fix.c` is adapted from the public GIFT optimized implementation by Alexandre Adomnicai and contributors:

- Repository: https://github.com/aadomn/gift
- Upstream path: `crypto_bc/gift128/opt32`
- Upstream license: CC0 1.0 Universal
- License text: https://creativecommons.org/publicdomain/zero/1.0/legalcode

The adaptation preserves the fixsliced round/key-schedule design while adding this project's context-based API, unaligned-safe input handling, multi-block wrapper, and coding style.

Algorithm specifications and test vectors are referenced in `REPORT.md`; they are not copied as third-party source files.
